from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget
)

from ..i18n import tr
from .current_page_stack import CurrentPageStack


class InsertPanel(QWidget):
    """Right-side insert workflow.

    The first page is deliberately small today, but the internal stack makes the
    interaction extensible: a future image/media action can replace the choice
    page with its own settings screen without introducing another popup UI.
    """

    sceneBreakRequested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self.stack = CurrentPageStack()
        root.addWidget(self.stack)

        self.menu_page = QWidget()
        layout = QVBoxLayout(self.menu_page)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(12)

        title = QLabel(tr('insert.title', 'Toevoegen'))
        title.setObjectName('sectionTitle')
        description = QLabel(tr(
            'insert.description',
            'Voeg een element toe op de huidige positie in het manuscript.'
        ))
        description.setObjectName('muted')
        description.setWordWrap(True)

        scene_card = QFrame()
        scene_card.setObjectName('insertChoiceCard')
        card_layout = QHBoxLayout(scene_card)
        card_layout.setContentsMargins(12, 10, 10, 10)
        card_layout.setSpacing(10)

        text_col = QVBoxLayout()
        text_col.setContentsMargins(0, 0, 0, 0)
        text_col.setSpacing(3)
        scene_title = QLabel(tr('insert.scene_break', 'Scènebreuk'))
        scene_title.setObjectName('sectionTitle')
        scene_description = QLabel(tr(
            'insert.scene_break.description',
            'Markeer een duidelijke overgang tussen twee scènes.'
        ))
        scene_description.setObjectName('muted')
        scene_description.setWordWrap(True)
        text_col.addWidget(scene_title)
        text_col.addWidget(scene_description)

        self.scene_break_button = QPushButton(tr('insert.add', 'Toevoegen'))
        self.scene_break_button.setObjectName('secondaryButton')
        self.scene_break_button.setToolTip(tr(
            'insert.scene_break.tip',
            'Voeg een scènebreuk toe op de cursorpositie'
        ))
        self.scene_break_button.clicked.connect(self.sceneBreakRequested.emit)

        card_layout.addLayout(text_col, 1)
        card_layout.addWidget(self.scene_break_button)

        layout.addWidget(title)
        layout.addWidget(description)
        layout.addSpacing(4)
        layout.addWidget(scene_card)
        layout.addStretch(1)

        self.stack.addWidget(self.menu_page)
        self.stack.setCurrentWidget(self.menu_page)

    def reset(self):
        """Return to the top-level insert choices when the panel is reopened."""
        self.stack.setCurrentWidget(self.menu_page)
