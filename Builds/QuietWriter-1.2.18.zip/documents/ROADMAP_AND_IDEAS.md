# QuietWriter — roadmap en ideeën

**Status:** canonieke roadmap vanaf QuietWriter 1.2.13  
**Laatste actualisatie:** 6 oktober 2026

Deze roadmap beschrijft alleen de actuele productrichting. Uitgebreide oude 1.0/v2-ontwerpen zijn bewaard in `ROADMAP_HISTORY_TO_1_2_13.md`.

## 1. Waar we nu staan

De private ontwikkelrepository `gen-x-coder/QuietWriter-dev` staat op **1.2.13** en is de actuele ontwikkelbaseline.

De publieke repository `gen-x-coder/QuietWriter` heeft nog **1.1.0** als publieke releasebron. De 1.2.x-lijn wordt bewust nog niet publiek gereleased zolang de SignPath Foundation-aanvraag loopt. We willen liever één duidelijke signed 1.2-release dan meerdere nieuwe unsigned Windows-builds kort na elkaar.

1.2.13 is functioneel en getest. Nieuwe ontwikkeling mag doorgaan in de dev-repository.

## 2. Wat al gerealiseerd is

Onder andere aanwezig:

- lokale manuscripteditor met hoofdstukken en secties;
- Planning met scènes en personages;
- **In dit hoofdstuk**;
- **Darlings / Bewaarplaats**;
- **Open punten**;
- versiegeschiedenis, herstel en conflictbescherming;
- integriteitscontrole en expliciete migratiebasis;
- `.qwbook` export/import als volledig overdraagbaar boekpakket;
- DOCX import en export;
- EPUB, PDF en Markdown export;
- begeleide exportwizard;
- first-run/onboarding;
- handmatige en optionele automatische GitHub-updatecontrole;
- AI **Meelezer** met Ollama en OpenRouter;
- Schrijverspersona, Boekprofiel en Boekgeheugen;
- spelling, zoeken, focusweergave en opmaak;
- lokale media;
- vijf interfacetalen: Nederlands, Engels, Duits, Frans en Spaans;
- vijftien thema's, waaronder Lamplicht;
- Windows portable build, smoke-test en publieke Windows/Ubuntu-CI;
- GPLv3 en publieke release-/privacy-/securitydocumentatie.

Details per versie staan in `CHANGELOG.md`.

## 3. Eerstvolgende stap — intern boek- en manuscriptformaat onderzoeken

**Prioriteit: zeer hoog — eerst onderzoeken, nog niets migreren.**

QuietWriter gebruikt nu Markdown als canonieke manuscriptbron omdat dat historisch zo is gegroeid. Dat heeft belangrijke voordelen: leesbaarheid, openheid, diffbaarheid, eenvoudige recovery en onafhankelijkheid van QuietWriter.

Maar het product krijgt steeds meer semantiek rond tekst: afbeeldingen, Open punten, publicatiestructuur, planningkoppelingen, toekomstige boektypografie en mogelijk andere structurele elementen. Daarom mag Markdown niet alleen uit gewoonte de permanente keuze blijven.

### Centrale vraag

**Wat is voor QuietWriter op langere termijn het beste interne boek- en manuscriptmodel, nu er echte gebruikers en bestaande boeken zijn?**

Het doel is nadrukkelijk **geen DOCX-roundtrip**. Een geïmporteerd Word-document wordt een QuietWriter-boek. We hoeven onbekende Word-opmaak niet later weer exact naar Word terug te kunnen schrijven.

Wel moet het onderzoek de basis van DOCX/OOXML goed begrijpen, zodat een normale roman betrouwbaar kan worden geïmporteerd zonder stille vervorming. De primaire praktijkcase is proza met hoofdstukken/scènes, gebruikelijke inline-opmaak en hooguit enkele afbeeldingen en tabellen.

Dit onderzoek moet minimaal vergelijken:

1. huidige Markdown per hoofdstuk;
2. Markdown met een explicietere semantische laag/sidecar-data;
3. een gestructureerd documentmodel met eigen schema;
4. HTML/XHTML-achtige opslag;
5. JSON/AST-achtige opslag;
6. hybride modellen waarbij een open tekstformaat de bron blijft maar QuietWriter een formeel structureel model onderhoudt.

Andere kandidaten mogen worden toegevoegd als daar een sterke reden voor is.

### Beoordelingscriteria

Niet alleen kijken naar wat technisch elegant is. Beoordeel minimaal:

- menselijk leesbare en herstelbare bestanden;
- open formaat en vendor lock-in;
- backward en forward compatibility;
- veilige migratie van bestaande boeken;
- externe wijzigingen / Dropbox / twee computers;
- atomische writes en conflictgedrag;
- History en byte-/semantisch herstel;
- source fidelity;
- Undo/Redo;
- hoofdstukken en scènegrenzen;
- inline opmaak;
- afbeeldingen en andere media;
- Open punten en toekomstige semantische annotaties;
- voetnoten, poëzie, gecentreerde tekst, kleinkapitalen en andere boektypografie;
- zoeken en vervangen;
- spelling;
- woordtelling en statistiek;
- AI-context;
- DOCX/EPUB/PDF/export;
- prestaties bij grote boeken;
- inspecteerbaarheid bij bugs;
- testbaarheid;
- mogelijkheid voor gebruikers om hun werk buiten QuietWriter terug te krijgen.

### DOCX-import als expliciet hoofdcriterium

Onderzoek DOCX niet als generiek rich-textformaat, maar vanuit wat romanschrijvers waarschijnlijk daadwerkelijk aanleveren.

Minimale importmatrix:

- gewone alinea's;
- Heading 1/2/3 en hoofdstuktitels;
- bold, italic, underline en strike waar relevant;
- scènebreuken;
- harde regeleinden;
- page breaks;
- lijsten voor uitzonderlijke gevallen;
- hyperlinks;
- afbeeldingen;
- afbeeldingsonderschriften waar herkenbaar;
- eenvoudige tabellen;
- documenttaal en basismetadata;
- Word-stijlen en style inheritance.

Daarnaast inventariseren wat we bewust **niet** willen ondersteunen of alleen met waarschuwing importeren, bijvoorbeeld track changes, comments, complexe velden, tekstvakken, zwevende objecten en exotische lay-out.

Een import mag normaliseren naar QuietWriter-semantiek. De gebruiker moet vooraf of achteraf duidelijk kunnen zien wat niet is overgenomen. Perfecte DOCX→QuietWriter→DOCX-reconstructie is geen doel.

### Open-source vergelijkingsonderzoek

Bestudeer minimaal:

- NEO;
- novelWriter;
- Manuskript;
- bibisco;
- één of meer aanvullende open-source schrijfapps wanneer hun opslag-/importarchitectuur relevant is.

Kijk per project naar:

- canoniek intern opslagformaat;
- scheiding tussen tekst en metadata;
- hoe hoofdstukken/scènes worden gemodelleerd;
- hoe DOCX wordt geïmporteerd;
- welke DOCX-features bewust worden genegeerd;
- hoe export wordt opgebouwd;
- hoe recovery/sync/backups worden opgelost;
- welke lessen bruikbaar zijn voor QuietWriter en welke niet.

### Harde randvoorwaarden

Tot dit onderzoek is afgerond:

- Markdown blijft de canonieke manuscriptbron;
- bestaande boeken worden niet gemigreerd;
- geen nieuw opslagformaat alleen voor een nieuwe feature introduceren;
- geen stille migratie;
- een toekomstige overgang moet expliciet, herstelbaar en terugwaarts doordacht zijn;
- gebruikersdata gaat vóór architectonische elegantie.

### Onderzoeksdocument

Het werkdocument staat in:

`documents/BOOK_FORMAT_ARCHITECTURE_RESEARCH.md`

Dit document bevat de huidige QuietWriter-analyse, open-source vergelijkingen, DOCX-scope, kandidaatarchitecturen en een expliciete reviewopdracht voor Claude/andere reviewers.

## 4. Productontwikkeling na/naast het formaatonderzoek

### 4.1 Schrijfdoelen en rustige voortgang
Hoge productwaarde. Geen streak-shaming, badges of motiverende popups.

### 4.2 Planning dichter bij het schrijven
Onderzoek naar spookalinea's / ghost paragraphs, altijd presentation-only.

### 4.3 Planning-polish op basis van echt gebruik
Scènes verplaatsen, inklapbare hoofdstukgroepen, compactere scènebewerking, eerste verschijning personages, locaties, relaties en aliassen.

### 4.4 Automatische `.qwbook`-back-ups
Dagelijks, handmatig, instelbare locatie en retention; back-up blijft output en geen tweede live bron.

## 5. Latere inhoudelijke ideeën

### Boektypografie
Voetnoten, poëzie/verzen, gecentreerde tekst, kleinkapitalen, harde spaties en bijzondere literaire opmaak.

### Export/publicatie
Echte exportpreview, half-title/schutblad, blanco pagina, meer TOC-niveaus, extra front/back matter en verdere afbeeldingsoptimalisatie.

### AI
Contextbudget, providercompatibiliteit, eenvoudigere Ollama-setup, voorstellen voor feiten/Open punten en aliasherkenning.

### Diagnostiek
Veilige diagnoseweergave zonder manuscriptinhoud, API-sleutels of gevoelige boekdata.

## 6. Distributie en platforms

### Nu
- SignPath Foundation-aanvraag afwachten;
- 1.2.x niet opnieuw unsigned publiek uitbrengen;
- doorontwikkelen in `QuietWriter-dev`.

### Na SignPath-goedkeuring
- trusted GitHub build/signing inrichten;
- signed buildflow testen;
- 1.2.x-bron naar publieke repository promoveren;
- publieke Windows + Ubuntu CI;
- officiële signed 1.2-release.

## 7. Bewust niet bouwen

- AI als ghostwriter;
- Herschrijf selectie;
- autonome Boekgeheugenwrites;
- stille reparatie/migratie;
- future-format downgraden;
- agressieve media-cleanup;
- tweede onafhankelijke hoofdstukvolgorde;
- volwaardige coverdesigner;
- complexe DTP-editor;
- volledige Scrivener/Obsidian/worldbuilding-featurepariteit.

## 8. Beslisregels voor nieuwe features

Voor substantiële wijzigingen eerst vastleggen welk probleem wordt opgelost, welke persistente data verandert, hoe conflict/recovery/history werken, wat zoeken/spelling/export/AI zien en welke tests het contract bewaken.

De roadmap is een beslisdocument, geen verzamelbak voor iedere mogelijke feature.
