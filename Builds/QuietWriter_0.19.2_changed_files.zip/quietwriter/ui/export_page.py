from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QUrl, Qt
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QButtonGroup, QCheckBox, QComboBox, QFileDialog, QFrame, QHBoxLayout, QLabel,
    QMessageBox, QPushButton, QRadioButton, QScrollArea, QVBoxLayout, QWidget
)

from ..exporting import (
    ExportSettingsStore, TEMPLATES, build_export_document, export_epub,
    export_markdown, run_preflight,
)
from ..i18n import current_locale, tr
from .dialogs import confirm


class ExportPage(QWidget):
    """Single lightweight home for EPUB/Markdown export.

    The page owns UI preferences only. Publication content remains in the existing
    PublicationStore and rendering receives a read-only ExportDocument snapshot.
    """

    def __init__(self, main):
        super().__init__(main)
        self.main = main
        self.book = None
        self.store = ExportSettingsStore()
        self.export_settings: dict = {}
        self.document = None
        self.last_output: Path | None = None

        root = QVBoxLayout(self); root.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame)
        host = QWidget(); body = QVBoxLayout(host); body.setContentsMargins(42, 32, 42, 32); body.setSpacing(14)
        scroll.setWidget(host); root.addWidget(scroll)

        heading = QLabel(tr('export.title', 'Exporteren')); heading.setObjectName('title')
        self.subtitle = QLabel(''); self.subtitle.setObjectName('muted'); self.subtitle.setWordWrap(True)
        body.addWidget(heading); body.addWidget(self.subtitle); body.addSpacing(6)

        section = QLabel(tr('export.format', 'Formaat')); section.setObjectName('sectionTitle'); body.addWidget(section)
        formats = QHBoxLayout(); formats.setSpacing(10)
        self.format_group = QButtonGroup(self); self.format_group.setExclusive(True)
        self.epub_button = self._format_button('EPUB', tr('export.epub.short', 'Voor e-readers en e-bookapps'), 'epub')
        self.pdf_button = self._format_button('PDF', tr('export.pdf.short', 'Vaste pagina-opmaak · later'), 'pdf'); self.pdf_button.setEnabled(False)
        self.markdown_button = self._format_button('Markdown', tr('export.markdown.short', 'Uitwisselen en back-up'), 'markdown')
        for button in (self.epub_button, self.pdf_button, self.markdown_button): formats.addWidget(button, 1)
        body.addLayout(formats)

        self.preflight_box = QFrame(); self.preflight_box.setObjectName('softPanel')
        pre = QVBoxLayout(self.preflight_box); pre.setContentsMargins(14, 12, 14, 12); pre.setSpacing(5)
        pretitle = QLabel(tr('export.preflight.title', 'Exportcontrole')); pretitle.setObjectName('sectionTitle'); pre.addWidget(pretitle)
        self.preflight_label = QLabel(''); self.preflight_label.setWordWrap(True); self.preflight_label.setTextInteractionFlags(Qt.TextSelectableByMouse); pre.addWidget(self.preflight_label)
        body.addWidget(self.preflight_box)

        content_box = QFrame(); content_box.setObjectName('softPanel')
        cl = QVBoxLayout(content_box); cl.setContentsMargins(14, 12, 14, 12); cl.setSpacing(6)
        ct = QLabel(tr('export.content.title', 'Inhoud')); ct.setObjectName('sectionTitle'); cl.addWidget(ct)
        self.content_summary = QLabel(''); self.content_summary.setWordWrap(True); cl.addWidget(self.content_summary)
        publication_btn = QPushButton(tr('export.content.adjust', 'Publicatiestructuur aanpassen'))
        publication_btn.setObjectName('secondaryButton'); publication_btn.clicked.connect(self._open_publication_setup); cl.addWidget(publication_btn, 0, Qt.AlignLeft)
        body.addWidget(content_box)

        self.epub_panel = QFrame(); self.epub_panel.setObjectName('panel')
        el = QVBoxLayout(self.epub_panel); el.setContentsMargins(0, 6, 0, 0); el.setSpacing(10)
        et = QLabel(tr('export.appearance', 'Vormgeving')); et.setObjectName('sectionTitle'); el.addWidget(et)
        template_row = QHBoxLayout(); template_row.addWidget(QLabel(tr('export.template', 'Template')))
        self.template_combo = QComboBox();
        for key, template in TEMPLATES.items():
            label = template.name_en if current_locale() == 'en' else template.name_nl
            self.template_combo.addItem(label, key)
        template_row.addWidget(self.template_combo, 1); el.addLayout(template_row)
        self.template_help = QLabel(''); self.template_help.setObjectName('muted'); self.template_help.setWordWrap(True); el.addWidget(self.template_help)

        self.include_cover = QCheckBox(tr('export.cover.include', 'Boekomslag opnemen')); self.include_cover.setObjectName('publicationToggle'); el.addWidget(self.include_cover)
        cover_box = QFrame(); cover_box.setObjectName('softPanel'); cbl = QVBoxLayout(cover_box); cbl.setContentsMargins(12, 10, 12, 10); cbl.setSpacing(5)
        cover_title = QLabel(tr('export.cover.title', 'Tekst op de omslag')); cover_title.setObjectName('sectionTitle'); cbl.addWidget(cover_title)
        self.cover_art_only = QRadioButton(tr('export.cover.artwork_only', 'Mijn omslag heeft geen tekst — QuietWriter voegt titel en auteur toe'))
        self.cover_has_text = QRadioButton(tr('export.cover.has_text', 'Mijn omslag bevat al tekst — afbeelding ongewijzigd gebruiken'))
        for rb in (self.cover_art_only, self.cover_has_text): rb.setObjectName('publicationRadio'); cbl.addWidget(rb)
        self.cover_box = cover_box; el.addWidget(cover_box)
        self.show_sections = QCheckBox(tr('export.sections.show', 'Sectietitels als eigen pagina opnemen')); self.show_sections.setObjectName('publicationToggle'); el.addWidget(self.show_sections)
        body.addWidget(self.epub_panel)

        self.markdown_panel = QFrame(); self.markdown_panel.setObjectName('softPanel')
        ml = QVBoxLayout(self.markdown_panel); ml.setContentsMargins(14, 12, 14, 12); ml.setSpacing(6)
        mt = QLabel(tr('export.markdown.fixed_title', 'Vast Markdown-formaat')); mt.setObjectName('sectionTitle'); ml.addWidget(mt)
        markdown_help = QLabel(tr(
            'export.markdown.fixed_help',
            'QuietWriter gebruikt altijd je vaste publicatieheader: title, date, slug, description, meta, intro, author en tags. Bij één los verhaal wordt geen overbodige hoofdstukkop toegevoegd.'
        ))
        markdown_help.setObjectName('muted'); markdown_help.setWordWrap(True); ml.addWidget(markdown_help)
        body.addWidget(self.markdown_panel)

        output_box = QFrame(); output_box.setObjectName('softPanel')
        ol = QVBoxLayout(output_box); ol.setContentsMargins(14, 12, 14, 12); ol.setSpacing(7)
        ot = QLabel(tr('export.output.title', 'Uitvoer')); ot.setObjectName('sectionTitle'); ol.addWidget(ot)
        output_row = QHBoxLayout(); self.output_label = QLabel(''); self.output_label.setObjectName('muted'); self.output_label.setWordWrap(True)
        choose_output = QPushButton(tr('export.output.choose', 'Exportmap…')); choose_output.setObjectName('secondaryButton'); choose_output.clicked.connect(self._choose_output_dir)
        output_row.addWidget(self.output_label, 1); output_row.addWidget(choose_output); ol.addLayout(output_row)
        body.addWidget(output_box)

        self.success_box = QFrame(); self.success_box.setObjectName('softPanel'); self.success_box.hide()
        sl = QVBoxLayout(self.success_box); sl.setContentsMargins(14, 12, 14, 12); sl.setSpacing(7)
        self.success_label = QLabel(''); self.success_label.setWordWrap(True); self.success_label.setTextInteractionFlags(Qt.TextSelectableByMouse); sl.addWidget(self.success_label)
        success_buttons = QHBoxLayout(); self.open_file_button = QPushButton(tr('export.open_file', 'Bestand openen')); self.open_file_button.clicked.connect(self._open_file)
        self.open_folder_button = QPushButton(tr('export.open_folder', 'Map openen')); self.open_folder_button.clicked.connect(self._open_folder)
        success_buttons.addWidget(self.open_file_button); success_buttons.addWidget(self.open_folder_button); success_buttons.addStretch(); sl.addLayout(success_buttons)
        body.addWidget(self.success_box)

        actions = QHBoxLayout(); actions.addStretch(); self.export_button = QPushButton(tr('export.action.epub', 'EPUB exporteren')); self.export_button.setObjectName('primaryButton'); self.export_button.clicked.connect(self._export); actions.addWidget(self.export_button); body.addLayout(actions); body.addStretch()

        self.format_group.buttonClicked.connect(self._format_changed)
        self.template_combo.currentIndexChanged.connect(self._options_changed)
        self.include_cover.toggled.connect(self._options_changed)
        self.cover_art_only.toggled.connect(self._options_changed)
        self.cover_has_text.toggled.connect(self._options_changed)
        self.show_sections.toggled.connect(self._options_changed)

    def _format_button(self, title: str, description: str, key: str) -> QPushButton:
        button = QPushButton(f'{title}\n{description}')
        button.setObjectName('exportFormatCard'); button.setCheckable(True); button.setMinimumHeight(76)
        button.setProperty('formatKey', key); self.format_group.addButton(button)
        return button

    @property
    def format_name(self) -> str:
        checked = self.format_group.checkedButton()
        return str(checked.property('formatKey')) if checked else 'epub'

    def set_book(self, book):
        self.book = book
        self.last_output = None; self.success_box.hide()
        if not book:
            self.setEnabled(False); return
        self.setEnabled(True)
        self.export_settings = self.store.load(book)
        fmt = self.export_settings.get('format', 'epub')
        (self.markdown_button if fmt == 'markdown' else self.epub_button).setChecked(True)
        epub = self.export_settings.get('epub', {})
        idx = self.template_combo.findData(epub.get('template', 'classic')); self.template_combo.setCurrentIndex(max(0, idx))
        self.include_cover.setChecked(bool(epub.get('include_cover', True)))
        if epub.get('cover_mode') == 'artwork_with_text': self.cover_has_text.setChecked(True)
        else: self.cover_art_only.setChecked(True)
        self.show_sections.setChecked(bool(epub.get('show_section_titles', True)))
        self.subtitle.setText(tr('export.subtitle', 'Maak een publicatiebestand van “{title}”.', title=book.title))
        self._refresh_document()
        self._refresh_output_dir()
        self._format_changed()

    def refresh(self):
        if self.book: self.set_book(self.book)

    def _settings_from_ui(self) -> dict:
        settings = dict(self.export_settings or {})
        settings['format'] = self.format_name
        settings['epub'] = dict(settings.get('epub') or {})
        settings['epub'].update({
            'template': self.template_combo.currentData() or 'classic',
            'include_cover': self.include_cover.isChecked(),
            'cover_mode': 'artwork_with_text' if self.cover_has_text.isChecked() else 'artwork_only',
            'show_section_titles': self.show_sections.isChecked(),
        })
        settings['markdown'] = {}
        return settings

    def _refresh_document(self):
        if not self.book: return
        try:
            self.document = build_export_document(self.main.library, self.book)
        except Exception:
            self.document = None
        self._refresh_summary(); self._refresh_preflight()

    def _refresh_summary(self):
        if not self.document:
            self.content_summary.setText(tr('export.content.unavailable', 'De inhoud kan nu niet worden gelezen.'))
            return
        front = len(self.document.front_matter); back = len(self.document.back_matter)
        self.content_summary.setText(tr(
            'export.content.summary',
            'Voorwerk: {front} onderdeel/onderdelen\nManuscript: {sections} sectie(s) · {chapters} hoofdstuk(ken)\nAchterwerk: {back} onderdeel/onderdelen',
            front=front, sections=len(self.document.sections), chapters=self.document.chapter_count, back=back,
        ))

    def _preflight_text(self, item) -> str:
        prefix = {'ok': '✓', 'warning': '⚠', 'error': '✕', 'info': '•'}.get(item.level, '•')
        values = {
            'title': tr('export.check.title', 'Titel: {value}', value=item.value or tr('export.check.missing', 'ontbreekt')),
            'author': tr('export.check.author', 'Auteur: {value}', value=item.value or tr('export.check.missing', 'ontbreekt')),
            'language': tr('export.check.language', 'Boektaal: {value}', value=item.value or tr('export.check.missing', 'ontbreekt')),
            'chapters': tr('export.check.chapters', '{value} hoofdstuk(ken)', value=item.value or '0'),
            'cover': tr('export.check.cover', 'Omslag: {value}', value=item.value),
            'cover_missing': tr('export.check.cover_missing', 'Geen eigen boekomslag; EPUB wordt zonder omslag gemaakt.'),
            'cover_disabled': tr('export.check.cover_disabled', 'Omslag is uitgeschakeld voor deze export.'),
            'isbn': tr('export.check.isbn', 'EPUB-ISBN: {value}', value=item.value) if item.value else tr('export.check.no_isbn', 'Geen EPUB-ISBN; boek-ID wordt als identifier gebruikt.'),
        }
        return f'{prefix} {values.get(item.key, item.key)}'

    def _refresh_preflight(self):
        if not self.document:
            self.preflight_label.setText(tr('export.check.failed', 'Exportcontrole kon niet worden uitgevoerd.'))
            self.export_button.setEnabled(False); return
        report = run_preflight(self.document, self.format_name, self._settings_from_ui())
        self.preflight_label.setText('\n'.join(self._preflight_text(item) for item in report.items))
        self.export_button.setEnabled(report.can_export and self.format_name != 'pdf')

    def _format_changed(self, *args):
        fmt = self.format_name
        self.epub_panel.setVisible(fmt == 'epub')
        self.markdown_panel.setVisible(fmt == 'markdown')
        self.export_button.setText(tr('export.action.markdown', 'Markdown exporteren') if fmt == 'markdown' else tr('export.action.epub', 'EPUB exporteren'))
        self.export_settings = self._settings_from_ui()
        if self.book: self.store.save(self.book, self.export_settings)
        self._options_changed()

    def _options_changed(self, *args):
        key = self.template_combo.currentData() or 'classic'
        template = TEMPLATES.get(key, TEMPLATES['classic'])
        self.template_help.setText(template.description_en if current_locale() == 'en' else template.description_nl)
        self.cover_box.setEnabled(self.include_cover.isChecked() and bool(self.document and self.document.cover_asset))
        if self.book:
            self.export_settings = self._settings_from_ui(); self.store.save(self.book, self.export_settings)
        self._refresh_preflight()

    def _output_dir(self) -> Path:
        raw = str(self.main.settings.value('export/output_dir', '') or '').strip()
        path = Path(raw) if raw else (Path.home() / 'Documents')
        if not path.exists(): path = Path.home()
        return path

    def _refresh_output_dir(self):
        self.output_label.setText(tr('export.output.current', 'Exportmap: {path}', path=self._output_dir()))

    def _choose_output_dir(self):
        path = QFileDialog.getExistingDirectory(self, tr('export.output.choose_title', 'Kies exportmap'), str(self._output_dir()))
        if path:
            self.main.settings.setValue('export/output_dir', path); self._refresh_output_dir()

    def _open_publication_setup(self):
        if not self.book: return
        self.main.show_editor()
        self.main.editor_page.show_publication_setup()

    def _export(self):
        if not self.book or self.format_name == 'pdf': return
        # Save any active manuscript/publication editor before capturing the snapshot.
        if self.main.editor_page.save() is False: return
        if self.main.planning_page.save_pending() is False: return
        try:
            self.document = build_export_document(self.main.library, self.book)
        except Exception as exc:
            QMessageBox.critical(self, tr('export.error.title', 'Exporteren'), tr('export.error.snapshot', 'De boeksnapshot kon niet veilig worden gemaakt.\n\n{error}', error=exc)); return
        self.export_settings = self._settings_from_ui(); self.store.save(self.book, self.export_settings)
        report = run_preflight(self.document, self.format_name, self.export_settings)
        self._refresh_preflight()
        if not report.can_export: return

        suffix = '.epub' if self.format_name == 'epub' else '.md'
        destination = self._output_dir() / f'{self.document.slug}{suffix}'
        if destination.exists() and not confirm(self, tr('export.overwrite.title', 'Bestand overschrijven'), tr('export.overwrite.text', '“{name}” bestaat al. Wil je dit bestand overschrijven?', name=destination.name)):
            return
        try:
            if self.format_name == 'epub': export_epub(self.document, destination, self.export_settings)
            else: export_markdown(self.document, destination, self.export_settings)
        except Exception as exc:
            QMessageBox.critical(self, tr('export.error.title', 'Exporteren'), tr('export.error.failed', 'Exporteren is mislukt.\n\n{error}', error=exc)); return
        self.last_output = destination
        self.success_label.setText(tr('export.success', 'Export voltooid:\n{path}', path=destination))
        self.success_box.show()
        self.main.status.showMessage(tr('export.success.short', 'Export voltooid'), 2500)

    def _open_file(self):
        if self.last_output and self.last_output.exists(): QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.last_output)))

    def _open_folder(self):
        if self.last_output: QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.last_output.parent)))
