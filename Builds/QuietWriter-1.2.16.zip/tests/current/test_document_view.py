from quietwriter.document_view import classify_block_line, parse_document


def test_document_view_classifies_current_blocks_in_one_place():
    source = 'Gewoon\n***\n## Kop\n> citaat\n- item\n1. item\n'
    view = parse_document(source)
    assert [block.kind for block in view.blocks] == [
        'paragraph', 'scene', 'heading', 'quote', 'bullet', 'numbered', 'empty'
    ]


def test_literal_unpaired_star_stays_plain_text():
    source = 'de man tikte het telefoonnummer in *31623455'
    view = parse_document(source)
    assert view.blocks[0].kind == 'paragraph'
    assert view.blocks[0].inline_spans == ()
    assert view.blocks[0].text == source


def test_inline_spans_never_pair_across_paragraph_lines():
    source = 'Prijs 5*3 euro.\nEn 2*4 meter.'
    view = parse_document(source)
    assert all(block.inline_spans == () for block in view.blocks)


def test_current_ambiguous_prose_is_reported_not_rewritten():
    source = '- Kom je mee?\n1944. Het was een koude winter.'
    view = parse_document(source)
    assert view.source == source
    assert [block.kind for block in view.blocks] == ['bullet', 'numbered']
    assert [item.code for item in view.diagnostics] == [
        'ambiguous-leading-dash', 'ambiguous-leading-number'
    ]


def test_scene_break_is_centralized_and_spaced_variant_is_not_silently_promoted():
    assert classify_block_line('***') == 'scene'
    assert classify_block_line(' * * * ') != 'scene'


def test_inline_marker_ranges_are_exposed_as_hidden_source_ranges():
    source = 'Dit is **vet** en *schuin*.'
    view = parse_document(source)
    assert view.hidden_ranges
    hidden_text = [source[a:b] for a, b in view.hidden_ranges]
    assert hidden_text.count('**') == 2
    assert hidden_text.count('*') == 2


def test_word_count_uses_semantics_not_markup_tokens():
    from quietwriter.media.markup import count_words
    source = '## Een kop\n- twee woorden\n***\n**drie** woorden\n'
    # Een kop (2) + twee woorden (2) + drie woorden (2); scene marker is structural.
    assert count_words(source) == 6


def test_pdf_docx_and_xhtml_share_block_classification(tmp_path):
    from quietwriter.exporting.markup import markdown_to_xhtml
    from quietwriter.exporting.pdf_exporter import _markdown_to_pdf_html
    source = '## Kop\n> Citaat\n- item\n1. nummer\n***\nGewoon'
    xhtml = markdown_to_xhtml(source)
    pdf = _markdown_to_pdf_html(source, {}, 600)
    for fragment in ('<h2', '<blockquote>', '<ul>', '<ol>', 'scene-break', '<p'):
        assert fragment in xhtml
        assert fragment in pdf


def test_block_style_states_uses_document_view_classification():
    from quietwriter.manuscript_markup import block_style_states
    text = '## Kop\n## Nog een'
    states = block_style_states(text, 0, len(text))
    assert states['heading'] is True
    assert states['paragraph'] is False


def test_empty_source_returns_empty_document_view():
    view = parse_document('')
    assert view.source == ''
    assert view.blocks == ()
    assert view.hidden_ranges == ()
    assert view.protected_ranges == ()
    assert view.diagnostics == ()


def test_language_tools_mask_structure_but_preserve_offsets_and_prose():
    from quietwriter.document_view import text_for_language_tools
    source = '## Kop\n- Kom je?\nDit is **vet** en *schuin*.\n***'
    masked = text_for_language_tools(source)
    assert len(masked) == len(source)
    assert 'Kop' in masked
    assert 'Kom je?' in masked
    assert 'vet' in masked and 'schuin' in masked
    assert '**' not in masked
    assert '***' not in masked


def test_ai_context_uses_semantics_not_source_markers():
    from quietwriter.document_view import text_for_ai_context
    source = '## Tussenkop\nDit is **belangrijk**.\n***\n- punt'
    context = text_for_ai_context(source)
    assert '## Tussenkop' in context
    assert 'Dit is belangrijk.' in context
    assert '[Scènebreuk]' in context
    assert '- punt' in context
    assert '**' not in context


def test_language_tools_keep_literal_unpaired_star():
    from quietwriter.document_view import text_for_language_tools
    source = 'de man tikte *31623455 in'
    assert text_for_language_tools(source) == source
