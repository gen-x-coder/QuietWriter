__version__ = '0.6.3'
APP_NAME = 'QuietWriter'
