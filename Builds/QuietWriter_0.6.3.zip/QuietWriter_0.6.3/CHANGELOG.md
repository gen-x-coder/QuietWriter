# Changelog

## 0.6.3 — Editorbasis afronding

- Interactieve hover-spellingssuggesties volledig verwijderd. De editor doet tijdens muisbewegingen geen woordenboek- of suggestiewerk meer.
- Spellingscontrole concentreert zich nu op rode onderstreping plus het stabiele rechterpaneel.
- Nieuwe functie **Altijd negeren**. Deze gebruikt `dictionaries/altijd_negeren.txt`, los van `persoonlijk.txt`.
- `Negeren`, `Alles negeren`, `Altijd negeren` en `Toevoegen aan woordenboek` hebben nu elk een duidelijk verschillende betekenis.
- Woordenboeklookup en suggesties gebruiken caches, wat herhaalde spellingsscans in grote hoofdstukken versnelt.
- Suggesties in het spellingspaneel zijn vaste compacte regels zonder scrollcontainer.
- Instellingen opgesplitst in tabs: Algemeen, Uiterlijk, Opslag, AI en Spelling.
- Spellinginstellingen leggen automatische detectie van ONLYOFFICE, LibreOffice en OpenOffice uit.
- Alle gevonden Hunspell-talen worden getoond met leesbare locale-namen.
- Woordenboeken kunnen opnieuw worden gescand, handmatig worden toegevoegd en — alleen als QuietWriter ze zelf heeft gekopieerd — weer worden verwijderd.
- Knop toegevoegd die de algemene OpenOffice Extensions-site voor woordenboeken opent.
- Woordenboeken uit Office-installaties worden altijd read-only behandeld.
- Hoofdstuk-contextmenu uitgebreid met hernoemen, dupliceren en veilig verwijderen.
- Verwijderde hoofdstukbestanden worden bewaard onder `trash/chapters/<boek-id>/`.
- Secties kunnen via contextmenu worden hernoemd en lege secties kunnen worden verwijderd.
- Editorbasis-regressietests uitgebreid naar 17 tests, waaronder 1000 willekeurige drag-and-dropbewegingen, grote spellingsscans, blijvend negeren, woordenboekbeheer en hoofdstukbewerkingen.

## 0.6.2

- Veilige custom drag-and-drop voor hoofdstukken.
- Interne tree-moves van Qt uitgeschakeld.
- Woordenboekcatalogus uitgebreid naar alle gevonden talen.
