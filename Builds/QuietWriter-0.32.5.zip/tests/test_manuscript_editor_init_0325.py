from pathlib import Path


def test_source_text_is_declared_after_manuscript_editor_init_setup():
    source = Path('quietwriter/ui/manuscript_editor.py').read_text(encoding='utf-8')
    init_pos = source.index('    def __init__(self, parent=None):')
    timer_pos = source.index('        self._format_timer = QTimer(self)', init_pos)
    highlighter_pos = source.index('        self.presentation_highlighter = ManuscriptHighlighter(self)', init_pos)
    source_text_pos = source.index('    def source_text(self) -> str:', init_pos)
    set_image_pos = source.index('    def set_image_resolver(self, resolver):', source_text_pos)

    assert init_pos < timer_pos < highlighter_pos < source_text_pos < set_image_pos
