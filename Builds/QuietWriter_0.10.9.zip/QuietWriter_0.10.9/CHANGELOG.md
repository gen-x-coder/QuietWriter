# Changelog

## 0.10.9

- Alle QuietWriter-SVG-iconen worden nu door één thema-afhankelijke renderer ingekleurd.
- De eerdere mix van `currentColor` en hardcoded grijstinten kan daardoor in donkere thema's geen zwarte of afwijkende iconen meer veroorzaken.
- Geselecteerde navigatie- en gereedschapsknoppen krijgen automatisch een accentkleurig icoon; disabled iconen volgen de disabled-themakleur.
- Themawissels verversen nu naast QSS ook bestaande iconen in beide rails, de editorbalk, het Inhoud-tabje en drag-handles.
- Het AI-chatvenster wordt bij iedere themawissel opnieuw gerenderd met de actieve themakleuren.
- Markdown-antwoorden worden als HTML-fragment ingevoegd in plaats van als genest volledig HTML-document. Daardoor lekken oude lichte/donkere documentkleuren niet meer de chat in.
- De QTextBrowser-palette wordt expliciet aangepast aan het actieve thema.

## 0.10.8

Zie eerdere release.
