# QuietWriter 0.8.3

- Verhalenbibliotheek is nu een extra bron naast selectie/hoofdstuk/sectie/boek, niet langer een exclusieve contextmodus.
- Nieuwe checkbox **Verhalenbibliotheek meenemen** in het AI-paneel.
- Duidelijke verzoeken als “oude verhalen”, “mijn verhalen” en “verhalenbibliotheek” activeren de bibliotheek automatisch en zichtbaar.
- Manuscriptcontext en gevonden oude verhalen worden gecombineerd in één AI-opdracht.
- Het AI-systeem krijgt een harde instructie om nooit verhaalnamen of bibliotheekinhoud te verzinnen wanneer geen bronnen zijn gevonden.
- Instellingen hernoemd: **Bibliothecarismodel** en **Semantisch zoekmodel (optioneel)**, met uitleg van beide functies.
- 33 automatische tests, inclusief automatische bibliotheek-intent en gecombineerde context.

# QuietWriter 0.8.1

- Startcrash opgelost: AI-chat gebruikt nu `QTextBrowser` in plaats van `QTextEdit` voor klikbare externe links.
- Alle bestaande 31 regressietests opnieuw uitgevoerd.

# Changelog

## 0.8.0 — AI-architectuur en slimme context

- AI-code opgesplitst in aparte modules onder `quietwriter/ai/`.
- Provider-onafhankelijke `AIProvider`-interface toegevoegd.
- Ollama-provider opnieuw opgebouwd bovenop deze interface.
- OpenRouter-provider toegevoegd; te activeren via Instellingen > AI.
- Hoofdmodel, snel achtergrondmodel en optioneel embeddingmodel zijn functioneel van elkaar gescheiden.
- Snel achtergrondmodel blijft standaard lokaal via Ollama, ook wanneer het hoofdmodel later via OpenRouter draait.
- AI-antwoorden worden als Markdown gerenderd: koppen, vet, cursief, lijsten en codeblokken.
- Streaming rendering wordt gebufferd/throttled zodat niet voor ieder token het volledige chatvenster opnieuw wordt opgebouwd.
- Context is zichtbaar in het AI-paneel: persona, selectie, hoofdstuk, sectie, boek en geraadpleegde verhalen.
- Een tekstselectie krijgt automatisch voorrang als AI-context.
- Gesprekken worden per boek opgeslagen in `.quietwriter/ai_chat.json`.
- Nieuwe knop `Nieuw gesprek` wist alleen de AI-conversatie van het huidige boek.
- Verhalen-RAG gebruikt metadata, tags en full-text als eerste lokale selectiestap.
- Het snelle model kan als bibliothecaris de compacte catalogus in batches lezen en relevante verhalen selecteren.
- Optionele Ollama-embeddings kunnen semantisch vergelijkbare verhalen vinden; embeddings worden persistent gecachet in `.cache/story_embeddings.db`.
- De gebruikte verhalen worden zichtbaar onder het AI-antwoord en in `Context bekijken`.
- Grote verhaalteksten en boekcontext worden begrensd om onnodig grote prompts te voorkomen.
- Denk-/reasoning-output blijft tijdelijk zichtbaar tijdens generatie en verdwijnt zodra het echte antwoord begint.
- AI schrijft nooit rechtstreeks in manuscriptbestanden.
- 5 nieuwe regressietests voor providerselectie, gesprekopslag, RAG-metadata en embeddingcache.
- Totaal: 31 automatische tests geslaagd.

## 0.7.2

- Zijpanelen robuust hersteld na inklappen.
- Hoofdstukrijen beter uitgelijnd met sleepgreep rechts.
- Rode spellinghints losgekoppeld van actieve spellingscontrole.

## 0.8.3
- Ollama HTTP-fouten tonen nu de echte foutmelding uit de response in plaats van alleen `400 Bad Request`.
- Bibliotheekcontext is conservatiever begrensd om context-overloop bij lokale modellen te voorkomen.
- Maximaal 6.000 tekens per geselecteerd oud verhaal en standaard 24.000 tekens samengestelde manuscript/bibliotheekcontext.
- De AI-laag blijft provider-onafhankelijk; deze limieten zitten in contextopbouw, niet in Ollama-specifieke functies.
