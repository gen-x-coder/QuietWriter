from __future__ import annotations

import html
import re
from pathlib import Path

from ..manuscript_markup import parse_inline_spans
from ..document_view import block_content_text, iter_content_blocks, visible_inline_text
from ..media.markup import image_reference_for_line


_TAGS = {
    'bold': ('<strong>', '</strong>'),
    'italic': ('<em>', '</em>'),
    'underline': ('<u>', '</u>'),
    'strike': ('<s>', '</s>'),
    'code': ('<code>', '</code>'),
}


def inline_to_xhtml(text: str) -> str:
    """Render QuietWriter's supported inline markup as balanced safe XHTML.

    QuietWriter deliberately allows crossed Markdown spans because formatting is
    selection-based. XML/XHTML does not: ``**one *two** three*`` cannot become
    ``<strong>one <em>two</strong> three</em>``. Render the visible source one
    character run at a time and transition between the active span stacks. When
    an outer span ends while an inner one continues, the inner tag is closed,
    the outer tag is closed, and the inner tag is reopened. The resulting XHTML
    is always properly nested while preserving the intended visual overlap.
    """
    spans = parse_inline_spans(text)
    if not spans:
        return html.escape(text, quote=False)

    marker_positions: set[int] = set()
    for span in spans:
        for a, b in span.marker_ranges:
            marker_positions.update(range(a, b))

    def active_at(position: int):
        active = [
            span for span in spans
            if span.content_start <= position < span.content_end and span.kind in _TAGS
        ]
        # Stable nesting order: spans that started first are outer. If starts are
        # equal, the one ending later is outer.
        active.sort(key=lambda span: (span.content_start, -span.content_end, span.kind))
        return active

    out: list[str] = []
    stack: list = []

    def transition(target: list):
        nonlocal stack
        common = 0
        while common < len(stack) and common < len(target) and stack[common] is target[common]:
            common += 1
        for span in reversed(stack[common:]):
            out.append(_TAGS[span.kind][1])
        for span in target[common:]:
            out.append(_TAGS[span.kind][0])
        stack = list(target)

    for i, ch in enumerate(text):
        if i in marker_positions:
            continue
        transition(active_at(i))
        out.append(html.escape(ch, quote=False))

    transition([])
    return ''.join(out)


def _image_href(reference: str, image_hrefs: dict[str, str] | None) -> str | None:
    if not image_hrefs:
        return None
    normalized = str(reference or '').replace('\\', '/')
    return image_hrefs.get(normalized) or image_hrefs.get(Path(normalized).name)


def _markdown_to_xhtml(
    text: str,
    image_hrefs: dict[str, str] | None = None,
    *,
    collect_headings: bool = False,
) -> tuple[str, list[tuple[str, str]]]:
    """Render QuietWriter manuscript semantics as XHTML.

    Block interpretation comes from DocumentView; this renderer only decides
    how those semantic blocks become XHTML.
    """
    source = (text or '').replace('\r\n', '\n').replace('\r', '\n')
    blocks: list[str] = []
    list_kind: str | None = None
    list_items: list[str] = []
    headings: list[tuple[str, str]] = []
    heading_index = 0

    def flush_list():
        nonlocal list_kind, list_items
        if list_kind and list_items:
            tag = 'ol' if list_kind == 'ol' else 'ul'
            blocks.append(f'<{tag}>' + ''.join(f'<li>{inline_to_xhtml(item)}</li>' for item in list_items) + f'</{tag}>')
        list_kind = None
        list_items = []

    for block in iter_content_blocks(source):
        if block.kind == 'image':
            flush_list()
            attrs = block.attrs or {}
            path = str(attrs.get('path') or '')
            href = _image_href(path, image_hrefs)
            alt = str(attrs.get('alt') or '')
            caption_text = str(attrs.get('caption') or '')
            if href:
                caption = f'<figcaption>{html.escape(caption_text)}</figcaption>' if caption_text else ''
                width = str(attrs.get('width') or 'medium')
                align = str(attrs.get('align') or 'center')
                classes = ['manuscript-image', f'image-width-{width}', f'image-align-{align}']
                if bool(attrs.get('wrap')):
                    classes.extend(['image-wrap', f'image-wrap-{align}'])
                blocks.append(
                    f'<figure class="{" ".join(classes)}">'
                    f'<img src="{html.escape(href, quote=True)}" alt="{html.escape(alt, quote=True)}"/>'
                    f'{caption}</figure>'
                )
            else:
                fallback = alt or caption_text or 'Afbeelding ontbreekt'
                blocks.append(f'<p class="missing-image">[{html.escape(fallback)}]</p>')
            continue

        if block.kind == 'scene':
            flush_list()
            blocks.append('<div class="scene-break" aria-label="Scene break">* * *</div>')
            continue

        content = block_content_text(block).strip()
        if block.kind == 'heading':
            flush_list()
            heading_index += 1
            heading_id = f'h-{heading_index}'
            blocks.append(f'<h2 id="{heading_id}">{inline_to_xhtml(content)}</h2>')
            if collect_headings:
                headings.append((heading_id, visible_inline_text(content).strip()))
            continue
        if block.kind == 'quote':
            flush_list()
            blocks.append(f'<blockquote><p>{inline_to_xhtml(content)}</p></blockquote>')
            continue
        if block.kind in {'bullet', 'numbered'}:
            wanted = 'ol' if block.kind == 'numbered' else 'ul'
            if list_kind and list_kind != wanted:
                flush_list()
            list_kind = wanted
            list_items.append(content)
            continue

        if list_kind:
            flush_list()
        blocks.append(f'<p>{inline_to_xhtml(block.text.strip())}</p>')

    flush_list()
    return '\n'.join(blocks), headings


def markdown_to_xhtml(text: str, image_hrefs: dict[str, str] | None = None) -> str:
    """Render QuietWriter's deliberately small manuscript Markdown subset."""
    body, _headings = _markdown_to_xhtml(text, image_hrefs, collect_headings=False)
    return body


def markdown_to_xhtml_with_headings(
    text: str, image_hrefs: dict[str, str] | None = None
) -> tuple[str, list[tuple[str, str]]]:
    """Render manuscript XHTML plus stable ``(id, label)`` h2 anchors."""
    return _markdown_to_xhtml(text, image_hrefs, collect_headings=True)
