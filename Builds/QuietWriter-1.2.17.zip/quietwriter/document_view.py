from __future__ import annotations

import re
from dataclasses import dataclass, field

from .manuscript_markup import InlineSpan, is_scene_break_line, parse_inline_spans
from .media.markup import image_reference_for_line
from .placeholders import marker_ranges


_BLOCK_NUMBERED_RE = re.compile(r'^\d+\.\s+')
_BLOCK_BULLET_RE = re.compile(r'^[-*]\s+')


@dataclass(frozen=True)
class DocumentDiagnostic:
    """Non-fatal observation about manuscript syntax.

    Diagnostics never rewrite source.  They exist so consumers can surface
    ambiguity without inventing their own parser rules.
    """

    code: str
    start: int
    end: int
    message: str


@dataclass(frozen=True)
class DocumentBlock:
    """One source block with stable source coordinates.

    QuietWriter 1.2.x is line-oriented: one physical source line represents one
    manuscript block.  The view records that fact without normalising bytes.
    """

    kind: str
    start: int
    end: int
    content_start: int
    content_end: int
    text: str
    inline_spans: tuple[InlineSpan, ...] = ()
    attrs: dict = field(default_factory=dict)


@dataclass(frozen=True)
class DocumentView:
    """Read-only semantic interpretation of one manuscript source string.

    This object is deliberately not a serializer.  Existing 1.2.x manuscript
    bytes stay authoritative; DocumentView gives editor/export/search code one
    shared interpretation of those bytes.
    """

    source: str
    blocks: tuple[DocumentBlock, ...]
    hidden_ranges: tuple[tuple[int, int], ...] = ()
    protected_ranges: tuple[tuple[int, int], ...] = ()
    diagnostics: tuple[DocumentDiagnostic, ...] = ()

    def block_at(self, position: int) -> DocumentBlock | None:
        pos = max(0, min(int(position), len(self.source)))
        for block in self.blocks:
            if block.start <= pos <= block.end:
                return block
        return None


def classify_block_line(line: str) -> str:
    """Return the canonical QuietWriter 1.2.x block kind for one source line."""
    text = line or ''
    stripped = text.strip()
    if not stripped:
        return 'empty'
    if is_scene_break_line(text):
        return 'scene'
    if image_reference_for_line(text):
        return 'image'
    if text.startswith('## '):
        return 'heading'
    if text.startswith('> '):
        return 'quote'
    if _BLOCK_BULLET_RE.match(text):
        return 'bullet'
    if _BLOCK_NUMBERED_RE.match(text):
        return 'numbered'
    return 'paragraph'


def _content_bounds(line: str, kind: str) -> tuple[int, int]:
    if kind == 'heading':
        return 3, len(line)
    if kind == 'quote':
        return 2, len(line)
    if kind == 'bullet':
        match = _BLOCK_BULLET_RE.match(line)
        return (match.end() if match else 0), len(line)
    if kind == 'numbered':
        match = _BLOCK_NUMBERED_RE.match(line)
        return (match.end() if match else 0), len(line)
    return 0, len(line)



def parse_block_line(line: str, *, source_start: int = 0) -> DocumentBlock:
    """Parse one physical manuscript line using the canonical block rules."""
    text = line or ''
    kind = classify_block_line(text)
    local_content_start, local_content_end = _content_bounds(text, kind)
    return DocumentBlock(
        kind=kind,
        start=source_start,
        end=source_start + len(text),
        content_start=source_start + local_content_start,
        content_end=source_start + local_content_end,
        text=text,
        inline_spans=tuple(parse_inline_spans(text)),
        attrs={},
    )


def parse_document(source: str) -> DocumentView:
    """Parse manuscript source into a read-only semantic view.

    Version 1 intentionally mirrors 1.2.x behaviour.  It does not silently fix
    ambiguous Markdown-like prose and does not rewrite or normalise the source.
    Inline parsing is performed per physical line so formatting never pairs
    across paragraph boundaries.
    """
    text = source or ''
    blocks: list[DocumentBlock] = []
    hidden: list[tuple[int, int]] = list(marker_ranges(text))
    protected: list[tuple[int, int]] = list(marker_ranges(text))
    diagnostics: list[DocumentDiagnostic] = []

    offset = 0
    parts = text.splitlines(keepends=True)
    if not parts and text == '':
        return DocumentView(source='', blocks=())

    for raw in parts:
        has_newline = raw.endswith('\n')
        line = raw[:-1] if has_newline else raw
        start = offset
        end = start + len(line)
        kind = classify_block_line(line)
        local_content_start, local_content_end = _content_bounds(line, kind)

        local_spans = tuple(parse_inline_spans(line))
        for span in local_spans:
            for a, b in span.marker_ranges:
                hidden.append((start + a, start + b))

        attrs: dict = {}
        if kind == 'image':
            image = image_reference_for_line(line)
            if image is not None:
                attrs = {
                    'path': image.path,
                    'alt': image.alt,
                    'caption': image.caption,
                    'width': image.width,
                    'align': image.align,
                    'wrap': image.wrap,
                }
                # The current editor renders managed images as protected cards.
                protected.append((start, end))

        # These are current 1.2.x interpretations that are especially likely to
        # collide with ordinary novel prose.  Record them; do not change bytes or
        # semantics until an explicit escaping design is introduced.
        if kind == 'bullet' and line.startswith('- '):
            diagnostics.append(DocumentDiagnostic(
                'ambiguous-leading-dash', start, end,
                'Een regel die met "- " begint wordt in 1.2.x als lijst gelezen.',
            ))
        elif kind == 'numbered':
            diagnostics.append(DocumentDiagnostic(
                'ambiguous-leading-number', start, end,
                'Een regel die met "getal. " begint wordt in 1.2.x als lijst gelezen.',
            ))

        blocks.append(DocumentBlock(
            kind=kind,
            start=start,
            end=end,
            content_start=start + local_content_start,
            content_end=start + local_content_end,
            text=line,
            inline_spans=local_spans,
            attrs=attrs,
        ))
        offset += len(raw)

    # splitlines() drops the final empty block after a trailing newline.  In the
    # editor a trailing newline means the cursor is in a new empty QTextBlock.
    if text.endswith('\n'):
        blocks.append(DocumentBlock(
            kind='empty', start=len(text), end=len(text),
            content_start=len(text), content_end=len(text), text='',
        ))

    return DocumentView(
        source=text,
        blocks=tuple(blocks),
        hidden_ranges=tuple(sorted(set(hidden))),
        protected_ranges=tuple(sorted(set(protected))),
        diagnostics=tuple(diagnostics),
    )


def iter_content_blocks(source: str):
    """Yield parsed non-empty blocks for consumers that render manuscript content."""
    for block in parse_document(source).blocks:
        if block.kind != 'empty':
            yield block


def block_content_text(block: DocumentBlock) -> str:
    """Return the source content of a block without its structural prefix.

    Inline markup remains present. Consumers that render inline formatting can
    pass the result to the shared inline parser.
    """
    return block.text[block.content_start - block.start:block.content_end - block.start]


def _mask_ranges(source: str, ranges: list[tuple[int, int]] | tuple[tuple[int, int], ...]) -> str:
    """Replace source ranges with spaces while preserving exact offsets."""
    chars = list(source or '')
    for start, end in ranges:
        for index in range(max(0, start), min(len(chars), end)):
            if chars[index] != '\n':
                chars[index] = ' '
    return ''.join(chars)


def text_for_language_tools(source: str) -> str:
    """Return offset-stable visible manuscript text for search and spelling.

    Structural prefixes, inline markup punctuation, scene-break syntax, managed
    image paths/layout metadata and Open-point markers are hidden. Natural image
    alt/caption text remains available through the existing media masking rule.
    """
    text = source or ''
    if not text:
        return ''

    # Keep the existing image contract: alt/caption remain searchable/spellable,
    # while UUID paths and layout metadata are masked. Import lazily to avoid an
    # import cycle while media.markup gradually moves onto DocumentView.
    from .media.markup import mask_image_paths
    masked = mask_image_paths(text)
    view = parse_document(text)
    ranges: list[tuple[int, int]] = list(view.hidden_ranges)
    for block in view.blocks:
        if block.kind == 'scene':
            ranges.append((block.start, block.end))
        elif block.kind in {'heading', 'quote', 'bullet', 'numbered'} and block.content_start > block.start:
            ranges.append((block.start, block.content_start))
    return _mask_ranges(masked, ranges)


def visible_inline_text(text: str, spans: tuple[InlineSpan, ...] | list[InlineSpan] | None = None) -> str:
    """Return inline source without QuietWriter formatting punctuation.

    This is a presentation helper only: literal, unpaired punctuation remains
    untouched because it is not part of a parsed span.
    """
    source = text or ''
    parsed = tuple(spans) if spans is not None else tuple(parse_inline_spans(source))
    marker_positions = {
        pos
        for span in parsed
        for a, b in span.marker_ranges
        for pos in range(a, b)
    }
    return ''.join(ch for idx, ch in enumerate(source) if idx not in marker_positions)


def visible_block_text(block: DocumentBlock) -> str:
    """Return human-visible text for one block, without technical markers."""
    if block.kind in {'empty', 'scene'}:
        return ''
    if block.kind == 'image':
        alt = str(block.attrs.get('alt') or '').strip()
        caption = str(block.attrs.get('caption') or '').strip()
        label = alt or caption or 'afbeelding'
        if alt and caption and caption.casefold() != alt.casefold():
            label = f'{alt} — {caption}'
        return f'[Afbeelding: {label}]'

    local_start = max(0, block.content_start - block.start)
    text = block.text[local_start:]
    local_spans: list[InlineSpan] = []
    for span in block.inline_spans:
        if span.open_start < local_start:
            continue
        local_spans.append(InlineSpan(
            span.kind,
            span.open_start - local_start, span.open_end - local_start,
            span.content_start - local_start, span.content_end - local_start,
            span.close_start - local_start, span.close_end - local_start,
        ))
    return visible_inline_text(text, local_spans)


def text_for_ai_context(source: str) -> str:
    """Build manuscript context from the same semantic interpretation as export.

    The result contains writer-visible prose plus compact semantic markers for
    scene breaks and images. QuietWriter's technical source syntax is omitted.
    """
    from .placeholders import strip_open_point_markers

    view = parse_document(strip_open_point_markers(source or ''))
    lines: list[str] = []
    for block in view.blocks:
        if block.kind == 'empty':
            if lines and lines[-1] != '':
                lines.append('')
            continue
        if block.kind == 'scene':
            lines.append('[Scènebreuk]')
            continue
        visible = visible_block_text(block)
        if not visible:
            continue
        if block.kind == 'heading':
            lines.append(f'## {visible}')
        elif block.kind == 'quote':
            lines.append(f'> {visible}')
        elif block.kind == 'bullet':
            lines.append(f'- {visible}')
        elif block.kind == 'numbered':
            lines.append(f'1. {visible}')
        else:
            lines.append(visible)
    return '\n'.join(lines).strip()
