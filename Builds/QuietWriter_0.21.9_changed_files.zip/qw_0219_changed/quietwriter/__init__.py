APP_NAME = "QuietWriter"
__version__ = "0.21.9"
