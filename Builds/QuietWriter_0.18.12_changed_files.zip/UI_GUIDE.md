# QuietWriter UI-richtlijnen

QuietWriter moet tijdens het schrijven zo weinig mogelijk als een interface voelen. Nieuwe schermen gebruiken daarom dezelfde visuele grammatica in plaats van per functie een nieuw patroon te introduceren.

## Paginasoorten

### Overzicht
- Titel links, één primaire actie rechts.
- Lijsten en lege toestanden blijven rustig; geen formulier tonen zolang niets is gekozen.
- Voorbeelden: Personages, Outline.

### Instellingen
- Vaste subnavigatie links.
- Scrollbare inhoud rechts; de Opslaan-actie blijft buiten de scrollviewport.
- Instellingen staan in rijen met vaste onzichtbare kolommen: naam en noodzakelijke uitleg links, bediening rechts. De control-kolom begint op iedere rij exact op dezelfde positie.
- Verwante instellingen krijgen een kleine gedempte sectiekop.
- Uitleg alleen waar gedrag of gevolgen niet vanzelf spreken.
- Complexere controls mogen binnen de rechterkolom breder zijn; korte controls blijven compact.
- Preview-elementen horen naast hun keuze wanneer dat vergelijken makkelijker maakt, niet eronder als de dropdown ze afdekt.
- Opslaan is alleen actief wanneer waarden gewijzigd zijn.

### Detail/formulier
- Vaste header, scrollbare inhoud, primaire actie onderaan wanneer commit nodig is.
- Voorbeelden: Boekdetails, gestructureerde publicatiepagina's.

### Document
- Inhoud domineert; zo weinig mogelijk chrome.
- Voorbeelden: manuscript, boeknotities, vrije publicatietekst.

### Setup-flow
- Een tijdelijke keuze- of configuratiestap mag Gereed/Annuleren gebruiken als beide acties betekenis hebben.

## Interactie

- Selecteren van tekst mag toetsenbordbewerkingen nooit blokkeren.
- Zwevende hulpmiddelen mogen geen keyboard focus van de editor stelen.
- Het standaard contextmenu blijft beschikbaar en kan QuietWriter-acties aanvullen.
- Primaire, secundaire en destructieve acties gebruiken overal dezelfde button-stijlen.
- Flyouts en tijdelijke balken sluiten zodra hun context verdwijnt.
- Icon-only knoppen krijgen altijd een tooltip; minder vanzelfsprekende symbolen krijgen beschrijvende tekst in plaats van alleen een functienaam.
- Alle toetsenbordbereikbare interactieve controls hebben een zichtbare focus-state die niet uitsluitend op kleurtekst of hover leunt. Focus mag dezelfde semantische `focus`-token gebruiken, maar mag geen layoutverspringing veroorzaken.
- Hover bevestigt dat iets interactief is; pressed geeft een korte, duidelijk afwijkende state. Checked/selected blijft zichtbaar wanneer de muis weg is en blijft onderscheidbaar van focus.
- Cursorsemantiek volgt desktopconventies: gewone knoppen, menu's en selectierijen houden de pijl; bewerkbare tekst gebruikt de tekstcursor; alleen linkachtige/inline acties gebruiken de handcursor; sleepgrepen gebruiken open/gesloten hand; resize-handles gebruiken de bijbehorende resizecursor.
- Controls die bewust geen focus mogen stelen (zoals de zwevende selectie-toolbar en de hover-delete bij scènebreuken) blijven `NoFocus`; dit is een expliciete uitzondering, geen standaard voor icon-only acties.
- Tab en Shift+Tab volgen de visuele/logische leesvolgorde. Een flyout die met het toetsenbord wordt geopend geeft focus aan zijn eerste actie en kan met Escape gesloten worden; na sluiten keert focus terug naar de opener.
- In de manuscriptruimte blijft de cursor expliciet een I-beam, ook wanneer een scènebreuk wordt gehoverd. Alleen de afzonderlijke hover-delete is een handactie.
- Tijdelijke rechterpanelen in de editor sluiten met Escape wanneer focus in het paneel staat; focus keert terug naar de railactie die het paneel opende.
- Een boom/lijst die primaire navigatie bevat moet ook zonder muis bruikbaar zijn: pijltjestoetsen verplaatsen selectie en Enter/Return activeert het geselecteerde inhoudsitem of toggelt een structurele groep wanneer openen niet van toepassing is.

## Responsive gedrag

- Beschikbare vensterruimte is leidend; content mag nooit het hoofdvenster groter afdwingen.
- Lange content zit in een scrollviewport.
- Verborgen pagina's mogen via stacks geen minimumafmetingen van het hoofdvenster bepalen.
- Controleer releases op lage laptophoogte en 100%, 125% en 150% schaal wanneer mogelijk.

## Boekenplank
- Op brede schermen gebruikt de boekenplank een gecentreerde contentas met een maximum breedte; lege ruimte wordt links en rechts gebalanceerd.
- Hero-inhoud, zoek/sorteerbediening en kaartgrid volgen dezelfde horizontale ankers.
- Boek- en nieuw-boekkaarten gebruiken exact dezelfde buitenmaat en een responsive grid; voeg geen decoratieve zijpanelen toe alleen om brede schermen te vullen.

### Navigatie- en opslagdetails
- In de Inhoud-boom vertegenwoordigt de geselecteerde rij de inhoud die werkelijk in het centrale werkvlak is geopend. Een sleepgreep of structurele kop (sectie, Voorwerk, Boek, Achterwerk) mag die selectie niet verplaatsen zolang de centrale tekstcontext niet verandert.
- Expliciete inline-acties zoals `wijzig` mogen wel naar een andere werkcontext navigeren en nemen dan de selectie/focus zichtbaar mee.
- Zoekresultaten zijn directe navigatiedoelen: één klik of Enter/Return opent de match en selecteert het gevonden bereik.
- Wanneer een documentachtig planningsscherm autosave gebruikt maar vergelijkbare schermen een zichtbare commitactie hebben, blijft een expliciete Opslaan-knop beschikbaar. De dirty-state bepaalt of die actie actief is; autosave blijft een vangnet en geen onzichtbaar afwijkend interactiepatroon.
- Applicatie-eigen dialoogknoppen (Ja/Nee, Opslaan/Annuleren) volgen de gekozen QuietWriter-locale en mogen niet terugvallen op de systeemtaal van Qt.
