#!/usr/bin/env python3
"""
QuietWriter PDF spike v2 — volledig losstaand van QuietWriter.

Doel:
- alleen de veelbelovende custom QPdfWriter/QPainter-route testen;
- titelpagina correct op precies één pagina;
- A5 boekopmaak;
- links/rechts tekstomloop;
- lang onderschrift;
- grote afbeelding vlak bij een paginagrens;
- herstel naar volledige tekstbreedte;
- tussenkop vlak bij paginagrens;
- running header + paginanummers.

Wijzigt GEEN QuietWriter-bestanden en importeert GEEN QuietWriter-modules.

Gebruik:
    python quietwriter_pdf_spike_v2.py --open
"""

from __future__ import annotations

import argparse
import html
import os
import platform
import sys
from pathlib import Path

from PySide6.QtCore import QMarginsF, QRectF, QSizeF, QUrl, Qt
from PySide6.QtGui import (
    QColor,
    QFont,
    QImage,
    QPageLayout,
    QPageSize,
    QPainter,
    QPdfWriter,
    QTextDocument,
)
from PySide6.QtWidgets import QApplication

DPI = 144
A5_W_MM, A5_H_MM = 148.0, 210.0

LEFT_MM = RIGHT_MM = 16.0
TOP_MM, BOTTOM_MM = 18.0, 17.0

HEADER_MM = 6.0
FOOTER_MM = 6.0
GAP_MM = 3.0


def mm(v: float) -> float:
    return v * DPI / 25.4


def make_test_image(path: Path) -> None:
    img = QImage(1200, 800, QImage.Format.Format_RGB32)
    img.fill(QColor("#eef1f4"))

    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.fillRect(55, 55, 1090, 690, QColor("#ffffff"))

    f = QFont("Arial", 34)
    f.setBold(True)
    p.setFont(f)
    p.setPen(QColor("#39424e"))
    p.drawText(
        QRectF(90, 100, 1020, 90),
        Qt.AlignmentFlag.AlignCenter,
        "QuietWriter PDF spike v2",
    )

    f.setPointSize(18)
    f.setBold(False)
    p.setFont(f)
    p.drawText(
        QRectF(110, 205, 980, 70),
        Qt.AlignmentFlag.AlignCenter,
        "Randgevallen voor paginering, afbeelding en tekstomloop",
    )

    boxes = [
        (120, "Links"),
        (470, "Midden"),
        (820, "Rechts"),
    ]
    for x, label in boxes:
        p.fillRect(x, 340, 260, 205, QColor("#d2d9e1"))
        p.drawRect(x, 340, 260, 205)
        p.drawText(
            QRectF(x, 340, 260, 205),
            Qt.AlignmentFlag.AlignCenter,
            label,
        )

    f.setPointSize(15)
    p.setFont(f)
    p.drawText(
        QRectF(90, 620, 1020, 60),
        Qt.AlignmentFlag.AlignCenter,
        "Controleer ook of het beeld nergens wordt afgesneden of vervormd.",
    )
    p.end()

    if not img.save(str(path), "PNG"):
        raise RuntimeError(f"Kon testafbeelding niet opslaan: {path}")


P1 = (
    "Eva legde haar tas op de stoel en keek naar het raam. Buiten schoof de avond "
    "langzaam over de straat. De huizen stonden stil onder het bleke licht van de "
    "lantaarns. Ze had deze kamer honderd keer gezien, maar vanavond leek de ruimte "
    "groter, alsof de muren een halve stap achteruit waren gezet."
)
P2 = (
    "Op tafel lag het notitieboek dat ze die ochtend dicht had achtergelaten. Nu stond "
    "het open. Niet ver, slechts twee bladzijden, maar genoeg om haar te laten "
    "stilstaan. Eerst luisterde ze. De koelkast sloeg aan, een auto reed door de straat "
    "en ergens boven haar schoof een stoel."
)
P3 = (
    "Ze streek met haar duim langs de rand van de tafel. Het hout voelde koel. Een "
    "kleine verandering kon onbeduidend zijn, hield ze zichzelf voor. Toch bleef ze "
    "staan en keek opnieuw naar de open bladzijde."
)
P4 = (
    "Pas toen ze haar jas had uitgetrokken, liep ze naar de tafel. Op de rechterpagina "
    "stond één regel die ze zich niet herinnerde. De letters waren niet vreemd, maar "
    "ook niet helemaal van haar. Dat was het ongemakkelijke eraan: ze leken bijna "
    "genoeg op haar handschrift om twijfel mogelijk te maken."
)


def para(text: str, indent: bool = True, klass: str = "") -> str:
    classes = []
    if indent:
        classes.append("indent")
    if klass:
        classes.append(klass)
    cls = f' class="{" ".join(classes)}"' if classes else ""
    return f"<p{cls}>{html.escape(text)}</p>"


def image_box(
    src: str,
    width: int,
    align: str,
    wrap: bool,
    caption: str,
    extra_class: str = "",
) -> str:
    if wrap and align in {"left", "right"}:
        if align == "left":
            margin = "4px 14px 9px 0"
        else:
            margin = "4px 0 9px 14px"
        style = f"float:{align}; width:{width}px; margin:{margin};"
    else:
        if align == "left":
            margin = "6px auto 12px 0"
        elif align == "right":
            margin = "6px 0 12px auto"
        else:
            margin = "8px auto 12px auto"
        style = f"width:{width}px; margin:{margin};"

    cls = f' class="{extra_class}"' if extra_class else ""
    return (
        f'<table{cls} cellspacing="0" cellpadding="0" style="{style}">'
        f'<tr><td><img src="{src}" width="{width}" /></td></tr>'
        f'<tr><td><p class="caption">{html.escape(caption)}</p></td></tr>'
        "</table>"
    )


def build_html(body_width: float) -> str:
    small = int(body_width * 0.30)
    medium = int(body_width * 0.48)
    large = int(body_width * 0.70)
    almost_full = int(body_width * 0.88)

    long_caption = (
        "Dit is bewust een veel langer onderschrift. Het moet over meerdere regels kunnen "
        "lopen, volledig onder de afbeelding blijven staan en mag niet los op een volgende "
        "pagina terechtkomen."
    )

    parts = [f"""
<html>
<head>
<style>
body {{
    font-family: Georgia, "Times New Roman", serif;
    font-size: 10.8pt;
    color: #202020;
}}
h1 {{
    font-size: 22pt;
    font-weight: normal;
    text-align: center;
    margin: 0 0 20px 0;
}}
h2 {{
    font-size: 16pt;
    font-weight: normal;
    margin: 0 0 18px 0;
}}
h3 {{
    font-size: 12.5pt;
    font-weight: bold;
    margin: 14px 0 7px 0;
    page-break-after: avoid;
}}
p {{
    margin: 0 0 6px 0;
    line-height: 135%;
    text-align: justify;
}}
p.indent {{
    text-indent: 1.25em;
}}
p.caption {{
    font-family: Arial, sans-serif;
    font-size: 8pt;
    color: #555;
    text-align: center;
    text-indent: 0;
    margin: 4px 2px 2px 2px;
}}
p.scene {{
    text-align: center;
    letter-spacing: .4em;
    margin: 15px 0;
}}
.titlepage {{
    text-align: center;
    margin-top: 150px;
}}
.chapter {{
    page-break-before: always;
}}
.avoid-split {{
    page-break-inside: avoid;
}}
table {{
    border-collapse: collapse;
}}
td {{
    padding: 0;
}}
</style>
</head>
<body>
"""]

    # TITELPAGINA: bewust GEEN page-break-after.
    # Het eerste hoofdstuk veroorzaakt precies één page-break-before.
    parts += [
        '<div class="titlepage">',
        "<h1>QuietWriter PDF spike v2</h1>",
        para("A5 · custom Qt paginering · randgevallen", False),
        para("De titelpagina hoort volledig op één pagina te staan.", False),
        "</div>",
    ]

    # HOOFDSTUK 1
    parts += [
        '<div class="chapter">',
        "<h2>Hoofdstuk 1 — Basis en gecentreerd beeld</h2>",
        para(P1, False),
        para(P2),
        image_box(
            "qw-spike://image",
            large,
            "center",
            False,
            "Groot · midden · geen omloop",
        ),
        para(P3),
        '<p class="scene">* * *</p>',
        para(P4, False),
        "</div>",
    ]

    # HOOFDSTUK 2: links
    parts += [
        '<div class="chapter">',
        "<h2>Hoofdstuk 2 — Links met omloop</h2>",
        image_box(
            "qw-spike://image",
            small,
            "left",
            True,
            "Klein · links · tekstomloop",
        ),
    ]
    for i in range(8):
        parts.append(para((P1, P2, P3, P4)[i % 4], i != 0))
    parts += [
        '<p class="scene">* * *</p>',
        para(
            "Na de scènebreuk moet de tekst weer over de volledige zetbreedte lopen. "
            "De eerdere float mag de rest van het hoofdstuk niet blijven beïnvloeden.",
            False,
        ),
        "</div>",
    ]

    # HOOFDSTUK 3: rechts + lang onderschrift
    parts += [
        '<div class="chapter">',
        "<h2>Hoofdstuk 3 — Rechts met lang onderschrift</h2>",
        image_box(
            "qw-spike://image",
            medium,
            "right",
            True,
            long_caption,
        ),
    ]
    for i in range(8):
        parts.append(para((P2, P3, P1, P4)[i % 4], i != 0))
    parts += ["</div>"]

    # HOOFDSTUK 4: afbeelding vlak bij paginagrens.
    # We vullen eerst bewust veel tekst en plaatsen dan een grote table.
    parts += [
        '<div class="chapter">',
        "<h2>Hoofdstuk 4 — Grote afbeelding bij paginagrens</h2>",
    ]
    for i in range(7):
        parts.append(para((P1, P2, P3, P4)[i % 4], i != 0))

    parts += [
        image_box(
            "qw-spike://image",
            almost_full,
            "center",
            False,
            long_caption,
            extra_class="avoid-split",
        ),
        para(
            "Deze alinea hoort pas na de volledige afbeelding en het volledige onderschrift "
            "te verschijnen. De afbeelding mag niet worden afgesneden en het onderschrift "
            "mag niet los op een andere pagina terechtkomen.",
            False,
        ),
        "</div>",
    ]

    # HOOFDSTUK 5: tussenkop bij paginagrens.
    parts += [
        '<div class="chapter">',
        "<h2>Hoofdstuk 5 — Tussenkop aan paginarand</h2>",
    ]
    for i in range(8):
        parts.append(para((P1, P3, P2, P4)[i % 4], i != 0))

    parts += [
        "<h3>Deze tussenkop hoort niet verweesd onderaan te staan</h3>",
        para(
            "Minimaal deze eerste alinea hoort visueel bij de tussenkop. Als Qt de "
            "page-break-after: avoid-regel respecteert, verhuist de kop zo nodig mee naar "
            "de volgende pagina.",
            False,
        ),
        para(P1),
        para(P2),
        "</div>",
        "</body></html>",
    ]

    return "".join(parts)


def make_writer(path: Path) -> QPdfWriter:
    writer = QPdfWriter(str(path))
    writer.setResolution(DPI)
    writer.setPageSize(QPageSize(QPageSize.PageSizeId.A5))
    writer.setPageMargins(
        QMarginsF(0, 0, 0, 0),
        QPageLayout.Unit.Millimeter,
    )
    writer.setTitle("QuietWriter PDF spike v2")
    writer.setCreator("QuietWriter PDF spike v2")
    return writer


def make_document(image_path: Path, page_size: QSizeF) -> QTextDocument:
    doc = QTextDocument()
    doc.setDefaultFont(QFont("Georgia", 11))
    doc.setPageSize(page_size)

    image = QImage(str(image_path))
    if image.isNull():
        raise RuntimeError(f"Kon testafbeelding niet laden: {image_path}")

    doc.addResource(
        QTextDocument.ResourceType.ImageResource,
        QUrl("qw-spike://image"),
        image,
    )
    doc.setHtml(build_html(page_size.width()))
    return doc


def export_custom_pdf(path: Path, image_path: Path) -> int:
    writer = make_writer(path)

    page_w = mm(A5_W_MM)
    page_h = mm(A5_H_MM)

    left = mm(LEFT_MM)
    right = mm(RIGHT_MM)
    top = mm(TOP_MM)
    bottom = mm(BOTTOM_MM)
    header_h = mm(HEADER_MM)
    footer_h = mm(FOOTER_MM)
    gap = mm(GAP_MM)

    body_x = left
    body_y = top + header_h + gap
    body_w = page_w - left - right
    body_h = page_h - body_y - bottom - footer_h - gap

    doc = make_document(image_path, QSizeF(body_w, body_h))
    count = int(doc.pageCount())

    painter = QPainter(writer)
    if not painter.isActive():
        raise RuntimeError("QPainter kon QPdfWriter niet openen.")

    header_font = QFont("Arial", 8)
    footer_font = QFont("Arial", 8)
    meta_color = QColor("#666666")

    for i in range(count):
        if i:
            writer.newPage()

        # Body
        painter.save()
        painter.setClipRect(QRectF(body_x, body_y, body_w, body_h))
        painter.translate(body_x, body_y - i * body_h)
        doc.drawContents(
            painter,
            QRectF(0, i * body_h, body_w, body_h),
        )
        painter.restore()

        # Titelpagina: geen running header/footer/paginanummer.
        if i == 0:
            continue

        painter.save()
        painter.setPen(meta_color)

        painter.setFont(header_font)
        painter.drawText(
            QRectF(left, top, body_w, header_h),
            Qt.AlignmentFlag.AlignCenter,
            "QuietWriter PDF spike v2",
        )

        painter.setFont(footer_font)
        painter.drawText(
            QRectF(left, page_h - bottom - footer_h, body_w, footer_h),
            Qt.AlignmentFlag.AlignCenter,
            str(i),  # titelpagina niet meetellen in zichtbare nummering
        )

        painter.restore()

    painter.end()
    return count


def write_report(path: Path, page_count: int) -> None:
    from PySide6 import __version__ as pyside_version
    from PySide6.QtCore import qVersion

    report = f"""QuietWriter PDF spike v2
========================

Dit script wijzigt niets aan QuietWriter.

Technische omgeving
-------------------
Python:   {platform.python_version()}
PySide6:  {pyside_version}
Qt:       {qVersion()}
Platform: {platform.platform()}

Uitvoer
------
02_custom_paged_v2.pdf: {page_count} pagina('s)

Controlelijst
-------------
1. Titelpagina staat volledig op precies één pagina.
2. Titelpagina heeft géén running header en géén paginanummer.
3. Hoofdstuk 1 begint op de volgende pagina.
4. Running header en paginanummers beginnen vanaf hoofdstuk 1.
5. Gecentreerde afbeelding is volledig zichtbaar en niet vervormd.
6. Linker afbeelding: tekst loopt er rechts omheen.
7. Rechter afbeelding: tekst loopt er links omheen.
8. Lang onderschrift blijft bij de bijbehorende afbeelding.
9. Na een float keert tekst terug naar volle zetbreedte.
10. Grote afbeelding vlak bij paginagrens wordt niet afgesneden.
11. Lang onderschrift bij die grote afbeelding raakt niet los.
12. Tussenkop vlak bij paginagrens staat niet verweesd onderaan.
13. Geen overlap, afgekapt beeld of onverwachte lege pagina's.

Interpretatie
-------------
Als vooral punten 1, 8, 10, 11 en 12 goed gaan, is de Qt-route sterk genoeg
om als basis voor QuietWriter PDF-export te overwegen.
"""
    path.write_text(report, encoding="utf-8")


def open_result(path: Path) -> None:
    try:
        if sys.platform.startswith("win"):
            os.startfile(str(path))  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            import subprocess
            subprocess.Popen(["open", str(path)])
        else:
            import subprocess
            subprocess.Popen(["xdg-open", str(path)])
    except Exception as exc:
        print(f"Kon PDF niet automatisch openen: {exc}")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Losstaande QuietWriter PDF spike v2."
    )
    parser.add_argument(
        "--output",
        default="pdf_spike_v2_output",
        help="Uitvoermap (standaard: pdf_spike_v2_output)",
    )
    parser.add_argument(
        "--open",
        action="store_true",
        help="Open de PDF na genereren.",
    )
    args = parser.parse_args()

    app = QApplication.instance() or QApplication(sys.argv)

    out = Path(args.output).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)

    image_path = out / "spike_test_image_v2.png"
    pdf_path = out / "02_custom_paged_v2.pdf"
    report_path = out / "pdf_spike_v2_report.txt"

    print("QuietWriter PDF spike v2")
    print("========================")
    print(f"Uitvoer: {out}")
    print()

    print("1/3 Testafbeelding maken...")
    make_test_image(image_path)

    print("2/3 Custom PDF maken...")
    pages = export_custom_pdf(pdf_path, image_path)

    print("3/3 Rapport schrijven...")
    write_report(report_path, pages)

    print()
    print("Klaar.")
    print(f"- {pdf_path.name} ({pages} pagina's)")
    print(f"- {image_path.name}")
    print(f"- {report_path.name}")

    if args.open:
        open_result(pdf_path)

    _ = app
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
