QuietWriter PDF Spike v2
========================

Deze tweede spike is volledig losstaand van QuietWriter.
Er wordt geen QuietWriter-code geïmporteerd of gewijzigd.

Bestanden:
- quietwriter_pdf_spike_v2.py

Start:
    python quietwriter_pdf_spike_v2.py --open

Uitvoer:
    pdf_spike_v2_output/
        02_custom_paged_v2.pdf
        spike_test_image_v2.png
        pdf_spike_v2_report.txt

Deze ronde test:
- titelpagina op exact één pagina;
- running header/paginanummers;
- links/rechts tekstomloop;
- lang onderschrift;
- grote afbeelding vlak bij paginagrens;
- tussenkop vlak bij paginagrens;
- geen afkapping/overlap.

Upload daarna bij voorkeur 02_custom_paged_v2.pdf.
