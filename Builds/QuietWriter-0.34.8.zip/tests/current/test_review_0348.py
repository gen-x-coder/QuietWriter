from pathlib import Path


def test_chapter_planning_is_explicit_opt_in_in_ai_panel_source():
    source = Path("quietwriter/ai/ui.py").read_text(encoding="utf-8")
    assert "value('ai_use_chapter_planning', False, bool)" in source
    assert "self.main.settings.contains('ai_use_chapter_planning')" in source
    assert "Dit staat standaard uit" in source
    assert "Bij een externe AI-provider verlaten deze gegevens je computer." in source


def test_context_budget_is_deferred_not_silently_truncated():
    source = Path("quietwriter/ai/ui.py").read_text(encoding="utf-8")
    assert "def _active_chapter_planning_text" in source
    assert "preview.text" in source
    assert "[:" not in source[source.index("def _active_chapter_planning_text"):source.index("def refresh_context_summary") ]
