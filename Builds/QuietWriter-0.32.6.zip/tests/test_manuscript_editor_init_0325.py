import ast
from pathlib import Path


def test_source_text_is_declared_after_manuscript_editor_init_setup():
    source = Path('quietwriter/ui/manuscript_editor.py').read_text(encoding='utf-8')
    init_pos = source.index('    def __init__(self, parent=None):')
    timer_pos = source.index('        self._format_timer = QTimer(self)', init_pos)
    highlighter_pos = source.index('        self.presentation_highlighter = ManuscriptHighlighter(self)', init_pos)
    source_text_pos = source.index('    def source_text(self) -> str:', init_pos)
    set_image_pos = source.index('    def set_image_resolver(self, resolver):', source_text_pos)

    assert init_pos < timer_pos < highlighter_pos < source_text_pos < set_image_pos


def test_manuscript_editor_init_has_no_nested_method_or_early_return():
    source = Path('quietwriter/ui/manuscript_editor.py').read_text(encoding='utf-8')
    tree = ast.parse(source)
    cls = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'ManuscriptEditor')
    init = next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == '__init__')

    nested_defs = [
        node for statement in init.body for node in ast.walk(statement)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node is not init
    ]
    returns = [node for statement in init.body for node in ast.walk(statement) if isinstance(node, ast.Return)]
    assert nested_defs == []
    assert returns == []
