import ast
from pathlib import Path


def test_no_unreachable_top_level_statements_after_return_or_raise():
    """Catch the 0.32.4 class of valid-Python but unreachable function code."""
    failures = []
    for path in Path('quietwriter').rglob('*.py'):
        source = path.read_text(encoding='utf-8')
        tree = ast.parse(source, filename=str(path))
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for index, statement in enumerate(node.body[:-1]):
                if isinstance(statement, (ast.Return, ast.Raise)):
                    next_statement = node.body[index + 1]
                    failures.append(
                        f'{path}:{node.lineno} {node.name}: '
                        f'{type(statement).__name__} on line {statement.lineno} '
                        f'is followed by unreachable code on line {next_statement.lineno}'
                    )
    assert failures == [], '\n'.join(failures)
