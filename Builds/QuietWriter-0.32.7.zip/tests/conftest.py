import importlib.util

import pytest


@pytest.fixture(autouse=True)
def fail_on_unexpected_qmessagebox(monkeypatch, request):
    """Make unexpected Qt message boxes fail fast instead of hanging tests.

    Tests that intentionally exercise a dialog can simply monkeypatch the
    relevant QMessageBox method again in the test body/fixture.
    """
    if importlib.util.find_spec('PySide6') is None:
        yield
        return

    from PySide6.QtWidgets import QMessageBox

    def unexpected(kind):
        def fail(*args, **kwargs):
            title = ''
            if kind == 'exec':
                box = args[0] if args else None
                try:
                    title = box.windowTitle() if box is not None else ''
                except Exception:
                    title = ''
            elif len(args) > 1:
                title = args[1]
            raise AssertionError(f'Unexpected QMessageBox.{kind}: {title}')
        return fail

    monkeypatch.setattr(QMessageBox, 'information', unexpected('information'))
    monkeypatch.setattr(QMessageBox, 'warning', unexpected('warning'))
    monkeypatch.setattr(QMessageBox, 'critical', unexpected('critical'))
    monkeypatch.setattr(QMessageBox, 'question', unexpected('question'))
    monkeypatch.setattr(QMessageBox, 'exec', unexpected('exec'))
    yield
