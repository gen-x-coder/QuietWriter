# QuietWriter 1.2.13

Kleine afrondende polishronde voor Open punten.

- Na **Open punt afronden** blijft de lijst op dezelfde plek staan, ook als het geselecteerde punt verdwijnt.
- Na wisselen van boek begint de Open punten-lijst bovenaan in het nieuwe boek.
- Regressietests bewaken beide scenario's met lange lijsten.

Geen wijzigingen aan opslagformaat, export of Open-puntmarkeringen.
