"""Publication structure UI."""
