import os
from pathlib import Path

import pytest

pytest.importorskip('PySide6')
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

from PySide6.QtCore import QSettings
from PySide6.QtGui import QTextCursor
from PySide6.QtWidgets import QApplication, QMessageBox

from quietwriter.fragment_store import FragmentStore
from quietwriter.storage import Library
from quietwriter.ui.main_window import MainWindow


@pytest.fixture(scope='module')
def app():
    return QApplication.instance() or QApplication([])


def _settings(path: Path):
    settings = QSettings(str(path), QSettings.IniFormat)
    settings.setValue('spell_enabled', False)
    settings.setValue('ai_enabled', False)
    settings.setValue('advanced_options', False)
    return settings


def _window_with_book(tmp_path: Path, source: str):
    workspace = tmp_path / 'workspace'
    lib = Library(workspace)
    book = lib.create_book('Testboek')
    chapter = next(c for sec in book.sections for c in sec.chapters)
    chapter_path = Path(book.path) / chapter.file
    chapter_path.write_text(source, encoding='utf-8')
    book = lib.load_book(book.path)
    window = MainWindow(_settings(tmp_path / 'settings.ini'), lib, [])
    window.open_book(book)
    return window, chapter_path


def test_copy_selection_runs_real_qt_path_and_does_not_modify_manuscript(app, tmp_path):
    source = 'Voor **vet woord** na.\n'
    window, chapter_path = _window_with_book(tmp_path, source)
    try:
        before = chapter_path.read_bytes()
        editor = window.editor_page.editor
        start = source.index('vet woord')
        cursor = editor.textCursor()
        cursor.setPosition(start)
        cursor.setPosition(start + len('vet woord'), QTextCursor.KeepAnchor)
        editor.setTextCursor(cursor)

        assert window.editor_page.copy_selection_to_darlings() is True
        fragments = window.darlings_page.store.list_fragments()
        assert len(fragments) == 1
        assert fragments[0].text == '**vet woord**'
        assert fragments[0].source_book_title == 'Testboek'
        assert chapter_path.read_bytes() == before
    finally:
        window.close()


def test_search_saves_pending_metadata_before_refresh(app, tmp_path):
    window, _chapter_path = _window_with_book(tmp_path, 'Tekst.\n')
    try:
        fragment = window.darlings_page.store.create('Fragmenttekst')
        window.darlings_page.add_fragment(fragment)
        window.darlings_page.title_edit.setText('Mijn lokale titel')
        assert window.darlings_page.dirty is True

        # textChanged invokes refresh(); the pending title must be committed first.
        window.darlings_page.search.setText('bestaat-niet')
        saved = window.darlings_page.store.load(fragment.id)
        assert saved.title == 'Mijn lokale titel'
    finally:
        window.close()


def test_external_change_keeps_local_fields_and_allows_conscious_second_save(app, tmp_path, monkeypatch):
    window, _chapter_path = _window_with_book(tmp_path, 'Tekst.\n')
    try:
        page = window.darlings_page
        fragment = page.store.create('Fragmenttekst', title='Origineel')
        page.add_fragment(fragment)
        page.note_edit.setPlainText('Mijn lokale notitie')
        assert page.dirty is True

        other = FragmentStore(page.store.root)
        disk = other.load(fragment.id)
        other.update_metadata(fragment.id, expected_revision=disk.revision, title='Titel van laptop')

        monkeypatch.setattr(QMessageBox, 'warning', lambda *args, **kwargs: QMessageBox.Ok)
        assert page.save_metadata() is False
        assert page.note_edit.toPlainText() == 'Mijn lokale notitie'
        assert page.dirty is True
        assert page._loaded_fragment.title == 'Titel van laptop'

        # A second click is an explicit choice to save the still-visible local fields.
        assert page.save_metadata() is True
        assert page.store.load(fragment.id).note == 'Mijn lokale notitie'
    finally:
        window.close()


def test_insert_at_cursor_keeps_fragment_and_is_one_undo_step(app, tmp_path):
    source = 'Voor na.\n'
    window, _chapter_path = _window_with_book(tmp_path, source)
    try:
        fragment = window.darlings_page.store.create('**bewaarde tekst**')
        page = window.darlings_page
        page.add_fragment(fragment)

        editor = window.editor_page.editor
        cursor = editor.textCursor()
        cursor.setPosition(source.index('na.'))
        editor.setTextCursor(cursor)
        before = editor.source_text()

        assert page.insert_at_cursor() is True
        assert editor.source_text() == 'Voor **bewaarde tekst**na.\n'
        assert len(page.store.list_fragments()) == 1

        editor.undo()
        assert editor.source_text() == before
    finally:
        window.close()


def test_insert_at_cursor_does_not_replace_existing_selection(app, tmp_path):
    source = 'Voor SELECTIE na.\n'
    window, _chapter_path = _window_with_book(tmp_path, source)
    try:
        fragment = window.darlings_page.store.create('*fragment*')
        window.darlings_page.add_fragment(fragment)
        editor = window.editor_page.editor
        cursor = editor.textCursor()
        start = source.index('SELECTIE')
        cursor.setPosition(start)
        cursor.setPosition(start + len('SELECTIE'), QTextCursor.KeepAnchor)
        editor.setTextCursor(cursor)
        active_end = cursor.position()

        assert window.darlings_page.insert_at_cursor() is True
        expected = source[:active_end] + '*fragment*' + source[active_end:]
        assert editor.source_text() == expected
        assert 'SELECTIE' in editor.source_text()
    finally:
        window.close()


def test_external_conflict_can_choose_disk_without_later_silent_overwrite(app, tmp_path, monkeypatch):
    window, _chapter_path = _window_with_book(tmp_path, 'Tekst.\n')
    try:
        page = window.darlings_page
        fragment = page.store.create('Fragmenttekst', title='Origineel', note='oud')
        page.add_fragment(fragment)
        page.title_edit.setText('LOKAAL')
        page.note_edit.setPlainText('lokale notitie')

        other = FragmentStore(page.store.root)
        disk = other.load(fragment.id)
        other.update_metadata(
            fragment.id, expected_revision=disk.revision,
            title='LAPTOP', note='notitie laptop', tags=['extern'],
        )
        monkeypatch.setattr(page, '_choose_external_conflict', lambda current: 'disk')

        assert page.save_metadata() is True
        assert page.title_edit.text() == 'LAPTOP'
        assert page.note_edit.toPlainText() == 'notitie laptop'
        assert page.dirty is False

        # Subsequent silent save routes have nothing pending and cannot overwrite it.
        page.search.setText('x')
        saved = page.store.load(fragment.id)
        assert saved.title == 'LAPTOP'
        assert saved.note == 'notitie laptop'
        assert saved.tags == ['extern']
    finally:
        window.close()


def test_external_conflict_can_explicitly_keep_local_values(app, tmp_path, monkeypatch):
    window, _chapter_path = _window_with_book(tmp_path, 'Tekst.\n')
    try:
        page = window.darlings_page
        fragment = page.store.create('Fragmenttekst', title='Origineel', note='oud')
        page.add_fragment(fragment)
        page.title_edit.setText('LOKAAL')
        page.note_edit.setPlainText('lokale notitie')
        page.tags_edit.setText('mijn-tag')

        other = FragmentStore(page.store.root)
        disk = other.load(fragment.id)
        other.update_metadata(
            fragment.id, expected_revision=disk.revision,
            title='LAPTOP', note='notitie laptop', tags=['extern'],
        )
        monkeypatch.setattr(page, '_choose_external_conflict', lambda current: 'local')

        assert page.save_metadata() is True
        saved = page.store.load(fragment.id)
        assert saved.title == 'LOKAAL'
        assert saved.note == 'lokale notitie'
        assert saved.tags == ['mijn-tag']
        assert page.dirty is False
    finally:
        window.close()
