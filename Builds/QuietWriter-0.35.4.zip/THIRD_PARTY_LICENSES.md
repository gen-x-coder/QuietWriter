# Third-party licenses

QuietWriter depends on third-party software and assets. This inventory is intended for the Windows 1.0 release and must be checked again when the portable build is assembled.

## Runtime software

- **Python** — Python Software Foundation License. Source: https://www.python.org/psf/license/
- **PySide6 / Qt for Python** — distributed by The Qt Company under applicable Qt for Python licensing terms, including LGPL/GPL options for the Community Edition. Source and license information: https://doc.qt.io/qtforpython-6/licenses.html
- **Requests** — Apache License 2.0. Source: https://github.com/psf/requests
- **spylls** — MIT License. Source: https://github.com/zverok/spylls

## Bundled writing fonts

The following fonts are licensed under the **SIL Open Font License 1.1**. Their complete OFL text is shipped in each font folder under `resources/fonts/<font>/OFL.txt`.

- Merriweather — The Merriweather Project Authors
- Literata — The Literata Project Authors
- Source Serif 4 — Adobe / Source Serif project
- EB Garamond — The EB Garamond Project Authors

## Hunspell dictionaries

QuietWriter can use Hunspell-compatible dictionaries for spelling. **No Hunspell dictionary data is currently redistributed in the source package.** Before a Windows portable build bundles any `.dic`/`.aff` files, each dictionary's exact license and attribution must be added here and its license file must be shipped alongside it. This is a release gate for 0.36 packaging.

## Development/test-only dependencies

Some tools used by CI and tests (for example pytest and PyYAML) are not necessarily redistributed with the application. Their licenses still apply to those tools themselves, but they only need to be included in the end-user third-party notice if they are actually bundled in the release.
