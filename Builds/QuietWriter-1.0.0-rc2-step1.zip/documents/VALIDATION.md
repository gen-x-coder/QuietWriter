# QuietWriter — validatiestatus 1.0.0-rc2 clean source

Deze pagina maakt controleerbaar waarop uitspraken als "groen" zijn gebaseerd.

## Reviewronde 56 — 2 oktober 2026

Omgeving van de onafhankelijke lokale review:
- Python 3.12.3
- PySide6 6.11.2

Resultaten vóór de laatste overdraagbaarheidsfixes:
- `tools/check_undefined_names.py`: OK
- actieve suite: 433 geslaagd + 284 subtests
- `pytest -m qt`: 80 geslaagd
- app koude start: OK
- `python main.py --smoke-test`: exitcode 0
- release staging + Windows version-info: OK
- oude 0.36.10 legacy-suite tegen rc2-code: 450/451; de enige fout zocht het bewust verwijderde oude `documents/dev/UI_GUIDE.md` en was geen productgedrag
- corrupte zoekcache: succesvol verwijderd en herbouwd
- brandinggenerator: `.ico` en drie in-app SVG's byte-identiek gereproduceerd

De review bevestigde dat de codewijzigingen voor de zoekcache en het expliciet sluiten van de zoekindex correct werken.

## Fixes naar aanleiding van reviewronde 56

De clean-source set is daarna aangevuld/gecorrigeerd met:
- `.github/workflows/tests.yml` en `build-windows.yml` terug in de bron;
- volledige SIL OFL 1.1-teksten voor alle vier gebundelde fonts;
- versieneutrale `LEESMIJ.txt`;
- tekstbreedte-combobox verbreed naar 160 px zodat ook Extra breed / Extra wide volledig zichtbaar zijn;
- actuele `branding/README.md` en `shapely` in `requirements-dev.txt`;
- `DEVELOPER_REFERENCE.md` met runtime-, opslag- en module-naslag;
- `UI_REFERENCE.md` met de concrete UI-specificaties die bij de eerste consolidatie te sterk waren samengevat;
- neutralere pytest-markertekst;
- release-stagingtest gebruikt een tijdelijke map via `QUIETWRITER_STAGE_DIR`;
- volledige fontlicentie-inhoud wordt nu met een test bewaakt.

## Interpretatie

"Groen" betekent dus niet dat alle toekomstige praktijksituaties bewezen zijn. Voor stabiele 1.0 blijven de handmatige/praktische checks uit `ROADMAP_AND_IDEAS.md` gelden, waaronder clean Windows, SmartScreen, meerdere DPI-schalen, echte providers, oude/grote boeken en langere dagelijkse schrijfsessies.
