# Technisch ontwerp 0.34.0 — Planning tijdens schrijven

## Doel
Planning dichter bij het manuscript brengen zonder een tweede bron van waarheid te introduceren. De eerste stap toont alleen bestaande Planning-data voor het actieve hoofdstuk.

## Eerste slice
- Een inklapbaar blok **In dit hoofdstuk** in de editoromgeving.
- Alleen-lezen overzicht van scènes die al aan het actieve hoofdstuk gekoppeld zijn.
- Relevante personages uitsluitend afgeleid uit die scènes / bestaande Planning-relaties.
- Acties leiden naar Planning om te bewerken; het blok zelf schrijft niets.
- Als er geen koppelingen zijn: rustige lege staat, geen automatische herkenning.

## Architectuurregels
- PlanningStore blijft de enige persistente bron. Geen kopieën in hoofdstukmetadata.
- Het blok krijgt een pure view-modelbuilder op basis van `active_book`, `chapter_id`, scènes en personages.
- Wisselen van hoofdstuk of centrale book-adopt ververst het viewmodel; geen polling en geen writes.
- Integriteit controleert in een latere 0.34-slice verweesde Planning-relaties.
- AI-context wordt in de eerste slice nog niet automatisch uitgebreid; eerst zichtbaar maken, daarna pas expliciet toevoegen.

## Reviewpunten voor de eerste implementatie
- Geen wijziging aan Planning-bestandsformaten.
- Geen autosave vanuit het nieuwe blok.
- Geen duplicatie van scène/personagevelden.
- Lage schermhoogte en focusvolgorde blijven bruikbaar.
- Lege en corrupte Planning-data blokkeren de manuscripteditor niet.
