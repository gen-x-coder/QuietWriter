# QuietWriter changelog

## 0.10.8

- Linkernavigatie is nu exclusief: een reeds geselecteerde pagina blijft geselecteerd wanneer dezelfde knop opnieuw wordt aangeklikt. Herhaalde klikken geven geen visuele toggle-feedback en voeren geen onnodige refresh uit.
- Het Inhoud-tabje wordt nu pas na de splitter opgebouwd zodat het gegarandeerd boven de hoofdstukken-/editorlaag staat.
- Het Inhoud-tabje heeft expliciet rechte linkerhoeken en ronde rechterhoeken, zodat het ingeklapt visueel in de linker rand doorloopt in plaats van als losse capsule te ogen.
- Extra regressietests voor navigatieselectie en stacking/styling van het Inhoud-tabje.

## 0.10.7

- Herstelt het uitklappen van de linker navigatierail. Een typefout maakte van de Qt-animatiegroep een Python-tuple, waardoor de labels wel verschenen maar de rail zelf op 64 px bleef en de tekst werd afgeknipt.
- Het Inhoud-tabje is opnieuw opgebouwd als overlay op `EditorPage` in plaats van als child van het middelste splitterpaneel. Daardoor kan het niet meer achter/onder splitter-widgets verdwijnen.
- Het tabje volgt nu dynamisch de grens van het Inhoud-paneel, ook na resizen, slepen van splitters en tonen/verbergen van Inhoud.
- Regressietests toegevoegd voor beide UI-problemen.

# Changelog

## 0.10.6

- Schrijflettertypen volledig opnieuw opgebouwd als zelfstandige typografielaag.
- Lettertypefamilie en tekstgrootte zijn nu volledig onafhankelijke instellingen.
- Instellingen toont dynamisch alle op de computer beschikbare fontfamilies; nieuwe geïnstalleerde fonts vereisen geen codewijziging.
- Het globale QSS-thema bepaalt niet langer de fontfamilie/grootte van alle widgets. Dit verhinderde live wisselen van het schrijflettertype.
- De editor gebruikt alleen nog een document-defaultfont in plaats van fontinformatie in ieder tekstteken te schrijven.
- Hoofdstuktitel en verhalenlezer volgen dezelfde schrijfprofielinstellingen.
- Alle code die een mogelijk ongeldige bestaande pointSize kon kopiëren is verwijderd.
- Extra regressietests voor de typografie-architectuur toegevoegd.

# 0.10.6

- Schrijflettertype en tekstgrootte worden nu direct bij het starten en na het laden van ieder hoofdstuk toegepast.
- Wisselen tussen Merriweather en Georgia gebruikt geen volledige QApplication/QSS-herpolish meer. Dit voorkomt de Windows/Qt-waarschuwing `QFont::setPointSize ... (-1)` die bij fontwissels kon optreden.
- Een themawissel wordt nog steeds direct als live preview toegepast; annuleren herstelt het oorspronkelijke thema en schrijfprofiel.
- Regressietests toegevoegd voor startup-typografie en font-preview.

# QuietWriter 0.10.4

- Fix: Instellingen kon niet openen omdat `QSpinBox` niet was geïmporteerd.
- Test: regressiecontrole toegevoegd voor de fontgrootte-widget in Instellingen.

# Changelog

## 0.10.4
- Uiterlijk: schrijflettertype en tekstgrootte zijn nu losse instellingen. Merriweather en Georgia gebruiken exact dezelfde ingestelde puntgrootte en Light/300 waar het font dit ondersteunt.
- Uiterlijk: tekstgrootte is live instelbaar van 11 t/m 22 pt en wordt direct toegepast op editor en verhalenlezer.
- UX: `+ Toevoegen` bij Inhoud opent nu een rustige flyout met **Hoofdstuk** en **Sectie** in plaats van een standaard Qt-dropdown. Klikken buiten de flyout annuleert vanzelf.
- Navigatie: de overbodige rechterpaneel-toggle is uit de rechter rail verwijderd; Zoeken, AI, Spelling en Geschiedenis openen/sluiten hun eigen paneel.
- Navigatie: de rechter gereedschapsrail heeft nu, net als links, een menu-knop waarmee alleen de rail zelf uit- en inklapt en optioneel tekstlabels toont.
- Navigatie: het tonen/verbergen van **Inhoud** is verplaatst naar een klein tabje aan de linkerrand van de schrijfruimte, zodat een bediening rechts niet langer een paneel links aanstuurt.
- Taal: nieuwe flyout-, menu- en inhoudstablabels zijn toegevoegd aan `nl.json`.

## 0.10.2
- Fix: QuietWriter startte niet doordat een lokale layoutvariabele `tr` de vertaalfunctie `tr()` overschaduwde in `MainWindow.__init__`. De layout heet nu `tool_layout`.
- Fix: de applicatie gebruikt bij opstarten een verse `QFont('Segoe UI', 10)` in plaats van een systeemfont dat op sommige Windows/Qt-combinaties `pointSize=-1` kan bevatten. Dit voorkomt de bekende `QFont::setPointSize`-waarschuwing aan de bron.
- Toegevoegd: regressietest die controleert dat `MainWindow.__init__` de vertaalfunctie niet opnieuw lokaal overschaduwt.

# QuietWriter 0.10.1

## UI/UX verfijning

- Wisselen tussen Merriweather en Georgia wordt nu direct en herhaald toegepast op bestaande tekst, hoofdstuktitels en de verhalenlezer; een herstart is niet meer nodig.
- Schrijftekst is iets groter gemaakt en behoudt font weight 300/Light waar het font dit ondersteunt.
- De maximale schrijfkolom is verbreed en dubbele horizontale editor-padding is teruggebracht, zodat de regelbreedte dichter bij Reedsy ligt.
- De verticale scrollbar sluit nu zonder extra marge aan op het aangrenzende paneel/rail.
- Het zichtbare label `Manuscript` is vervangen door `Inhoud` in de navigatie en boven het hoofdstukkenpaneel.
- Labels zijn standaard transparant, waardoor ongewenste grijze vlakjes achter kopteksten verdwijnen.
- Tooltips van linker- en rechtermenuknoppen gebruiken nu het taalbestand; nieuwe vertaalbare labels zijn toegevoegd voor Zoeken, AI, Spellingscontrole, Toevoegen, Versiegeschiedenis en paneelknoppen.

# QuietWriter 0.10.0

## UI/UX polish

- Nieuw centraal semantisch designsysteem voor alle zes thema's. Hardcoded UI-kleuren in onder meer versiegeschiedenis en fallback-boekomslagen zijn verwijderd.
- Merriweather is nu het standaard schrijflettertype met Georgia als automatische fallback. In Instellingen > Uiterlijk kan tussen Merriweather en Georgia worden gekozen.
- Schrijftekst gebruikt een lichte font weight (300/Light) waar het platform/font dat ondersteunt.
- Primaire, secundaire en gevaarlijke acties hebben nu een duidelijke visuele hiërarchie.
- Focus-, hover-, pressed-, selected- en disabled-states zijn consistent gemaakt.
- Actieve navigatieknoppen krijgen een subtiele accentlijn; iconen en tooltips zijn consistenter gemaakt.
- De navigatierail klapt nu met een korte, rustige animatie in en uit.
- Splitter-hitboxes zijn groter zonder een dikke zichtbare scheidingsbalk te introduceren.
- Hoofdstuk drag-handles tonen een open hand en tijdens slepen een gesloten hand.
- Manuscriptsecties zijn visueel rustiger en duidelijker ondergeschikt aan hoofdstukken.
- Boekenkaarten hebben een lichte slagschaduw; primaire kaartacties zijn duidelijker.
- De editor toont bovenin een subtiele opslagstatus en onderin hoofdstukpositie + woordenaantal.
- `***`-regels worden in de editor als gecentreerde, rustige scènebreuk weergegeven, terwijl het Markdown-bestand ongewijzigd `***` blijft bevatten.
- AI-chat heeft een rustigere, moderne kaartweergave en een compacte compose-regel met geïntegreerde verzend/stop-knop.
- Instellingen-tabbladen, menu's, scrollbars en dialoogknoppen zijn visueel op hetzelfde designsysteem gebracht.
- Application/window icon gebruikt nu de bestaande rustige boek-SVG.

## Techniek

- De grote UI-structuur in `app.py` is bewust nog niet opgesplitst. Eerst is de look & feel gestabiliseerd; technische refactoring volgt als aparte iteratie.
- Bestaande functionaliteit en opslagformaten zijn ongewijzigd.
