from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
import re

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.shared import Pt

from .manuscript_markup import is_scene_break_line, parse_inline_spans
from .media.markup import image_reference_for_line


@dataclass(frozen=True)
class DocxImportResult:
    title: str
    sections: tuple[tuple[str | None, tuple[dict, ...]], ...]
    author: str = ''
    warnings: tuple[str, ...] = ()


def _style_name(paragraph) -> str:
    try:
        return str(paragraph.style.name or '')
    except Exception:
        return ''


def _run_is_code(run) -> bool:
    try:
        if run.style and str(run.style.name or '') == 'QuietWriter Code':
            return True
    except Exception:
        pass
    try:
        name = str(run.font.name or '').lower()
    except Exception:
        name = ''
    return name in {'consolas', 'courier new', 'courier', 'liberation mono'}


def _wrap_run(text: str, run) -> str:
    if not text:
        return ''
    # A DOCX run may contain hard line breaks. Keep those as source newlines.
    code = _run_is_code(run) and '`' not in text
    bold = bool(run.bold)
    italic = bool(run.italic)
    underline = bool(run.underline)
    strike = bool(getattr(run.font, 'strike', False))

    out = text
    if code:
        out = f'`{out}`'
    else:
        if bold and italic:
            out = f'***{out}***'
        elif bold:
            out = f'**{out}**'
        elif italic:
            out = f'*{out}*'
        if underline:
            out = f'<u>{out}</u>'
        if strike:
            out = f'~~{out}~~'
    return out


def paragraph_to_markdown(paragraph) -> str:
    body = ''.join(_wrap_run(run.text, run) for run in paragraph.runs)
    style = _style_name(paragraph).lower()
    if not body:
        return ''
    if style.startswith('list bullet'):
        return f'- {body}'
    if style.startswith('list number'):
        return f'1. {body}'
    if style in {'quote', 'intense quote'}:
        return f'> {body}'
    return body


def parse_docx_book(source: Path) -> DocxImportResult:
    """Read a DOCX conservatively into QuietWriter sections/chapters.

    QuietWriter-created DOCX files use custom paragraph styles for unambiguous
    section/chapter boundaries. For ordinary Word documents, Heading 1 is treated
    as chapter headings unless Heading 2 is also present; with Heading 2 present,
    Heading 1 becomes a section and Heading 2 a chapter.
    """
    source = Path(source)
    doc = Document(str(source))
    warnings: list[str] = []
    if doc.tables:
        warnings.append(f'{len(doc.tables)} tabel(len) zijn niet geïmporteerd.')
    try:
        inline_shapes = len(doc.inline_shapes)
    except Exception:
        inline_shapes = 0
    if inline_shapes:
        warnings.append(f'{inline_shapes} afbeelding(en) uit het Word-document zijn nog niet geïmporteerd.')

    paragraphs = list(doc.paragraphs)
    styles = [_style_name(p) for p in paragraphs]
    has_qw = any(s in {'QuietWriter Section', 'QuietWriter Chapter'} for s in styles)
    has_h2 = any(re.match(r'^Heading\s+2$', s, re.I) for s in styles)

    groups: list[tuple[str | None, list[dict]]] = []
    current_section: str | None = None
    current_title: str | None = None
    current_lines: list[str] = []
    preamble: list[str] = []

    def ensure_group(title: str | None):
        nonlocal current_section
        if not groups or groups[-1][0] != title:
            groups.append((title, []))
        current_section = title

    def flush_chapter():
        nonlocal current_title, current_lines, preamble
        if current_title is None:
            return
        if not groups:
            ensure_group(current_section)
        text = '\n'.join(current_lines).rstrip('\n')
        groups[-1][1].append({'title': current_title, 'text': text})
        current_title = None
        current_lines = []

    def start_chapter(title: str):
        nonlocal current_title, current_lines, preamble
        flush_chapter()
        if not groups:
            ensure_group(current_section)
        current_title = title.strip() or 'Hoofdstuk'
        current_lines = []
        if preamble:
            current_lines.extend(preamble)
            preamble = []

    for p in paragraphs:
        style = _style_name(p)
        text = ''.join(run.text for run in p.runs).strip()
        is_section = style == 'QuietWriter Section' or (not has_qw and has_h2 and bool(re.match(r'^Heading\s+1$', style, re.I)))
        is_chapter = style == 'QuietWriter Chapter' or (
            not has_qw and ((has_h2 and bool(re.match(r'^Heading\s+2$', style, re.I))) or (not has_h2 and bool(re.match(r'^Heading\s+1$', style, re.I))))
        )
        if is_section and text:
            flush_chapter()
            ensure_group(text)
            continue
        if is_chapter and text:
            start_chapter(text)
            continue
        md = paragraph_to_markdown(p)
        if current_title is None:
            # QuietWriter DOCX files contain a generated title/front-matter area
            # before the first explicit chapter. Those publication pages are not
            # manuscript chapters on re-import. External DOCX files keep their
            # pre-heading text as a first chapter.
            if not has_qw:
                preamble.append(md)
        else:
            current_lines.append(md)

    flush_chapter()
    if preamble:
        if not groups:
            groups.append((None, []))
        title = str(doc.core_properties.title or '').strip() or source.stem
        groups[-1][1].insert(0, {'title': title, 'text': '\n'.join(preamble).rstrip('\n')})
    if not any(chapters for _, chapters in groups):
        title = str(doc.core_properties.title or '').strip() or source.stem
        groups = [(None, [{'title': title, 'text': ''}])]

    return DocxImportResult(
        title=str(doc.core_properties.title or '').strip() or source.stem,
        author=str(doc.core_properties.author or '').strip(),
        sections=tuple((section, tuple(chapters)) for section, chapters in groups),
        warnings=tuple(warnings),
    )


def _ensure_styles(doc: Document):
    styles = doc.styles
    if 'QuietWriter Section' not in styles:
        style = styles.add_style('QuietWriter Section', WD_STYLE_TYPE.PARAGRAPH)
        style.base_style = styles['Heading 1']
    if 'QuietWriter Chapter' not in styles:
        style = styles.add_style('QuietWriter Chapter', WD_STYLE_TYPE.PARAGRAPH)
        style.base_style = styles['Heading 2']
    if 'QuietWriter Code' not in styles:
        style = styles.add_style('QuietWriter Code', WD_STYLE_TYPE.CHARACTER)
        style.font.name = 'Consolas'
        style.font.size = Pt(10)


def _append_inline(paragraph, source: str, doc: Document):
    spans = parse_inline_spans(source)
    if not spans:
        paragraph.add_run(source)
        return
    marker_positions: set[int] = set()
    for span in spans:
        for a, b in span.marker_ranges:
            marker_positions.update(range(a, b))

    def active_at(pos: int) -> frozenset[str]:
        return frozenset(span.kind for span in spans if span.content_start <= pos < span.content_end)

    start = None
    styles = frozenset()
    for i in range(len(source) + 1):
        if i < len(source) and i in marker_positions:
            if start is not None:
                _add_run(paragraph, source[start:i], styles, doc)
                start = None
            continue
        current = active_at(i) if i < len(source) else frozenset()
        if start is None:
            start = i
            styles = current
        elif current != styles or i == len(source):
            _add_run(paragraph, source[start:i], styles, doc)
            start = i
            styles = current
    if start is not None and start < len(source):
        _add_run(paragraph, source[start:], styles, doc)


def _add_run(paragraph, text: str, styles: frozenset[str], doc: Document):
    if not text:
        return
    run = paragraph.add_run(text)
    run.bold = 'bold' in styles
    run.italic = 'italic' in styles
    run.underline = 'underline' in styles
    run.font.strike = 'strike' in styles
    if 'code' in styles:
        run.style = doc.styles['QuietWriter Code']


def _asset_map(export_document) -> dict[str, object]:
    result = {}
    for asset in export_document.assets:
        if asset.role != 'inline':
            continue
        result[asset.filename] = asset
        result[Path(asset.filename).name] = asset
    return result


def _append_markdown(doc: Document, markdown: str, export_document):
    assets = _asset_map(export_document)
    for raw in (markdown or '').replace('\r\n', '\n').replace('\r', '\n').split('\n'):
        stripped = raw.strip()
        image = image_reference_for_line(stripped) if stripped else None
        if image:
            p = doc.add_paragraph()
            asset = assets.get(Path(image.path).name) or assets.get(image.path)
            if asset:
                try:
                    p.add_run().add_picture(BytesIO(asset.data))
                except Exception:
                    _append_inline(p, image.alt or Path(image.path).name, doc)
            else:
                _append_inline(p, image.alt or Path(image.path).name, doc)
            if image.caption:
                cp = doc.add_paragraph()
                cp.alignment = WD_ALIGN_PARAGRAPH.CENTER
                r = cp.add_run(image.caption); r.italic = True
            continue
        if is_scene_break_line(raw):
            p = doc.add_paragraph('***')
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            continue
        if stripped.startswith('## '):
            p = doc.add_paragraph(style='Heading 3')
            _append_inline(p, stripped[3:], doc)
            continue
        if stripped.startswith('> '):
            p = doc.add_paragraph(style='Quote')
            _append_inline(p, stripped[2:], doc)
            continue
        if re.match(r'^[-*]\s+', stripped):
            p = doc.add_paragraph(style='List Bullet')
            _append_inline(p, re.sub(r'^[-*]\s+', '', stripped), doc)
            continue
        if re.match(r'^\d+\.\s+', stripped):
            p = doc.add_paragraph(style='List Number')
            _append_inline(p, re.sub(r'^\d+\.\s+', '', stripped), doc)
            continue
        p = doc.add_paragraph()
        _append_inline(p, raw, doc)


def export_docx(export_document, destination: Path, settings: dict | None = None) -> Path:
    """Export a QuietWriter snapshot to an editable DOCX document."""
    destination = Path(destination)
    doc = Document()
    _ensure_styles(doc)
    doc.core_properties.title = export_document.title
    doc.core_properties.author = export_document.author

    title = doc.add_paragraph(style='Title')
    title.add_run(export_document.title)
    if export_document.author:
        author = doc.add_paragraph()
        author.alignment = WD_ALIGN_PARAGRAPH.CENTER
        author.add_run(export_document.author)
    doc.add_page_break()

    # Textual publication front matter remains editable Word text. Structured
    # title/copyright widgets are deliberately not duplicated beyond the title page.
    for item in export_document.front_matter:
        if item.kind == 'text' and item.text.strip():
            _append_markdown(doc, item.text, export_document)
            doc.add_page_break()

    multiple_sections = len(export_document.sections) > 1
    for section in export_document.sections:
        if multiple_sections or (section.title and section.id != 'root' and section.title.lower() != 'manuscript'):
            doc.add_paragraph(section.title, style='QuietWriter Section')
        for chapter in section.chapters:
            doc.add_paragraph(chapter.title, style='QuietWriter Chapter')
            _append_markdown(doc, chapter.markdown, export_document)

    for item in export_document.back_matter:
        if item.kind == 'text' and item.text.strip():
            doc.add_page_break()
            _append_markdown(doc, item.text, export_document)

    destination.parent.mkdir(parents=True, exist_ok=True)
    tmp = destination.with_suffix(destination.suffix + '.tmp')
    doc.save(str(tmp))
    tmp.replace(destination)
    return destination
