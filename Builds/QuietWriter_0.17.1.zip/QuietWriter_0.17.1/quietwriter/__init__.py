APP_NAME = "QuietWriter"
__version__ = "0.17.1"
