# QuietWriter — projectgids

**Status:** QuietWriter-dev staat op **1.2.14** en is de actuele ontwikkelbaseline. De publieke repository heeft nog 1.1.0 als releasebasis; een nieuwe publieke 1.2.x-release wacht op de SignPath Foundation-certificering.

## Wat QuietWriter is

QuietWriter is een lokale desktop-schrijfomgeving voor boeken en langere teksten. De applicatie combineert een rustige manuscripteditor, hoofdstuk- en sectiebeheer, Planning, versiegeschiedenis/herstel, spelling, publicatie/export, media en een optionele **AI Meelezer**.

De kernwaarden zijn:

- **Blijf schrijven**;
- lokale controle;
- voorspelbaar gedrag;
- dataveiligheid;
- rust boven feature density;
- AI die ondersteunt zonder het auteurschap over te nemen.

## Wat QuietWriter niet wil zijn

- geen DTP-pakket;
- geen cloud-samenwerkingsplatform;
- geen autonome AI-schrijver;
- geen allesomvattende worldbuildingdatabase;
- geen systeem dat stil bestanden repareert, migreert of herschrijft;
- geen applicatie met meerdere concurrerende bronnen van waarheid voor dezelfde structuur.

## Huidige productstaat

In 1.2.14 zijn onder andere aanwezig:

- manuscript en hoofdstukstructuur;
- Planning, scènes en personages;
- In dit hoofdstuk;
- Darlings/Bewaarplaats;
- Open punten;
- versiegeschiedenis en herstel;
- conflict- en integriteitsbeveiliging;
- `.qwbook` import/export;
- DOCX import/export;
- EPUB/PDF/Markdown-export;
- begeleid exporteren;
- first-run/onboarding en updatecontrole;
- AI Meelezer, Schrijverspersona, Boekprofiel en Boekgeheugen;
- spelling, zoeken, focusweergave en opmaak;
- lokale media;
- vijf interfacetalen;
- vijftien thema's.

Zie `CHANGELOG.md` voor exacte versiedetails.

## Technische basis

- Python 3.12+;
- PySide6/Qt;
- momenteel Markdown als canonieke manuscriptbron;
- JSON voor diverse gestructureerde boekdata;
- lokale bestandssystemen, geen verplichte cloudbackend;
- History/revisions en optimistic concurrency;
- EPUB, PDF, DOCX en Markdown export;
- Ollama en OpenRouter als optionele AI-providers;
- PyInstaller onedir voor Windows.

### Belangrijk: intern boekformaat staat opnieuw ter beoordeling

Markdown is op dit moment de bron van waarheid voor manuscripttekst, maar wordt niet langer automatisch als de definitieve langetermijnarchitectuur beschouwd.

Omdat QuietWriter meer gebruikers en meer semantische functies krijgt, staat een formeel onderzoek naar het interne boek-/documentmodel bovenaan de roadmap.

Tot daar een expliciet besluit uit komt, blijft Markdown canoniek en veranderen we bestaande boeken niet.

## Belangrijkste codegebieden

- `quietwriter/storage.py`, `revisions.py`, `integrity.py`, `migrations.py`: opslag en veiligheid.
- `quietwriter/document_view.py`: centrale read-only interpretatie van manuscriptsyntaxis en bronranges.
- `quietwriter/ui/editor_page.py`, `manuscript_editor.py`, `manuscript_markup.py`: manuscript/editor.
- `quietwriter/planning_*` en `ui/planning/`: scènes, personages en notities.
- `quietwriter/publication_*`, `ui/publication/`, `exporting/`: publicatie en export.
- `quietwriter/media/`: media en afbeeldingen.
- `quietwriter/ai/`: Meelezer, providers en context.
- `quietwriter/ui/main_window.py`, `rail_model.py`, `current_page_stack.py`: navigatie en hoofd-UI.

## Dataconcepten

**Manuscript** = wat werkelijk geschreven is.  
**Planning** = wat bedoeld/gepland is.  
**Boekprofiel** = regels en karakter van dit specifieke boek.  
**Boekgeheugen** = duurzame feiten, afspraken en besluiten.  
**Schrijverspersona** = globale stijl/voorkeuren van de schrijver.

Deze lagen mogen niet stil in elkaar overlopen.

## Harde productregels

1. Externe wijzigingen nooit stil overschrijven.
2. Geen stille reparatie/migratie bij openen.
3. Nieuwere bestandsformaten zijn incompatibel, niet corrupt.
4. Lokale dirty invoer blijft zichtbaar of wordt eerst herstelbaar vastgelegd.
5. Presentatie is geen inhoud.
6. Eén autoritatieve bron per concept.
7. AI is Meelezer, niet schrijver/co-auteur.
8. Externe AI krijgt pas context na een bewuste gebruikersactie.
9. Geen autonome writes naar Boekgeheugen.
10. Onzekere media worden niet automatisch weggegooid.
11. Een opslagformaat wordt niet vervangen zonder expliciete migratie- en herstelstrategie.

## Repository- en releasemodel

- `gen-x-coder/QuietWriter-dev`: private ontwikkelrepository en actuele ontwikkelbaseline.
- `gen-x-coder/QuietWriter`: publieke open-source- en releaserepository.
- officiële builds en toekomstige signing komen uit de publieke repository;
- 1.2.x wordt niet opnieuw unsigned uitgebracht terwijl de SignPath Foundation-aanvraag loopt.

Zie `RELEASE_PROCESS.md`.

## Leesvolgorde voor een nieuwe ontwikkelaar of AI

1. `PROJECT_GUIDE.md`
2. `ARCHITECTURE_AND_DATA_SAFETY.md`
3. `PRODUCT_AND_UI_PHILOSOPHY.md`
4. `ROADMAP_AND_IDEAS.md`
5. `MANUSCRIPT_SYNTAX.md` — feitelijke 1.2.13-manuscriptsyntaxis en richting naar gangbare Markdownconventies
6. `BOOK_FORMAT_ARCHITECTURE_RESEARCH.md` — actief onderzoek naar manuscriptopslag, intern documentmodel en DOCX-import
7. `BOOK_FORMAT_ARCHITECTURE_REVIEW_CLAUDE.md` — onafhankelijke broncode-/DOCX-review en voorlopig advies E→B
8. `TEST_STRATEGY.md`
9. `HISTORY_AND_LESSONS.md`
10. `RELEASE_PROCESS.md`
11. `RELEASE_BRANDING_AND_OPERATIONS.md`
12. `PUBLIC_PRESENTATION.md`
13. `CHANGELOG.md`

Historische roadmapdetails staan in `ROADMAP_HISTORY_TO_1_2_13.md`.
