import unittest
from quietwriter.ai.context import ContextBuilder, ContextBundle

class TestAIContextLibrary(unittest.TestCase):
    def test_library_intent_is_detected_for_old_stories(self):
        self.assertTrue(ContextBuilder.library_intent('Welke oude verhalen lijken het meeste op deze?'))
        self.assertTrue(ContextBuilder.library_intent('Vergelijk dit met mijn verhalen.'))
        self.assertFalse(ContextBuilder.library_intent('Herschrijf deze alinea iets soberder.'))

    def test_combine_keeps_manuscript_and_library(self):
        primary = ContextBundle('hoofdstuk: X', 'MANUSCRIPT', pieces=['Schrijverspersona', 'Hoofdstuk: X'])
        library = ContextBundle('bibliotheek', 'STORY', sources=[{'title':'Oud verhaal'}], pieces=['Schrijverspersona','Verhalenbibliotheek: 1 verhalen'])
        combined = ContextBuilder.combine(primary, library, auto_library=True)
        self.assertIn('MANUSCRIPT', combined.text)
        self.assertIn('STORY', combined.text)
        self.assertEqual(combined.sources[0]['title'], 'Oud verhaal')
        self.assertIn('automatisch', combined.pieces[-1])

if __name__ == '__main__':
    unittest.main()
