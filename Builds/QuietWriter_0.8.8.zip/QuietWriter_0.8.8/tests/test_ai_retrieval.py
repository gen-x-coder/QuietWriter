import unittest
from quietwriter.ai.retrieval import retrieval_query, local_metadata_rank, dedupe_rows
from quietwriter.ai.ollama_provider import OllamaProvider


class AIRetrievalTests(unittest.TestCase):
    def test_retrieval_query_contains_current_text(self):
        q=retrieval_query('Welke oude verhalen lijken op deze?', 'Een verlaten boerderij in de winter.')
        self.assertIn('verlaten boerderij', q)
        self.assertIn('Welke oude verhalen', q)

    def test_local_rank_uses_reference_not_generic_question(self):
        rows=[
            {'path':'a','title':'Erf','tags':'boerderij, winter','description':'Familieverhaal op het platteland','synopsis':'Terugkeer naar een verlaten erf','excerpt':'Koude schuur en oude boerderij.'},
            {'path':'b','title':'Metro','tags':'stad','description':'Drukke stad','synopsis':'Een forens in de metro','excerpt':'Treinen en perrons.'},
        ]
        ranked=local_metadata_rank(rows,'Welke oude verhalen lijken op deze?','Ik keer terug naar de koude boerderij van mijn vader.',5)
        self.assertTrue(ranked)
        self.assertEqual(ranked[0]['title'],'Erf')

    def test_dedupe_rows(self):
        a={'path':'a'}; b={'path':'b'}
        self.assertEqual([x['path'] for x in dedupe_rows([a],[a,b])],['a','b'])

    def test_embedding_names_are_not_chat_models(self):
        self.assertTrue(OllamaProvider.probable_embedding_model('nomic-embed-text-v2-moe:latest'))
        self.assertTrue(OllamaProvider.probable_embedding_model('qwen3-embedding:latest'))
        self.assertFalse(OllamaProvider.probable_embedding_model('qwen3-moe-uncensored:latest'))


if __name__ == '__main__':
    unittest.main()

class _FakeResponse:
    def __init__(self): self.closed=False
    def close(self): self.closed=True

class ProviderCancellationTests(unittest.TestCase):
    def test_ollama_cancel_closes_active_response(self):
        p=OllamaProvider()
        r=_FakeResponse(); p._set_active(r)
        p.cancel_active()
        self.assertTrue(r.closed)
