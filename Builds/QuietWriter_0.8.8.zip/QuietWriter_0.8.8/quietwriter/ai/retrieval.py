from __future__ import annotations
import math
import re

STOPWORDS = {
    'de','het','een','en','of','van','voor','met','naar','op','in','uit','aan','bij','om','te','dat','dit','die','wat','welke',
    'mijn','oude','eerder','eerdere','verhaal','verhalen','lijkt','lijken','meest','meeste','deze','dit','vergelijk','vergelijkbare',
    'ik','je','jij','is','zijn','was','waren','als','dan','ook','nog','maar','er','ze','hij','zij','haar','hem','hun','door','over',
}


def terms(text: str, limit: int = 80) -> list[str]:
    raw = re.findall(r"[\wÀ-ÿ'-]{3,}", (text or '').casefold())
    out=[]; seen=set()
    for w in raw:
        w=w.strip("'-")
        if not w or w in STOPWORDS or w.isdigit() or w in seen:
            continue
        seen.add(w); out.append(w)
        if len(out) >= limit: break
    return out


def retrieval_query(prompt: str, reference_text: str, max_reference_chars: int = 5500) -> str:
    """Maak een zoekquery die 'deze tekst' concreet maakt voor embeddings.

    Alleen de gebruikersvraag embedden is onvoldoende bij vragen zoals
    'Welke oude verhalen lijken op deze?'. Daarom gaat een begrensd fragment
    van het actuele manuscript mee als semantische referentie.
    """
    ref=(reference_text or '').strip()
    if len(ref) > max_reference_chars:
        ref=ref[:max_reference_chars]
    if ref:
        return f'Vraag: {prompt}\n\nTe vergelijken huidige tekst:\n{ref}'
    return prompt


def local_metadata_rank(catalog: list[dict], prompt: str, reference_text: str, limit: int = 20) -> list[dict]:
    """Provider-onafhankelijke fallback-rangschikking.

    Dit is bewust geen vervanging voor embeddings, maar voorkomt dat een fout
    achtergrondmodel de retrieval volledig leeg maakt.
    """
    q=set(terms(prompt, 40)); r=set(terms(reference_text, 100))
    scored=[]
    for row in catalog:
        meta=' '.join(str(row.get(k,'') or '') for k in ('title','tags','description','synopsis','excerpt'))
        m=set(terms(meta, 160))
        if not m: continue
        qhits=len(q & m)
        rhits=len(r & m)
        # Tags/titel-vraagoverlap telt zwaar; overlap met manuscript geeft de
        # vergelijking inhoudelijke richting. Normalisatie remt lange metadata.
        score=qhits*4.0 + rhits/max(1.0, math.sqrt(len(m)))
        if score > 0:
            scored.append((score,row))
    scored.sort(key=lambda x:x[0], reverse=True)
    return [row for _,row in scored[:limit]]


def dedupe_rows(*groups: list[dict], limit: int | None = None) -> list[dict]:
    out=[]; seen=set()
    for group in groups:
        for row in group or []:
            key=str(row.get('path',''))
            if not key or key in seen: continue
            seen.add(key); out.append(row)
            if limit is not None and len(out) >= limit:
                return out
    return out
