APP_NAME = 'QuietWriter'
__version__ = "0.8.8"
