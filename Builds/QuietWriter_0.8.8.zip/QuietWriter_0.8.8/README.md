# QuietWriter 0.8.6

QuietWriter is een lokale Python-desktopapp voor het schrijven van boeken en verhalen. Manuscripten blijven gewone Markdown-bestanden. De applicatie combineert een rustige editor met versiegeschiedenis, spellingscontrole en een modulaire AI-laag.

## Installeren

Python 3.12 of nieuwer wordt aanbevolen.

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

## AI

Open **Instellingen > AI**. QuietWriter ondersteunt nu een provider-onafhankelijke AI-laag.

### Ollama

Ollama blijft de standaard. QuietWriter controleert bij het opstarten of Ollama bereikbaar is en haalt de lokale modellen op. Je kunt afzonderlijk kiezen voor:

- **Schrijf- en analysemodel** — het grotere model voor schrijven, feedback en analyse;
- **Snel achtergrondmodel** — een klein lokaal model dat als bibliothecaris kan werken;
- **Embeddingmodel (optioneel)** — bijvoorbeeld een lokaal embeddingmodel voor semantische verhaalzoekopdrachten.

### OpenRouter

Kies **OpenRouter** als AI-provider, vul een API-key in en klik op **Modellen ophalen**. De rest van QuietWriter blijft dezelfde AI-functies gebruiken; providerdetails zitten volledig achter de provider-interface.

Het snelle achtergrondmodel blijft standaard lokaal via Ollama. Daardoor kun je later bijvoorbeeld een groot OpenRouter-model voor analyse gebruiken en een klein lokaal Ollama-model voor bibliotheektaken.

## AI-context

De schrijverpersona uit `persona/schrijver.md` wordt altijd toegevoegd.

Daarbovenop kun je als context kiezen:

- huidig hoofdstuk;
- huidige sectie;
- hele boek;
- verhalenbibliotheek.

Als je tekst in de editor selecteert, krijgt die selectie automatisch voorrang. In het AI-paneel laat **Context bekijken** zien welke context is gebruikt en welke oude verhalen zijn geraadpleegd.

## Verhalenbibliotheek en RAG

Bij **Verhalenbibliotheek** gebruikt QuietWriter meerdere lagen:

1. lokale full-text search en metadata;
2. tags krijgen extra gewicht;
3. het snelle achtergrondmodel kan een compacte catalogus van alle verhalen in batches beoordelen;
4. als een embeddingmodel is gekozen, worden semantisch vergelijkbare verhalen meegenomen;
5. alleen de meest relevante verhalen gaan als volledige context naar het hoofdmodel.

Embeddingvectors worden gecachet in:

```text
.cache/story_embeddings.db
```

Als een verhaal wijzigt, wordt de oude embedding automatisch ongeldig door de gewijzigde bestandsdatum.

## AI-gesprekken

Gesprekken worden per boek opgeslagen in:

```text
books/<boek>/.quietwriter/ai_chat.json
```

Daarmee blijft de chat bij het boek horen. **Nieuw gesprek** leegt die conversatie. Alleen de recente conversatie wordt opnieuw naar het model gestuurd; manuscriptcontext wordt bij iedere opdracht opnieuw opgebouwd zodat die niet veroudert.

AI-antwoorden worden als Markdown weergegeven, inclusief koppen, vet, cursief, lijsten en codeblokken. De AI verandert nooit zelfstandig je manuscript.

## Werkmap

Standaard:

```text
C:\Users\<naam>\QuietWriter
```

Belangrijke mappen:

```text
QuietWriter/
├── books/
├── stories/
├── boekomslagen/
├── persona/
│   └── schrijver.md
├── archive/
├── trash/
├── dictionaries/
└── .cache/
```

## Spellingscontrole

QuietWriter bundelt bewust geen woordenboeken. Het zoekt automatisch in de werkmap en in gangbare installaties van ONLYOFFICE, LibreOffice en OpenOffice. Alle gevonden Hunspell-talen worden getoond met een leesbare naam.

De editor toont rode spellinghints. Het rechter spellingspaneel biedt stap-voor-stap wijzigen, negeren, alles negeren, altijd negeren en toevoegen aan het persoonlijke woordenboek.

## Versiegeschiedenis

Via het klok-icoon zijn automatische dagarchieven en handmatige versies zichtbaar. Oude versies kunnen alleen-lezen worden bekeken, met ster worden gemarkeerd en veilig worden hersteld. Vóór herstel maakt QuietWriter automatisch een veiligheidsversie van de huidige toestand.

## Tests

```powershell
python -m unittest discover -s tests -v
```

0.8.1 bevat **31 automatische tests**, onder andere voor drag-and-drop, Dropbox/Windows file locks, versieherstel, woordenboeken, spellingsengine, AI-providerselectie, gesprekopslag, metadata-RAG en embeddingcache.

Zie `ROADMAP.md` voor de volgende iteraties.


## AI-bibliotheek in 0.8.4

Bij een vraag als **“Welke oude verhalen lijken op deze?”** gebruikt QuietWriter nu het huidige hoofdstuk als echte vergelijkingsreferentie. De zoekketen is:

1. lokale metadata/full-text matching;
2. optioneel semantisch zoeken met een embeddingmodel;
3. optioneel een klein bibliothecarismodel voor herordening/selectie;
4. maximaal enkele relevante verhalen naar het schrijfmodel.

Een embeddingmodel is **geen chatmodel**. QuietWriter scheidt deze rollen nu en zal een model als `nomic-embed-text` niet meer als bibliothecaris gebruiken. Als voor een expliciete bibliotheekvraag geen bron wordt gevonden, stopt QuietWriter daar en laat het het schrijfmodel geen verhalen verzinnen.

Tijdens een lang AI-verzoek kun je **Stop AI** gebruiken. QuietWriter sluit daarbij de actieve providerstream en wacht bij afsluiten op de workerthreads.


## AI-context in 0.8.3

De hoofdcontext blijft selectie, huidig hoofdstuk, huidige sectie of hele boek. De verhalenbibliotheek is nu een **extra bron**. Zet **Verhalenbibliotheek meenemen** aan wanneer oude verhalen relevant zijn. Bij duidelijke formuleringen zoals “vergelijk met mijn oude verhalen” activeert QuietWriter die bron ook automatisch en toont dat in de contextweergave.

**Bibliothecarismodel:** klein/snel lokaal model dat op metadata (titel, tags, description, synopsis) relevante verhalen selecteert.

**Semantisch zoekmodel:** optionele embeddinglaag die zoekt op betekenis in plaats van alleen woorden/tags. Het schrijft geen tekst. Laat het leeg als je dit niet nodig hebt; de bibliothecaris blijft dan gewoon werken.


## AI-modus in 0.8.6

QuietWriter gebruikt voorlopig een eenvoudige en stabiele AI-flow: schrijverspersona + geselecteerde tekst of gekozen manuscriptcontext -> rechtstreeks naar het schrijf- en analysemodel. De bibliothecaris en semantische zoeklaag blijven in de code aanwezig, maar zijn tijdelijk uitgeschakeld totdat de retrieval betrouwbaar genoeg is.

De verzendknop verandert tijdens generatie in dezelfde knop met een stopvierkant. QuietWriter begrenst de prompt conservatief op het contextvenster van het gekozen model, zodat lokale 8k-modellen niet meer door een te grote prompt met HTTP 400 stoppen.


### Automatische AI-context

QuietWriter kiest het contextvenster nu automatisch per model en opdracht. Bij Ollama leest de app het modelmaximum uit, kijkt hij of het model al geladen is en welk runtimevenster daarbij actief is, en kiest vervolgens het kleinste contextvenster dat de huidige prompt plus antwoordruimte past. Voor korte opdrachten blijft een klein venster actief; langere hoofdstukken kunnen automatisch naar 16K of 32K gaan wanneer het model dat ondersteunt.

Onder **Context bekijken** worden het gekozen venster, de geschatte invoer, gereserveerde antwoordruimte en het modelmaximum getoond. Als de context ondanks de conservatieve schatting te klein blijkt, kan de Ollama-provider de exacte tokenfout gebruiken om automatisch een groter venster te proberen. Als het modelmaximum bereikt is, wordt eerst oude chatgeschiedenis verwijderd en daarna pas manuscriptcontext ingekort.


## AI-context in 0.8.8
QuietWriter doet bewust geen token- of VRAMberekeningen meer. De gekozen AI-provider krijgt rechtstreeks de schrijverspersona, de gekozen selectie/hoofdstuk/sectie/boek-context en een beperkte recente chatgeschiedenis. Ollama/OpenRouter bepalen zelf hun runtime-context.
