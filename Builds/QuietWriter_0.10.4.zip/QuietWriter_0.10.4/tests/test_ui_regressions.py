import ast
import unittest
from pathlib import Path


class UIRegressionTests(unittest.TestCase):
    def test_mainwindow_init_does_not_shadow_translation_function(self):
        app_path = Path(__file__).resolve().parents[1] / "quietwriter" / "app.py"
        tree = ast.parse(app_path.read_text(encoding="utf-8"))
        main_cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "MainWindow")
        init = next(n for n in main_cls.body if isinstance(n, ast.FunctionDef) and n.name == "__init__")
        assigned = set()
        for node in ast.walk(init):
            if isinstance(node, (ast.Assign, ast.AnnAssign, ast.NamedExpr)):
                targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                for target in targets:
                    if isinstance(target, ast.Name):
                        assigned.add(target.id)
            elif isinstance(node, ast.For) and isinstance(node.target, ast.Name):
                assigned.add(node.target.id)
        self.assertNotIn("tr", assigned, "MainWindow.__init__ must not shadow imported tr()")

    def test_application_font_has_explicit_positive_point_size(self):
        app_path = Path(__file__).resolve().parents[1] / "quietwriter" / "app.py"
        source = app_path.read_text(encoding="utf-8")
        self.assertIn("QFont('Segoe UI', 10)", source)

    def test_qspinbox_is_imported_for_settings_font_size(self):
        app_path = Path(__file__).resolve().parents[1] / "quietwriter" / "app.py"
        source = app_path.read_text(encoding="utf-8")
        self.assertIn("QSpinBox", source.split("from . import APP_NAME", 1)[0])
        self.assertIn("self.editor_font_size = QSpinBox()", source)


if __name__ == "__main__":
    unittest.main()
