# QuietWriter 0.10.4

- Fix: Instellingen kon niet openen omdat `QSpinBox` niet was geïmporteerd.
- Test: regressiecontrole toegevoegd voor de fontgrootte-widget in Instellingen.

# Changelog

## 0.10.4
- Uiterlijk: schrijflettertype en tekstgrootte zijn nu losse instellingen. Merriweather en Georgia gebruiken exact dezelfde ingestelde puntgrootte en Light/300 waar het font dit ondersteunt.
- Uiterlijk: tekstgrootte is live instelbaar van 11 t/m 22 pt en wordt direct toegepast op editor en verhalenlezer.
- UX: `+ Toevoegen` bij Inhoud opent nu een rustige flyout met **Hoofdstuk** en **Sectie** in plaats van een standaard Qt-dropdown. Klikken buiten de flyout annuleert vanzelf.
- Navigatie: de overbodige rechterpaneel-toggle is uit de rechter rail verwijderd; Zoeken, AI, Spelling en Geschiedenis openen/sluiten hun eigen paneel.
- Navigatie: de rechter gereedschapsrail heeft nu, net als links, een menu-knop waarmee alleen de rail zelf uit- en inklapt en optioneel tekstlabels toont.
- Navigatie: het tonen/verbergen van **Inhoud** is verplaatst naar een klein tabje aan de linkerrand van de schrijfruimte, zodat een bediening rechts niet langer een paneel links aanstuurt.
- Taal: nieuwe flyout-, menu- en inhoudstablabels zijn toegevoegd aan `nl.json`.

## 0.10.2
- Fix: QuietWriter startte niet doordat een lokale layoutvariabele `tr` de vertaalfunctie `tr()` overschaduwde in `MainWindow.__init__`. De layout heet nu `tool_layout`.
- Fix: de applicatie gebruikt bij opstarten een verse `QFont('Segoe UI', 10)` in plaats van een systeemfont dat op sommige Windows/Qt-combinaties `pointSize=-1` kan bevatten. Dit voorkomt de bekende `QFont::setPointSize`-waarschuwing aan de bron.
- Toegevoegd: regressietest die controleert dat `MainWindow.__init__` de vertaalfunctie niet opnieuw lokaal overschaduwt.

# QuietWriter 0.10.1

## UI/UX verfijning

- Wisselen tussen Merriweather en Georgia wordt nu direct en herhaald toegepast op bestaande tekst, hoofdstuktitels en de verhalenlezer; een herstart is niet meer nodig.
- Schrijftekst is iets groter gemaakt en behoudt font weight 300/Light waar het font dit ondersteunt.
- De maximale schrijfkolom is verbreed en dubbele horizontale editor-padding is teruggebracht, zodat de regelbreedte dichter bij Reedsy ligt.
- De verticale scrollbar sluit nu zonder extra marge aan op het aangrenzende paneel/rail.
- Het zichtbare label `Manuscript` is vervangen door `Inhoud` in de navigatie en boven het hoofdstukkenpaneel.
- Labels zijn standaard transparant, waardoor ongewenste grijze vlakjes achter kopteksten verdwijnen.
- Tooltips van linker- en rechtermenuknoppen gebruiken nu het taalbestand; nieuwe vertaalbare labels zijn toegevoegd voor Zoeken, AI, Spellingscontrole, Toevoegen, Versiegeschiedenis en paneelknoppen.

# QuietWriter 0.10.0

## UI/UX polish

- Nieuw centraal semantisch designsysteem voor alle zes thema's. Hardcoded UI-kleuren in onder meer versiegeschiedenis en fallback-boekomslagen zijn verwijderd.
- Merriweather is nu het standaard schrijflettertype met Georgia als automatische fallback. In Instellingen > Uiterlijk kan tussen Merriweather en Georgia worden gekozen.
- Schrijftekst gebruikt een lichte font weight (300/Light) waar het platform/font dat ondersteunt.
- Primaire, secundaire en gevaarlijke acties hebben nu een duidelijke visuele hiërarchie.
- Focus-, hover-, pressed-, selected- en disabled-states zijn consistent gemaakt.
- Actieve navigatieknoppen krijgen een subtiele accentlijn; iconen en tooltips zijn consistenter gemaakt.
- De navigatierail klapt nu met een korte, rustige animatie in en uit.
- Splitter-hitboxes zijn groter zonder een dikke zichtbare scheidingsbalk te introduceren.
- Hoofdstuk drag-handles tonen een open hand en tijdens slepen een gesloten hand.
- Manuscriptsecties zijn visueel rustiger en duidelijker ondergeschikt aan hoofdstukken.
- Boekenkaarten hebben een lichte slagschaduw; primaire kaartacties zijn duidelijker.
- De editor toont bovenin een subtiele opslagstatus en onderin hoofdstukpositie + woordenaantal.
- `***`-regels worden in de editor als gecentreerde, rustige scènebreuk weergegeven, terwijl het Markdown-bestand ongewijzigd `***` blijft bevatten.
- AI-chat heeft een rustigere, moderne kaartweergave en een compacte compose-regel met geïntegreerde verzend/stop-knop.
- Instellingen-tabbladen, menu's, scrollbars en dialoogknoppen zijn visueel op hetzelfde designsysteem gebracht.
- Application/window icon gebruikt nu de bestaande rustige boek-SVG.

## Techniek

- De grote UI-structuur in `app.py` is bewust nog niet opgesplitst. Eerst is de look & feel gestabiliseerd; technische refactoring volgt als aparte iteratie.
- Bestaande functionaliteit en opslagformaten zijn ongewijzigd.
