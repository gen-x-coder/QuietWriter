from __future__ import annotations

import re

from PySide6.QtGui import QColor, QFont, QTextCharFormat, QSyntaxHighlighter

from ..spell_engine import WORD_RE


class ManuscriptHighlighter(QSyntaxHighlighter):
    """Visual presentation layer for QuietWriter's Markdown source.

    The QTextDocument continues to contain ordinary Markdown.  This highlighter
    makes the syntax markers visually disappear and styles the text they delimit.
    Because QSyntaxHighlighter does not modify document contents, undo/redo and
    ``toPlainText()`` remain source-oriented and no rich-text state leaks into the
    saved chapter files.

    Spelling is handled here too.  A QTextDocument should have one presentation
    highlighter so spelling underlines can be merged with bold/italic/etc. rather
    than one highlighter accidentally overwriting another.
    """

    INLINE_PATTERNS = (
        ('code', re.compile(r'`([^`\n]+)`')),
        ('underline', re.compile(r'<u>(.+?)</u>')),
        ('strike', re.compile(r'~~(.+?)~~')),
        ('bold', re.compile(r'\*\*(.+?)\*\*')),
        ('italic', re.compile(r'(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)')),
    )

    def __init__(self, editor):
        super().__init__(editor.document())
        self.editor = editor
        self.dictionary = None
        self.spell_active = False

    def set_dictionary(self, dictionary):
        self.dictionary = dictionary
        self.rehighlight()

    def set_active(self, active: bool):
        self.spell_active = bool(active)
        self.rehighlight()

    def _hidden_marker_format(self) -> QTextCharFormat:
        # A very small glyph size collapses Markdown punctuation to effectively
        # zero visual width.  Keeping a real positive size avoids Qt's invalid
        # point-size warning on stricter PySide6 builds.
        fmt = QTextCharFormat()
        fmt.setForeground(QColor(self.editor._theme()['editor']))
        fmt.setFontPointSize(0.1)
        fmt.setFontStretch(1)
        return fmt

    def _base_format(self, kind: str) -> QTextCharFormat:
        fmt = QTextCharFormat()
        if kind == 'heading':
            fmt.setFontWeight(QFont.Weight.DemiBold)
            fmt.setFontPointSize(float(self.editor.typography.point_size + 2))
        elif kind == 'quote':
            fmt.setFontItalic(True)
            fmt.setForeground(QColor(self.editor._theme()['muted']))
        return fmt

    @staticmethod
    def _prefix(text: str, kind: str) -> tuple[int, str]:
        if kind == 'heading' and text.startswith('## '):
            return 3, text[3:]
        if kind == 'quote' and text.startswith('> '):
            return 2, text[2:]
        if kind == 'bullet':
            m = re.match(r'^[-*]\s+', text)
            if m:
                return m.end(), text[m.end():]
        if kind == 'numbered':
            m = re.match(r'^\d+\.\s+', text)
            if m:
                return m.end(), text[m.end():]
        return 0, text

    def _apply_inline(self, text: str, offset: int, base: QTextCharFormat, marker_ranges: list[tuple[int, int]]):
        hidden = self._hidden_marker_format()
        for kind, rx in self.INLINE_PATTERNS:
            for match in rx.finditer(text):
                full_start, full_end = match.span(0)
                inner_start, inner_end = match.span(1)
                open_start = offset + full_start
                open_len = inner_start - full_start
                close_start = offset + inner_end
                close_len = full_end - inner_end
                if open_len:
                    self.setFormat(open_start, open_len, hidden)
                    marker_ranges.append((open_start, open_start + open_len))
                if close_len:
                    self.setFormat(close_start, close_len, hidden)
                    marker_ranges.append((close_start, close_start + close_len))

                fmt = QTextCharFormat(base)
                if kind == 'bold':
                    fmt.setFontWeight(QFont.Weight.Bold)
                elif kind == 'italic':
                    fmt.setFontItalic(True)
                elif kind == 'underline':
                    fmt.setFontUnderline(True)
                elif kind == 'strike':
                    fmt.setFontStrikeOut(True)
                elif kind == 'code':
                    fmt.setFontFamilies(['Consolas', 'Courier New'])
                    fmt.setBackground(QColor(self.editor._theme()['panel2']))
                self.setFormat(offset + inner_start, inner_end - inner_start, fmt)

    @staticmethod
    def _inside_ranges(position: int, ranges: list[tuple[int, int]]) -> bool:
        return any(start <= position < end for start, end in ranges)

    def _apply_spelling(self, text: str, marker_ranges: list[tuple[int, int]]):
        if not self.spell_active or not self.dictionary or not self.dictionary.words:
            return
        for match in WORD_RE.finditer(text):
            if self._inside_ranges(match.start(), marker_ranges):
                continue
            if self.dictionary.known(match.group(0)):
                continue
            # Merge the spelling underline into the presentation format already
            # applied at this position instead of replacing bold/italic/etc.
            fmt = QTextCharFormat(self.format(match.start()))
            fmt.setUnderlineColor(QColor('#c84b4b'))
            fmt.setUnderlineStyle(QTextCharFormat.SpellCheckUnderline)
            self.setFormat(match.start(), len(match.group(0)), fmt)

    def highlightBlock(self, text: str):
        kind = self.editor._block_kind(text)
        hidden = self._hidden_marker_format()
        marker_ranges: list[tuple[int, int]] = []

        if kind == 'scene':
            if text:
                self.setFormat(0, len(text), hidden)
                marker_ranges.append((0, len(text)))
            return

        prefix_len, visible_text = self._prefix(text, kind)
        if prefix_len:
            self.setFormat(0, prefix_len, hidden)
            marker_ranges.append((0, prefix_len))

        base = self._base_format(kind)
        if visible_text and (kind in {'heading', 'quote'}):
            self.setFormat(prefix_len, len(visible_text), base)

        self._apply_inline(visible_text, prefix_len, base, marker_ranges)
        self._apply_spelling(text, marker_ranges)
