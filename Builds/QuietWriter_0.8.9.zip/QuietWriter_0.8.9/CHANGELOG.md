# Changelog

## 0.8.9

- RAG-, embedding-, semantische retrieval- en bibliothecarisfunctionaliteit volledig verwijderd.
- Bijbehorende AI-instellingen en uitgeschakelde UI-elementen verwijderd.
- `embedding_cache.py` en `retrieval.py` verwijderd.
- Bibliothecarisworker en alle oude retrieval-flow uit het AI-paneel verwijderd.
- Ollama-provider teruggebracht tot modeloverzicht, streaming chat en annuleren.
- Provider-interface teruggebracht tot de functies die QuietWriter nu werkelijk gebruikt.
- AI-context bevat alleen schrijverspersona plus selectie/hoofdstuk/sectie/boek en recente chat.
- OpenRouter-modulariteit behouden.
- Verhalenbibliotheek blijft volledig beschikbaar als normale QuietWriter-functie, maar staat los van AI.
- Tests en documentatie opgeschoond zodat ze alleen actuele functionaliteit beschrijven.
