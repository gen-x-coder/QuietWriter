# QuietWriter 0.8.9

QuietWriter is een lokale Python-desktopapp voor het schrijven van boeken en verhalen. Manuscripten blijven gewone Markdown-bestanden. De applicatie combineert een rustige editor met versiegeschiedenis, spellingscontrole en een modulaire AI-schrijfassistent.

## Installeren

Python 3.12 of nieuwer wordt aanbevolen.

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

## AI

De AI-laag is bewust eenvoudig. Iedere opdracht gebruikt:

1. `schrijver.md` als vaste schrijverspersona;
2. je geselecteerde tekst, of anders het gekozen hoofdstuk/de sectie/het hele boek;
3. een beperkte recente chatgeschiedenis;
4. het gekozen schrijf- en analysemodel.

QuietWriter past nooit zelfstandig je manuscript aan. AI-output verschijnt alleen in het chatpaneel. Antwoorden worden als Markdown gerenderd en de output streamt tijdens generatie. De verzendknop verandert tijdens een lopend verzoek in een stopknop.

### Providers

- **Ollama** is de standaard lokale provider. Bij het starten controleert QuietWriter of Ollama bereikbaar is en haalt het de geïnstalleerde modellen op.
- **OpenRouter** is als aparte provider voorbereid. De schrijfworkflow zelf kent geen provider-specifieke logica.

Er is geen actieve RAG-, embedding- of bibliothecarislaag meer. Oude verhalen blijven gewoon via **Verhalen** in de applicatie beschikbaar, maar worden niet automatisch aan AI-opdrachten toegevoegd.

## AI-gesprekken

Gesprekken worden per boek opgeslagen in:

```text
books/<boek>/.quietwriter/ai_chat.json
```

**Nieuw gesprek** leegt alleen de AI-chat van dat boek. Manuscriptcontext wordt bij iedere opdracht opnieuw uit de actuele editor opgebouwd.

## Werkmap

Belangrijke mappen:

```text
QuietWriter/
├── books/
├── stories/
├── boekomslagen/
├── persona/
│   └── schrijver.md
├── archive/
├── trash/
├── dictionaries/
└── .cache/
```

## Spellingscontrole

QuietWriter bundelt bewust geen woordenboeken. Het zoekt automatisch in de werkmap en in gangbare installaties van ONLYOFFICE, LibreOffice en OpenOffice. De editor toont passieve rode spellinghints; het rechterpaneel biedt stap-voor-stap controle en correctie.

## Versiegeschiedenis

Via het klok-icoon zijn automatische dagarchieven en handmatige versies zichtbaar. Oude versies kunnen alleen-lezen worden bekeken, met ster worden gemarkeerd en veilig worden hersteld.

## Tests

```powershell
python -m unittest discover -s tests -v
```

Zie `ROADMAP.md` voor de volgende iteraties.
