import os
from pathlib import Path

import pytest

pytest.importorskip('PySide6')
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

from PySide6.QtCore import QSettings
from PySide6.QtGui import QTextCursor
from PySide6.QtWidgets import QApplication, QMessageBox

from quietwriter.fragment_store import FragmentStore
from quietwriter.storage import Library
from quietwriter.ui.main_window import MainWindow


@pytest.fixture(scope='module')
def app():
    return QApplication.instance() or QApplication([])


def _settings(path: Path):
    settings = QSettings(str(path), QSettings.IniFormat)
    settings.setValue('spell_enabled', False)
    settings.setValue('ai_enabled', False)
    settings.setValue('advanced_options', False)
    return settings


def _window_with_book(tmp_path: Path, source: str):
    workspace = tmp_path / 'workspace'
    lib = Library(workspace)
    book = lib.create_book('Testboek')
    chapter = next(c for sec in book.sections for c in sec.chapters)
    chapter_path = Path(book.path) / chapter.file
    chapter_path.write_text(source, encoding='utf-8')
    book = lib.load_book(book.path)
    window = MainWindow(_settings(tmp_path / 'settings.ini'), lib, [])
    window.open_book(book)
    return window, chapter_path


def test_copy_selection_runs_real_qt_path_and_does_not_modify_manuscript(app, tmp_path):
    source = 'Voor **vet woord** na.\n'
    window, chapter_path = _window_with_book(tmp_path, source)
    try:
        before = chapter_path.read_bytes()
        editor = window.editor_page.editor
        start = source.index('vet woord')
        cursor = editor.textCursor()
        cursor.setPosition(start)
        cursor.setPosition(start + len('vet woord'), QTextCursor.KeepAnchor)
        editor.setTextCursor(cursor)

        assert window.editor_page.copy_selection_to_darlings() is True
        fragments = window.darlings_page.store.list_fragments()
        assert len(fragments) == 1
        assert fragments[0].text == '**vet woord**'
        assert fragments[0].source_book_title == 'Testboek'
        assert chapter_path.read_bytes() == before
    finally:
        window.close()


def test_search_saves_pending_metadata_before_refresh(app, tmp_path):
    window, _chapter_path = _window_with_book(tmp_path, 'Tekst.\n')
    try:
        fragment = window.darlings_page.store.create('Fragmenttekst')
        window.darlings_page.add_fragment(fragment)
        window.darlings_page.title_edit.setText('Mijn lokale titel')
        assert window.darlings_page.dirty is True

        # textChanged invokes refresh(); the pending title must be committed first.
        window.darlings_page.search.setText('bestaat-niet')
        saved = window.darlings_page.store.load(fragment.id)
        assert saved.title == 'Mijn lokale titel'
    finally:
        window.close()


def test_external_change_keeps_local_fields_and_allows_conscious_second_save(app, tmp_path, monkeypatch):
    window, _chapter_path = _window_with_book(tmp_path, 'Tekst.\n')
    try:
        page = window.darlings_page
        fragment = page.store.create('Fragmenttekst', title='Origineel')
        page.add_fragment(fragment)
        page.note_edit.setPlainText('Mijn lokale notitie')
        assert page.dirty is True

        other = FragmentStore(page.store.root)
        disk = other.load(fragment.id)
        other.update_metadata(fragment.id, expected_revision=disk.revision, title='Titel van laptop')

        monkeypatch.setattr(QMessageBox, 'warning', lambda *args, **kwargs: QMessageBox.Ok)
        assert page.save_metadata() is False
        assert page.note_edit.toPlainText() == 'Mijn lokale notitie'
        assert page.dirty is True
        assert page._loaded_fragment.title == 'Titel van laptop'

        # A second click is an explicit choice to save the still-visible local fields.
        assert page.save_metadata() is True
        assert page.store.load(fragment.id).note == 'Mijn lokale notitie'
    finally:
        window.close()
