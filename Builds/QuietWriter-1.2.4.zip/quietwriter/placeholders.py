from __future__ import annotations

import html
import re
import uuid
from dataclasses import dataclass
from urllib.parse import quote, unquote

_OPEN_RE = re.compile(r'<!--\s*qw:todo\s+id=([0-9a-fA-F-]{8,})\s+note="([^"]*)"\s*-->')
_CLOSE_RE = re.compile(r'<!--\s*/qw:todo\s*-->')
_TOKEN_RE = re.compile(r'<!--\s*qw:todo\s+id=([0-9a-fA-F-]{8,})\s+note="([^"]*)"\s*-->|<!--\s*/qw:todo\s*-->')


@dataclass(frozen=True)
class OpenPoint:
    id: str
    note: str
    text: str
    start: int
    end: int
    content_start: int
    content_end: int


def encode_note(note: str) -> str:
    return quote(str(note or ''), safe='')


def decode_note(value: str) -> str:
    try:
        return unquote(str(value or ''))
    except Exception:
        return str(value or '')


def marker_open(point_id: str, note: str = '') -> str:
    return f'<!-- qw:todo id={point_id} note="{encode_note(note)}" -->'


def marker_close() -> str:
    return '<!-- /qw:todo -->'


def wrap_open_point(text: str, start: int, end: int, note: str = '') -> tuple[str, int, int, str]:
    source = text or ''
    start, end = sorted((max(0, int(start)), max(0, int(end))))
    start = min(start, len(source)); end = min(end, len(source))
    visible = source[start:end]
    if not visible:
        visible = '[…]'
    point_id = str(uuid.uuid4())
    left = marker_open(point_id, note)
    right = marker_close()
    new = source[:start] + left + visible + right + source[end:]
    content_start = start + len(left)
    return new, content_start, content_start + len(visible), point_id


def parse_open_points(text: str) -> list[OpenPoint]:
    source = text or ''
    points: list[OpenPoint] = []
    stack: list[tuple[re.Match, str, str]] = []
    for match in _TOKEN_RE.finditer(source):
        if match.group(1):
            stack.append((match, match.group(1), decode_note(match.group(2))))
            continue
        if not stack:
            continue
        opening, point_id, note = stack.pop()
        content_start = opening.end()
        content_end = match.start()
        points.append(OpenPoint(
            id=point_id,
            note=note,
            text=source[content_start:content_end],
            start=opening.start(),
            end=match.end(),
            content_start=content_start,
            content_end=content_end,
        ))
    return sorted(points, key=lambda p: p.start)


def strip_open_point_markers(text: str) -> str:
    """Remove QuietWriter todo syntax while preserving the writer-visible text."""
    return _TOKEN_RE.sub('', text or '')



def mask_open_point_markers(text: str) -> str:
    """Blank marker syntax while preserving source offsets exactly."""
    source = text or ''
    chars = list(source)
    for start, end in marker_ranges(source):
        for index in range(start, min(end, len(chars))):
            chars[index] = ' '
    return ''.join(chars)

def marker_ranges(text: str) -> list[tuple[int, int]]:
    return [(m.start(), m.end()) for m in _TOKEN_RE.finditer(text or '')]


def open_point_content_ranges(text: str) -> list[tuple[int, int]]:
    return [(p.content_start, p.content_end) for p in parse_open_points(text)]


def count_open_points(text: str) -> int:
    return len(parse_open_points(text))


def open_point_at(text: str, position: int) -> OpenPoint | None:
    pos = max(0, int(position))
    for point in parse_open_points(text):
        if point.content_start <= pos <= point.content_end:
            return point
    return None


def resolve_open_point(text: str, point_id: str) -> tuple[str, int, int] | None:
    source = text or ''
    point = next((p for p in parse_open_points(source) if p.id == point_id), None)
    if point is None:
        return None
    visible = source[point.content_start:point.content_end]
    new = source[:point.start] + visible + source[point.end:]
    start = point.start
    return new, start, start + len(visible)


def update_open_point_note(text: str, point_id: str, note: str) -> str | None:
    source = text or ''
    point = next((p for p in parse_open_points(source) if p.id == point_id), None)
    if point is None:
        return None
    opening = marker_open(point.id, note)
    return source[:point.start] + opening + source[point.content_start:]
