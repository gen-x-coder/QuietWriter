from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QLabel, QListWidget, QListWidgetItem, QPushButton, QVBoxLayout, QWidget

from ..i18n import tr
from ..placeholders import parse_open_points


class OpenPointsPanel(QWidget):
    """Book-level overview of persistent open points in manuscript chapters."""

    openPointRequested = Signal(str, str)
    addRequested = Signal()

    def __init__(self, library):
        super().__init__()
        self.library = library
        self.book = None

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(10)

        title = QLabel(tr('open_points.panel_title', 'Open punten'))
        title.setObjectName('sectionTitle')
        root.addWidget(title)

        intro = QLabel(tr(
            'open_points.panel_intro',
            'Gebruik Open punten in plaats van eigen XXX-, TODO- of ???-notatie. QuietWriter houdt ze bij en waarschuwt je vóór export.'
        ))
        intro.setObjectName('muted')
        intro.setWordWrap(True)
        root.addWidget(intro)

        self.summary = QLabel('')
        self.summary.setObjectName('muted')
        self.summary.setWordWrap(True)
        root.addWidget(self.summary)

        self.list = QListWidget()
        self.list.setObjectName('openPointsList')
        self.list.setAlternatingRowColors(False)
        self.list.itemActivated.connect(self._activate)
        self.list.itemDoubleClicked.connect(self._activate)
        root.addWidget(self.list, 1)

        self.add_button = QPushButton(tr('open_points.add', 'Open punt toevoegen'))
        self.add_button.setObjectName('secondaryButton')
        self.add_button.clicked.connect(self.addRequested.emit)
        root.addWidget(self.add_button)

    def refresh(self, book) -> None:
        self.book = book
        self.list.clear()
        if book is None:
            self.summary.setText(tr('open_points.panel_no_book', 'Open een boek om de open punten te bekijken.'))
            self.add_button.setEnabled(False)
            return

        self.add_button.setEnabled(True)
        rows = []
        for section in book.sections:
            for chapter in section.chapters:
                try:
                    source = self.library.read_chapter(book, chapter)
                except (OSError, UnicodeError):
                    continue
                for point in parse_open_points(source):
                    snippet = ' '.join(point.text.split()).strip() or '[…]'
                    if len(snippet) > 90:
                        snippet = snippet[:87].rstrip() + '…'
                    note = ' '.join(point.note.split()).strip()
                    rows.append((chapter, point, snippet, note))

        count = len(rows)
        if count == 0:
            self.summary.setText(tr(
                'open_points.panel_empty',
                'Geen open punten. Gebruik Toevoegen → Open punt wanneer je iets later wilt aanvullen.'
            ))
        elif count == 1:
            self.summary.setText(tr('open_points.panel_count_one', '1 open punt in dit boek.'))
        else:
            self.summary.setText(tr('open_points.panel_count_many', '{count} open punten in dit boek.', count=count))

        for chapter, point, snippet, note in rows:
            label = f'{chapter.title}\n{snippet}'
            if note:
                label += f'\n{tr("open_points.panel_note", "Notitie")}: {note}'
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, (chapter.id, point.id))
            item.setToolTip(tr('open_points.panel_open_tip', 'Dubbelklik of druk Enter om naar dit open punt te gaan.'))
            self.list.addItem(item)

    def _activate(self, item: QListWidgetItem) -> None:
        data = item.data(Qt.UserRole)
        if not data or len(data) != 2:
            return
        self.openPointRequested.emit(str(data[0]), str(data[1]))
