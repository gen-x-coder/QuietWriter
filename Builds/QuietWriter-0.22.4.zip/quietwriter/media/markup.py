from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path


# QuietWriter creates deliberately conservative block-image Markdown. Asset
# filenames are UUID based and never contain whitespace, which lets the parser
# stay small and deterministic rather than becoming a second Markdown engine.
_IMAGE_RE = re.compile(
    r'!\[(?P<alt>[^\]]*)\]\((?P<path>[^\s\)]+)(?:\s+"(?P<caption>[^"]*)")?\)'
)


@dataclass(frozen=True)
class ImageReference:
    alt: str
    path: str
    caption: str
    start: int
    end: int
    path_start: int
    path_end: int


def _unescape(value: str) -> str:
    return value.replace('\\"', '"').replace('\\]', ']').replace('\\\\', '\\')


def _escape_alt(value: str) -> str:
    return str(value or '').replace('\\', '\\\\').replace(']', '\\]')


def _escape_caption(value: str) -> str:
    return str(value or '').replace('\\', '\\\\').replace('"', '\\"')


def find_image_references(text: str) -> tuple[ImageReference, ...]:
    rows: list[ImageReference] = []
    for match in _IMAGE_RE.finditer(text or ''):
        rows.append(ImageReference(
            alt=_unescape(match.group('alt') or ''),
            path=(match.group('path') or '').replace('\\', '/'),
            caption=_unescape(match.group('caption') or ''),
            start=match.start(), end=match.end(),
            path_start=match.start('path'), path_end=match.end('path'),
        ))
    return tuple(rows)


def image_reference_for_line(line: str) -> ImageReference | None:
    stripped = (line or '').strip()
    match = _IMAGE_RE.fullmatch(stripped)
    if not match:
        return None
    return ImageReference(
        alt=_unescape(match.group('alt') or ''),
        path=(match.group('path') or '').replace('\\', '/'),
        caption=_unescape(match.group('caption') or ''),
        start=0, end=len(stripped),
        path_start=match.start('path'), path_end=match.end('path'),
    )


def build_image_markdown(path: str, alt: str = '', caption: str = '') -> str:
    ref = str(path or '').replace('\\', '/')
    base = f'![{_escape_alt(alt)}]({ref}'
    if str(caption or '').strip():
        base += f' "{_escape_caption(str(caption).strip())}"'
    return base + ')'


def insert_image_block(text: str, position: int, block: str) -> tuple[str, int]:
    """Insert one image as its own Markdown block and return the new cursor position."""
    text = text or ''
    position = max(0, min(int(position), len(text)))
    before = text[:position]
    after = text[position:]
    left = before.rstrip('\n')
    right = after.lstrip('\n')
    prefix = ('\n\n' if left else '')
    suffix = ('\n\n' if right else '')
    result = left + prefix + block.strip() + suffix + right
    cursor = len(left + prefix + block.strip())
    return result, cursor


def _block_image_line_ranges(text: str) -> list[tuple[int, int]]:
    ranges: list[tuple[int, int]] = []
    offset = 0
    for raw in (text or '').splitlines(keepends=True):
        line = raw[:-1] if raw.endswith('\n') else raw
        if image_reference_for_line(line):
            ranges.append((offset, offset + len(line)))
        offset += len(raw)
    return ranges


def text_without_image_blocks(text: str) -> str:
    chars = list(text or '')
    for start, end in _block_image_line_ranges(text or ''):
        for index in range(start, min(end, len(chars))):
            chars[index] = ' '
    return ''.join(chars)


def count_words(text: str) -> int:
    # Preserve QuietWriter's historical whitespace word-count semantics while
    # excluding media syntax, alt text and captions from manuscript statistics.
    return len(text_without_image_blocks(text).split())


def mask_image_paths(text: str) -> str:
    """Mask image syntax/paths while preserving alt and caption source offsets.

    The returned string has exactly the same length as the source. Search and
    spelling can therefore ignore UUID paths yet still select natural alt/caption
    text using the original QTextDocument offsets.
    """
    source = text or ''
    chars = list(source)
    for match in _IMAGE_RE.finditer(source):
        keep: list[tuple[int, int]] = [match.span('alt')]
        if match.group('caption') is not None:
            keep.append(match.span('caption'))
        for index in range(match.start(), match.end()):
            if not any(a <= index < b for a, b in keep):
                chars[index] = ' '
    return ''.join(chars)


def replace_searchable_text(text: str, pattern: re.Pattern, replacement: str) -> str:
    """Replace search matches without ever mutating protected image syntax/paths.

    ``mask_image_paths`` preserves source length, so matches found in the masked
    text map one-to-one to offsets in the original Markdown. Alt text and
    captions intentionally remain searchable/editable; only the managed image
    syntax and asset path stay protected. Replacement text is literal, matching
    the editor's existing replace semantics.
    """
    source = text or ''
    searchable = mask_image_paths(source)
    matches = list(pattern.finditer(searchable))
    if not matches:
        return source
    parts: list[str] = []
    cursor = 0
    for match in matches:
        parts.append(source[cursor:match.start()])
        parts.append(replacement)
        cursor = match.end()
    parts.append(source[cursor:])
    return ''.join(parts)


def text_for_search(text: str) -> str:
    return mask_image_paths(text)


def text_for_ai(text: str) -> str:
    """Replace media source syntax with compact semantic context for AI."""
    source = text or ''

    def repl(match: re.Match) -> str:
        alt = _unescape(match.group('alt') or '').strip()
        caption = _unescape(match.group('caption') or '').strip()
        label = alt or caption or 'afbeelding'
        if alt and caption and caption.casefold() != alt.casefold():
            label = f'{alt} — {caption}'
        return f'[Afbeelding: {label}]'

    return _IMAGE_RE.sub(repl, source)


def relative_asset_reference(chapter_file: str, asset_file: str) -> str:
    chapter_dir = Path(chapter_file).parent
    # os.path.relpath is the clearest cross-platform way to compute the Markdown
    # source reference; convert back to POSIX because Markdown/EPUB use '/'.
    return Path(os.path.relpath(Path(asset_file), chapter_dir)).as_posix()
