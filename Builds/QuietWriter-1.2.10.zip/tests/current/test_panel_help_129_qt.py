import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

import pytest
PySide6 = pytest.importorskip('PySide6')
pytestmark = pytest.mark.qt

from PySide6.QtCore import QSettings
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication

from quietwriter.ui.panel_help import PanelHelp, panel_help_key


def _app():
    return QApplication.instance() or QApplication([])


def test_panel_help_persists_dismiss_and_question_reopens(tmp_path):
    _app()
    settings = QSettings(str(tmp_path / 'settings.ini'), QSettings.IniFormat)
    help_widget = PanelHelp(settings, 'search', 'Zoeken', 'Uitleg voor zoeken.')
    help_widget.show(); QApplication.processEvents()
    assert help_widget.block.isVisible()
    QTest.mouseClick(help_widget.ok, PySide6.QtCore.Qt.LeftButton)
    assert settings.value(panel_help_key('search'), False, bool) is True
    assert not help_widget.block.isVisible()
    QTest.mouseClick(help_widget.toggle, PySide6.QtCore.Qt.LeftButton)
    assert help_widget.block.isVisible()
    assert settings.value(panel_help_key('search'), True, bool) is False


def test_panel_help_wraps_at_narrow_width(tmp_path):
    _app()
    settings = QSettings(str(tmp_path / 'settings.ini'), QSettings.IniFormat)
    widget = PanelHelp(settings, 'search', 'Zoeken', 'Een langere uitleg die op een smal paneel over meerdere regels moet lopen zonder afgekapt te worden.')
    widget.resize(300, 300); widget.show(); QApplication.processEvents(); QTest.qWait(20)
    assert widget.text.height() >= widget.text.heightForWidth(widget.text.width())


def test_panel_help_recomputes_wrapped_height_after_narrow_resize():
    app = _app()
    settings = QSettings(QSettings.IniFormat, QSettings.UserScope, 'QuietWriterTests', 'panel_help_narrow')
    settings.clear()
    text = ('Posez une question sur votre texte, ou sélectionnez un passage et choisissez une action rapide. '
            'La réponse s’affiche ici ; votre manuscrit ne change que si vous le modifiez vous-même. '
            'Sous Contexte, vous voyez ce qui est envoyé.')
    widget = PanelHelp(settings, 'ai', 'Assistant de lecture', text)
    widget.resize(300, 500)
    widget.show()
    app.processEvents()
    QTest.qWait(20)
    assert widget.text.height() >= widget.text.heightForWidth(widget.text.width())
    widget.close()
