# QuietWriter 1.2.10

Deze polishrelease rondt de paneeluitleg en Open-puntenintegratie verder af.

- Open punten verversen direct in het rechterpaneel na toevoegen, ook vóór autosave.
- Spellingscontrole negeert de technische Open-puntmarkeringen volledig.
- Uitleg in smalle rechterpanelen reserveert dynamisch voldoende hoogte, ook bij Engels, Frans en Spaans.
- Help-iconen volgen live een themawissel, ook in panelen die op dat moment gesloten zijn.
- De Meelezer-waarschuwing heeft consistente binnenmarges.
- Toevoegen gebruikt dezelfde titeluitlijning als de overige rechterpanelen.
- De HiDPI-regressietest voor In dit hoofdstuk is aangepast aan de gedeelde PanelHelp-titel.
