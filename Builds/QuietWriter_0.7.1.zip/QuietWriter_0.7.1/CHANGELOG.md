# Changelog

## 0.7.1

- Hoofdstuk verwijderen verplaatst van het linker contextmenu naar een prullenbakactie in de rechter gereedschapsbalk.
- Verwijderen is alleen beschikbaar als er meer dan één hoofdstuk bestaat.
- Voor elke hoofdstukverwijdering wordt automatisch een volledige versie in de tijdlijn gemaakt.
- Na verwijderen wordt eerst het bovenliggende hoofdstuk geladen; alleen als dat niet bestaat het onderliggende.
- Historische previewbalk gebruikt nu een vaste, thema-onafhankelijke kleur met leesbare knoppen in alle zes kleurenschema's.
- Opslaginstelling heet nu generiek `Werkmap`; Dropbox is geen speciaal opslagtype meer.
- Bij herkenning van Dropbox, OneDrive, Google Drive of iCloud in de werkmap verschijnt een waarschuwing over tijdelijke synchronisatie-locks.
- Manuscriptlijst gebruikt geen onduidelijke boom-decoratie meer; titels benutten de volledige tekstkolom en de zes-puntsgreep blijft rechts uitgelijnd.
- Spellingscontrole en rode onderstreping worden pas actief wanneer het spellingspaneel daadwerkelijk wordt geopend.
- Een boek openen selecteert daardoor niet meer automatisch het eerste onbekende woord.
- Extra regressietests toegevoegd voor de hoofdstukkeuze na verwijderen.

## 0.7.0

- Versiegeschiedenis toegevoegd aan de rechter gereedschapsbalk.
- Dagarchieven uit eerdere versies worden automatisch zichtbaar in de tijdlijn.
- Handmatig een volledige boekversie maken vanuit het geschiedenisvenster.
- Historische versies alleen-lezen bekijken zonder het huidige manuscript te wijzigen.
- Duidelijke bovenbalk tijdens versiepreview met datum/tijd, Herstellen en Afsluiten.
- Herstellen maakt eerst automatisch een extra veiligheidsversie en probeert bij fouten terug te rollen.
- Versies kunnen een ster krijgen en de tijdlijn kan op versies met ster filteren.
- Hoofdstuktitels worden nu meegenomen door het spellingscontrolepaneel.
- Manifest- en hoofdstukopslag robuuster gemaakt voor Dropbox/Windows file locks: unieke tijdelijke bestanden, retries en gecontroleerde fallback.
- Drag-and-drop commit nu transactioneel: de in-memory hoofdstukvolgorde wordt pas gewijzigd nadat book.json succesvol is opgeslagen.
- Qt-fontinitialisatie aangepast om ongeldige point-size overerving op Windows te voorkomen.
- Testset uitgebreid naar 22 regressietests, waaronder geschiedenis, herstel en Dropbox-achtige PermissionError-situaties.
