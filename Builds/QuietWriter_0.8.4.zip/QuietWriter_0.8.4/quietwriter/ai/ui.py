from __future__ import annotations
import html
from PySide6.QtCore import QThread, Signal, Qt, QTimer
from PySide6.QtGui import QTextCursor, QTextDocument
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QPushButton,
    QTextEdit, QTextBrowser, QMessageBox, QCheckBox
)
from .providers import ProviderFactory
from .context import ContextBuilder
from .conversations import ConversationStore
from .embedding_cache import EmbeddingCache, cosine
from .retrieval import retrieval_query, local_metadata_rank, dedupe_rows


class ProviderChatWorker(QThread):
    token = Signal(str)
    thinking = Signal(str)
    finished_ok = Signal()
    failed = Signal(str)
    cancelled = Signal()

    def __init__(self, provider, model: str, messages: list[dict], options=None):
        super().__init__()
        self.provider = provider
        self.model = model
        self.messages = messages
        self.options = options or {}
        self._stop = False

    def stop(self):
        self._stop = True
        try:
            self.provider.cancel_active()
        except Exception:
            pass

    def run(self):
        try:
            for chunk in self.provider.stream_chat(self.model, self.messages, **self.options):
                if self._stop:
                    self.cancelled.emit(); return
                if chunk.thinking: self.thinking.emit(chunk.thinking)
                if chunk.content: self.token.emit(chunk.content)
            if self._stop:
                self.cancelled.emit()
            else:
                self.finished_ok.emit()
        except Exception as exc:
            if self._stop:
                self.cancelled.emit()
            else:
                self.failed.emit(str(exc))


class LibrarianWorker(QThread):
    ranked = Signal(object)
    failed = Signal(str)
    cancelled = Signal()
    progress = Signal(str)

    def __init__(self, prompt: str, reference_text: str, catalog: list[dict], lexical: list[dict],
                 fast_provider=None, fast_model: str = '', embedding_provider=None,
                 embedding_model: str = '', cache_path=None):
        super().__init__()
        self.prompt=prompt
        self.reference_text=reference_text or ''
        self.catalog=catalog
        self.lexical=lexical
        self.fast_provider=fast_provider
        self.fast_model=fast_model
        self.embedding_provider=embedding_provider
        self.embedding_model=embedding_model
        self.cache_path=cache_path
        self._stop=False

    def stop(self):
        self._stop=True
        for provider in {id(x): x for x in (self.fast_provider, self.embedding_provider) if x}.values():
            try: provider.cancel_active()
            except Exception: pass

    @staticmethod
    def _compact(c):
        return (
            'Titel: '+str(c.get('title',''))+
            '\nTags: '+str(c.get('tags',''))+
            '\nBeschrijving: '+str(c.get('description',''))[:260]+
            '\nSynopsis: '+str(c.get('synopsis',''))[:620]+
            '\nFragment: '+str(c.get('excerpt',''))[:1400]
        )

    def _semantic(self):
        if self._stop or not (self.embedding_provider and self.embedding_model and self.cache_path):
            return []
        self.progress.emit('Semantisch zoeken in verhalenbibliotheek')
        cache=EmbeddingCache(self.cache_path)
        try:
            qtext=retrieval_query(self.prompt, self.reference_text)
            qv=self.embedding_provider.embed(self.embedding_model,[qtext])
            if self._stop or not qv: return []
            qv=qv[0]; missing=[]; vectors={}
            for row in self.catalog:
                if self._stop: return []
                v=cache.get(str(row.get('path','')),self.embedding_model,float(row.get('mtime',0) or 0))
                if v is None: missing.append(row)
                else: vectors[str(row.get('path',''))]=v
            for offset in range(0,len(missing),12):
                if self._stop: return []
                batch=missing[offset:offset+12]
                self.progress.emit(f'Semantische index bijwerken ({min(offset+len(batch), len(missing))}/{len(missing)})')
                vals=self.embedding_provider.embed(self.embedding_model,[self._compact(x) for x in batch])
                if self._stop: return []
                for row,v in zip(batch,vals):
                    key=str(row.get('path','')); vectors[key]=v
                    cache.put(key,self.embedding_model,float(row.get('mtime',0) or 0),v)
            scored=[]
            for row in self.catalog:
                v=vectors.get(str(row.get('path','')))
                if v: scored.append((cosine(qv,v),row))
            scored.sort(key=lambda x:x[0], reverse=True)
            # Zeer zwakke semantische buren niet blind als bron aanbieden.
            return [row for score,row in scored[:24] if score >= 0.18]
        finally:
            cache.close()

    def _choose_with_fast_model(self, rows):
        import json, re
        if self._stop or not (self.fast_provider and self.fast_model) or not rows:
            return []
        system=(
            'Je bent uitsluitend bibliothecaris voor een schrijver. Je schrijft GEEN verhaaltekst. '
            'Vergelijk de huidige tekst met de catalogus en kies alleen catalogusitems die inhoudelijk echt relevant zijn. '
            'Let op thema, sfeer, setting, personages, conflict, vertelperspectief, tags en synopsis. '
            'Antwoord UITSLUITEND met een JSON-array van maximaal 5 numerieke id’s, bijvoorbeeld [2, 7, 9]. '
            'Kies niets als er geen duidelijke overeenkomst is: antwoord dan [].'
        )
        catalog=[]
        for i,c in enumerate(rows,1):
            catalog.append({
                'id':i,'title':c.get('title',''),'tags':c.get('tags',''),
                'description':str(c.get('description',''))[:240],
                'synopsis':str(c.get('synopsis',''))[:520],
                'excerpt':str(c.get('excerpt',''))[:700],
            })
        ref=self.reference_text[:5000]
        user=(
            f'Vraag van de schrijver: {self.prompt}\n\n'
            f'HUIDIGE TEKST DIE VERGELEKEN MOET WORDEN:\n{ref}\n\n'
            f'CATALOGUS:\n{json.dumps(catalog, ensure_ascii=False)}'
        )
        raw=self.fast_provider.complete(
            self.fast_model,
            [{'role':'system','content':system},{'role':'user','content':user}],
            temperature=0.0,
        )
        if self._stop: return []
        m=re.search(r'\[[^\]]*\]',raw,re.S)
        if not m: return []
        ids=json.loads(m.group(0))
        return [rows[i-1] for i in ids if isinstance(i,int) and 1<=i<=len(rows)][:5]

    def run(self):
        try:
            if self._stop:
                self.cancelled.emit(); return
            local=local_metadata_rank(self.catalog,self.prompt,self.reference_text,20)
            semantic=[]
            if self.embedding_provider and self.embedding_model:
                try:
                    semantic=self._semantic()
                except Exception:
                    # Een falend embeddingmodel mag de hele bibliotheekfunctie nooit breken.
                    semantic=[]
            if self._stop:
                self.cancelled.emit(); return

            strong_pool=dedupe_rows(semantic,self.lexical,local,limit=30)
            if self.fast_provider and self.fast_model:
                self.progress.emit('Bibliothecaris vergelijkt oude verhalen')
                # Zonder semantische kandidaten moet het kleine model de compacte
                # catalogus zelf kunnen bekijken; zo werkt 'welke lijken op deze?'
                source=strong_pool if semantic else self.catalog
                winners=[]
                for offset in range(0,len(source),32):
                    if self._stop:
                        self.cancelled.emit(); return
                    batch=source[offset:offset+32]
                    try:
                        chosen=self._choose_with_fast_model(batch)
                    except Exception:
                        chosen=[]
                    # Bij een fout van het snelle model gebruiken we uitsluitend
                    # reeds onderbouwde lokale/semantische kandidaten, nooit een
                    # willekeurig eerste verhaal uit de catalogus.
                    if chosen:
                        winners.extend(chosen)
                winners=dedupe_rows(winners,limit=12)
                if len(winners)>5:
                    try:
                        reranked=self._choose_with_fast_model(winners)
                    except Exception:
                        reranked=[]
                    if reranked: winners=reranked
                if winners:
                    self.ranked.emit(winners[:5]); return

            fallback=dedupe_rows(semantic,self.lexical,local,limit=5)
            self.ranked.emit(fallback)
        except Exception as exc:
            if self._stop: self.cancelled.emit()
            else: self.failed.emit(str(exc))


def markdown_to_html(text: str) -> str:
    doc = QTextDocument()
    doc.setMarkdown(text or '')
    return doc.toHtml()


class AIPanel(QWidget):
    """Provider-onafhankelijk AI-paneel met veilige worker-lifecycle."""
    def __init__(self, main):
        super().__init__()
        self.main = main
        self.worker = None
        self.librarian = None
        self.current_assistant = ''
        self._thinking_dots = 0
        self._thinking_base = 'Denken'
        self._final_started = False
        self._thinking_text = ''
        self._active_context = None
        self._active_user_index = None
        self._pending_library = None
        self.messages: list[dict] = []
        self.store = None

        self.thinking_timer = QTimer(self); self.thinking_timer.setInterval(350); self.thinking_timer.timeout.connect(self._animate_thinking)
        self.render_timer = QTimer(self); self.render_timer.setSingleShot(True); self.render_timer.setInterval(70); self.render_timer.timeout.connect(lambda: self._render_chat(streaming_placeholder=True))
        lay = QVBoxLayout(self); lay.setContentsMargins(14,14,14,14); lay.setSpacing(8)

        top = QHBoxLayout()
        lab = QLabel('AI-assistent'); lab.setObjectName('sectionTitle')
        self.context = QComboBox(); self.context.addItems(['Huidig hoofdstuk', 'Huidige sectie', 'Hele boek'])
        top.addWidget(lab); top.addStretch(); top.addWidget(self.context)
        lay.addLayout(top)

        source_row = QHBoxLayout()
        self.use_library = QCheckBox('Verhalenbibliotheek meenemen')
        self.use_library.setToolTip('Zoekt relevante oude verhalen op basis van tags, metadata, tekst en optioneel semantische overeenkomst.')
        source_row.addWidget(self.use_library); source_row.addStretch()
        lay.addLayout(source_row)

        self.context_summary = QLabel('Schrijverspersona · Huidig hoofdstuk')
        self.context_summary.setObjectName('muted'); self.context_summary.setWordWrap(True)
        lay.addWidget(self.context_summary)

        context_row = QHBoxLayout()
        self.context_button = QPushButton('Context bekijken'); self.context_button.clicked.connect(self._toggle_context_details)
        self.clear_button = QPushButton('Nieuw gesprek'); self.clear_button.clicked.connect(self.clear_conversation)
        context_row.addWidget(self.context_button); context_row.addStretch(); context_row.addWidget(self.clear_button)
        lay.addLayout(context_row)

        self.context_details = QTextEdit(); self.context_details.setReadOnly(True); self.context_details.setMaximumHeight(120); self.context_details.hide()
        lay.addWidget(self.context_details)

        self.thinking_button = QPushButton('Denken…'); self.thinking_button.setObjectName('thinkingButton'); self.thinking_button.clicked.connect(self._toggle_thinking_details); self.thinking_button.hide()
        self.thinking_details = QTextEdit(); self.thinking_details.setReadOnly(True); self.thinking_details.setMaximumHeight(130); self.thinking_details.setObjectName('thinkingDetails'); self.thinking_details.hide()
        lay.addWidget(self.thinking_button, 0, Qt.AlignLeft); lay.addWidget(self.thinking_details)

        self.chat = QTextBrowser(); self.chat.setOpenExternalLinks(True)
        self.input = QTextEdit(); self.input.setMaximumHeight(120); self.input.setPlaceholderText('Typ een opdracht…')
        self.send_button = QPushButton('Versturen'); self.send_button.clicked.connect(self.send)
        self.stop_button = QPushButton('Stop AI'); self.stop_button.setEnabled(False); self.stop_button.clicked.connect(self.stop_ai)
        button_row=QHBoxLayout(); button_row.addStretch(); button_row.addWidget(self.stop_button); button_row.addWidget(self.send_button)
        lay.addWidget(self.chat, 1); lay.addWidget(self.input); lay.addLayout(button_row)

    def is_busy(self) -> bool:
        return bool((self.worker and self.worker.isRunning()) or (self.librarian and self.librarian.isRunning()))

    def _update_busy_buttons(self):
        busy=self.is_busy()
        self.send_button.setEnabled(not busy)
        self.stop_button.setEnabled(busy)
        self.clear_button.setEnabled(not busy)
        if not busy:
            self.stop_button.setText('Stop AI')

    def set_book(self, book):
        if self.is_busy():
            self.stop_ai()
            self._wait_for_workers(2500)
        self.store = ConversationStore(book) if book else None
        self.messages = self.store.load() if self.store else []
        self._render_chat()

    def clear_conversation(self):
        if self.is_busy(): return
        self.messages = []
        if self.store: self.store.save(self.messages)
        self._render_chat()

    def _provider_model(self):
        provider = ProviderFactory.from_settings(self.main.settings)
        pname = str(self.main.settings.value('ai_provider', 'ollama') or 'ollama').lower()
        key = 'openrouter_model' if pname == 'openrouter' else 'ollama_model'
        return provider, str(self.main.settings.value(key, '') or '')

    def send(self):
        prompt = self.input.toPlainText().strip()
        if not prompt or self.is_busy(): return
        provider, model = self._provider_model()
        if not model:
            QMessageBox.information(self, 'AI', 'Kies eerst een AI-model in Instellingen.'); return
        if not provider.is_available():
            QMessageBox.warning(self, 'AI', 'De geselecteerde AI-provider is niet bereikbaar of niet geconfigureerd.'); return

        builder = ContextBuilder(self.main, provider)
        manuscript_context = builder.build(self.context.currentText(), prompt)
        auto_library = builder.library_intent(prompt)
        want_library = self.use_library.isChecked() or auto_library
        if want_library:
            lexical = builder._library_sources(prompt, 18)
            catalog = self.main.story_index.list_all()
            fast_model = str(self.main.settings.value('fast_model', '') or '')
            embedding_model = str(self.main.settings.value('embedding_model', '') or '')
            local_provider = ProviderFactory.for_name(self.main.settings, 'ollama')
            local_ok = local_provider.is_available()
            # Voorkom dat een embeddingmodel per ongeluk als bibliothecaris wordt gebruikt.
            probable_embed=getattr(local_provider,'probable_embedding_model',lambda _x:False)
            if fast_model and probable_embed(fast_model):
                fast_model=''
            self.input.clear(); self.current_assistant=''; self._final_started=False; self._thinking_text=''
            self._pending_library=(provider,model,prompt,builder,manuscript_context,auto_library,lexical)
            self._start_thinking('Verhalenbibliotheek doorzoeken')
            if catalog and local_ok and (fast_model or embedding_model):
                self.librarian = LibrarianWorker(
                    prompt, manuscript_context.text, catalog, lexical,
                    fast_provider=local_provider if fast_model else None, fast_model=fast_model,
                    embedding_provider=local_provider if embedding_model else None, embedding_model=embedding_model,
                    cache_path=self.main.library.cache_dir / 'story_embeddings.db'
                )
                self.librarian.progress.connect(self._library_progress)
                self.librarian.ranked.connect(self._library_ranked)
                self.librarian.failed.connect(self._library_failed)
                self.librarian.cancelled.connect(self._library_cancelled)
                self.librarian.finished.connect(self._librarian_thread_finished)
                self.librarian.start(); self._update_busy_buttons(); return
            # Ook zonder achtergrondmodel is er een lokale fallback.
            from .retrieval import local_metadata_rank
            fallback=dedupe_rows(lexical,local_metadata_rank(catalog,prompt,manuscript_context.text,5),limit=5)
            self._library_ranked(fallback); return
        self.input.clear()
        self._continue_send(provider, model, prompt, manuscript_context)

    def _library_progress(self, text: str):
        self._thinking_base=text
        self.thinking_button.setText(text+'…')

    def _library_ranked(self, rows):
        if not self._pending_library: return
        provider,model,prompt,builder,manuscript_context,auto_library,_lexical=self._pending_library
        self._pending_library=None
        library_context=builder.library_bundle_from_rows(rows,5)
        context=builder.combine(manuscript_context,library_context,auto_library=auto_library)
        if auto_library and not context.sources:
            self._finish_thinking()
            self._active_context=context
            self.context_summary.setText(' · '.join(context.pieces))
            self.context_details.setPlainText('\n'.join([f'Context: {x}' for x in context.pieces]+['','Geen relevante verhalen in de bibliotheek gevonden.']))
            self.messages.append(ConversationStore.entry('user',prompt,{'pieces':context.pieces,'sources':[],'scope':self.context.currentText(),'library':True}))
            self.messages.append(ConversationStore.entry('assistant','Ik heb geen relevante oude verhalen in je verhalenbibliotheek kunnen vinden voor deze vergelijking. Ik verzin daarom geen titels of vergelijkingen.'))
            if self.store: self.store.save(self.messages)
            self._render_chat(); self._update_busy_buttons(); return
        self._continue_send(provider,model,prompt,context)

    def _library_failed(self, err: str):
        # Laat een achtergrondfout nooit leiden tot hallucinaties. Gebruik alleen
        # lokaal gevonden kandidaten; bij een expliciete bibliotheekvraag en nul
        # kandidaten zal _library_ranked een deterministisch antwoord geven.
        if not self._pending_library: return
        *_, lexical = self._pending_library
        self._library_ranked(lexical[:5])

    def _library_cancelled(self):
        self._finish_thinking()
        if self._pending_library:
            _provider,_model,prompt,*_=self._pending_library
            if not self.input.toPlainText().strip(): self.input.setPlainText(prompt)
        self._pending_library=None
        self.context_summary.setText('AI gestopt.')

    def _librarian_thread_finished(self):
        obj=self.librarian
        self.librarian=None
        if obj is not None: obj.deleteLater()
        self._update_busy_buttons()

    def _continue_send(self, provider, model: str, prompt: str, context):
        self._active_context = context
        self.context_summary.setText(' · '.join(context.pieces))
        lines=[f'Context: {x}' for x in context.pieces]
        if context.sources:
            lines += ['', 'Geraadpleegde verhalen:']
            lines += [f"• {x['title']}" + (f" — {x['tags']}" if x.get('tags') else '') for x in context.sources]
        self.context_details.setPlainText('\n'.join(lines))
        persona=self.main.library.read_persona()
        max_chars=int(self.main.settings.value('ai_context_chars', 24000) or 24000)
        context_text=context.text
        if len(context_text)>max_chars:
            context_text=context_text[:max_chars]+'\n\n[… context automatisch ingekort om binnen het modelvenster te blijven …]'
        allowed='\n'.join(f"- {s.get('title','')}" for s in context.sources)
        library_rule=(
            '\n\nBIBLIOTHEEKBRONNEN DIE JE MAG GEBRUIKEN:\n'+allowed+
            '\nGebruik bij uitspraken over oude verhalen uitsluitend deze titels en de meegeleverde inhoud. '
            'Noem geen andere werken als voorbeelden uit de bibliotheek.'
        ) if context.sources else ''
        system=(
            'Je bent de schrijf- en redactieassistent van de gebruiker. Beantwoord altijd eerst en precies de concrete opdracht van de gebruiker. '
            'Gebruik ALTIJD het onderstaande schrijversprofiel als stijl- en beoordelingskader, maar herschrijf of genereer geen nieuw verhaal tenzij daarom wordt gevraagd. '
            'Pas nooit rechtstreeks manuscriptbestanden aan. Geef wijzigingen, herschrijvingen en suggesties uitsluitend in je antwoord. '
            'Wanneer informatie ontbreekt, zeg dat expliciet. Verzin NOOIT titels, samenvattingen of inhoud van verhalen uit de verhalenbibliotheek. '
            'Bij een vergelijkingsvraag geef je een vergelijking; verander die opdracht niet in een nieuwe schrijfopdracht.\n\n'
            f'SCHRIJVERSPROFIEL:\n{persona}\n\nCONTEXT ({context.label}):\n{context_text}{library_rule}'
        )
        self.messages.append(ConversationStore.entry('user',prompt,{'pieces':context.pieces,'sources':context.sources,'scope':self.context.currentText(),'library': bool(context.sources)}))
        self._active_user_index=len(self.messages)-1
        self.current_assistant=''; self._final_started=False; self._thinking_text=''
        self._render_chat(streaming_placeholder=True); self._start_thinking('Denken')
        recent=[{'role':m['role'],'content':m['content']} for m in self.messages[-12:] if m.get('role') in {'user','assistant'}]
        messages=[{'role':'system','content':system}]+recent
        self.worker=ProviderChatWorker(provider,model,messages,options={'temperature':0.45})
        self.worker.token.connect(self._token); self.worker.thinking.connect(self._thinking)
        self.worker.failed.connect(self._fail); self.worker.finished_ok.connect(self._done)
        self.worker.cancelled.connect(self._chat_cancelled); self.worker.finished.connect(self._chat_thread_finished)
        self.worker.start(); self._update_busy_buttons()

    def stop_ai(self):
        any_running=False
        if self.librarian and self.librarian.isRunning():
            any_running=True; self.librarian.stop()
        if self.worker and self.worker.isRunning():
            any_running=True; self.worker.stop()
        if any_running:
            self.stop_button.setEnabled(False); self.stop_button.setText('Stoppen…')
            self._thinking_base='Stoppen'; self.thinking_button.setText('Stoppen…')

    def _wait_for_workers(self, timeout_ms=3000) -> bool:
        workers=[w for w in (self.librarian,self.worker) if w and w.isRunning()]
        if not workers: return True
        per=max(200,int(timeout_ms/max(1,len(workers))))
        return all(w.wait(per) for w in workers)

    def shutdown(self, timeout_ms=4000) -> bool:
        self.stop_ai()
        return self._wait_for_workers(timeout_ms)

    def _start_thinking(self, base='Denken'):
        self._thinking_base=base; self._thinking_dots = 0
        self.thinking_details.clear(); self.thinking_details.hide()
        self.thinking_button.setText(base+'…'); self.thinking_button.show(); self.thinking_timer.start()

    def _animate_thinking(self):
        self._thinking_dots = (self._thinking_dots + 1) % 4
        self.thinking_button.setText(self._thinking_base + '.' * (self._thinking_dots + 1))

    def _toggle_thinking_details(self):
        if self._thinking_text.strip(): self.thinking_details.setVisible(not self.thinking_details.isVisible())

    def _toggle_context_details(self):
        self.context_details.setVisible(not self.context_details.isVisible())

    def _thinking(self, text):
        self._thinking_text += text
        self.thinking_details.setPlainText(self._thinking_text)
        cur = self.thinking_details.textCursor(); cur.movePosition(QTextCursor.End); self.thinking_details.setTextCursor(cur)

    def _finish_thinking(self):
        self.thinking_timer.stop(); self.thinking_details.clear(); self.thinking_details.hide(); self.thinking_button.hide(); self._thinking_text = ''

    def _token(self, text):
        if not self._final_started:
            self._final_started = True; self._finish_thinking()
        self.current_assistant += text
        if not self.render_timer.isActive(): self.render_timer.start()

    def _done(self):
        self._finish_thinking()
        if self.current_assistant.strip():
            context = self._active_context
            self.messages.append(ConversationStore.entry('assistant', self.current_assistant, {'pieces': context.pieces if context else [], 'sources': context.sources if context else []}))
            if self.store: self.store.save(self.messages)
        self._active_user_index=None
        self.render_timer.stop(); self.current_assistant = ''; self._render_chat()

    def _fail(self, err):
        self._finish_thinking(); self.current_assistant=''
        self.messages.append(ConversationStore.entry('assistant', f'Fout: {err}'))
        self._active_user_index=None
        if self.store: self.store.save(self.messages)
        self._render_chat()

    def _chat_cancelled(self):
        self._finish_thinking(); self.render_timer.stop(); self.current_assistant=''
        # Een gestopte opdracht wordt niet als half gesprek bewaard.
        if self._active_user_index is not None and self._active_user_index == len(self.messages)-1:
            if self.messages[self._active_user_index].get('role') == 'user':
                self.messages.pop()
        self._active_user_index=None
        self.context_summary.setText('AI gestopt.')
        self._render_chat()

    def _chat_thread_finished(self):
        obj=self.worker
        self.worker=None
        if obj is not None: obj.deleteLater()
        self._update_busy_buttons()

    def _render_chat(self, streaming_placeholder=False):
        blocks=[]
        for msg in self.messages:
            role = msg.get('role'); content = msg.get('content','')
            if role == 'user':
                body = html.escape(content).replace('\n','<br>'); blocks.append(f'<p><b>Jij</b><br>{body}</p>')
            else:
                blocks.append(f'<p><b>AI</b></p>{markdown_to_html(content)}')
                sources = (msg.get('context') or {}).get('sources') or []
                if sources:
                    names = ', '.join(html.escape(s.get('title','')) for s in sources)
                    blocks.append(f'<p style="color:#777;font-size:9pt">Gebruikte verhalen: {names}</p>')
        if streaming_placeholder and self.current_assistant:
            blocks.append('<p><b>AI</b></p>' + markdown_to_html(self.current_assistant))
        self.chat.setHtml('<html><body>' + '<hr>'.join(blocks) + '</body></html>')
        cur=self.chat.textCursor(); cur.movePosition(QTextCursor.End); self.chat.setTextCursor(cur)
