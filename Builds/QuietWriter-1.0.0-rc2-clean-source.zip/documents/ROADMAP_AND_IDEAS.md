# QuietWriter — roadmap en ideeën

## Beslisregel
Nieuwe functies worden niet gebouwd omdat ze technisch interessant zijn. Eerst moet er een concreet gebruikersprobleem of aantoonbare kwaliteitswinst zijn. Grote subsystemen vragen UX-, data/migratie- en testontwerp vooraf.

## Nu: richting stabiele 1.0
Feature freeze. Alleen regressie-, data-, release- en noodzakelijke documentatie/testfixes.

Praktijkvalidatie:
- clean Windows zonder Python;
- SmartScreen;
- 100/125/150% en waar mogelijk mixed DPI;
- echte Ollama cold start;
- echte OpenRouter-vraag;
- groot boek (~150k woorden/40 hoofdstukken);
- meerdere oude echte boeken;
- langere periode dagelijks schrijven;
- twee-machine syncscenario waar praktisch mogelijk.

## Kort na 1.0 — kleine duidelijke verbeteringen
- OpenRouter free-only displaymismatch: opgeslagen betaald model zichtbaar houden met markering i.p.v. een ander gratis model tonen.
- AI-contextbudget: begrenzen zonder stille inhoudelijke afkapping, met inzicht in wat wel/niet meegaat.
- Diagnostiek per start uitbreiden met versie/Qt/OS/DPI zonder manuscript of secrets te loggen.
- Logging zo vroeg mogelijk vóór/om QApplication zodat platform-pluginfouten beter zichtbaar zijn.
- Alleen Boekprofiel/Boekgeheugen bezoeken idealiter geen leeg sjabloonbestand laten materialiseren.
- Enkele generieke meldteksten aanscherpen.

## Planning en worldbuilding — onderzoeken
- scènes vrij tussen hoofdstukken herschikken, maar met één canonieke structuurmutatie;
- inklapbare hoofdstukgroepen;
- compactere inline-scènebewerking;
- personageportretten;
- eerste verschijning / belangrijke hoofdstukken;
- rijkere relatiebeschrijvingen of visuele relaties;
- wiki-achtige `[[links]]`;
- locaties als eigen entiteit;
- tijdlijn / chronologie;
- Kanban/alternatieve outlineweergave;
- genre-specifieke custom fields;
- lokale aliasherkenning;
- AI-voorstellen voor feiten/stemprofielen, uitsluitend als voorstel met user approval.

## Publicatie/export — onderzoeken of praktijkgedreven
- echte exportpreview uit dezelfde renderpipeline;
- meer printfijninstellingen (marges, hoofdstukstarts, recto/verso, page breaks);
- schutblad / half-title;
- expliciete blanco pagina's;
- meer TOC-niveaus wanneer structuur dat vraagt;
- vrij definieerbare voor-/achterwerkonderdelen;
- meer reader-validatie alleen bij concrete compatibiliteitsproblemen;
- automatische optimalisatie van zeer grote afbeeldingen bij aantoonbaar probleem;
- rijkere inline image preview alleen als huidige protected-block UX onvoldoende blijkt.

## Editor
- spellingscontextmenu kan nuttig zijn als bestaande paneelflow te omslachtig blijkt;
- hover is geen doel op zichzelf;
- geen extra focus-/distraction modes zonder concrete behoefte; QuietWriter is al bewust rustig.

## AI
- providercompatibiliteit/streaming/cancellation/capabilities blijven testen;
- nieuwe snelacties alleen als Meelezeracties (analyseren/feedback/controle), nooit manuscriptgeneratie;
- nieuwe contextbronnen alleen zichtbaar, inspecteerbaar en privacybewust;
- eventueel vriendelijkere lokale Ollama-modelsetup, geen eigen modelruntime zonder sterke reden.

## Platform/distributie
- installer: post-1.0, alleen met duidelijk upgrade/uninstall/signingmodel;
- auto-updater: pas met signing, rollback en stabiele releasecadans;
- code signing: onderzoeken als kosten/beheer zinvol zijn;
- macOS/Linux builds: later, aparte productbeslissing.

## Productonderzoek
Voor grote uitbreidingen eerst vergelijken met o.a. Reedsy, Scrivener en Obsidian-achtige linking. Niet streven naar feature parity; alleen leren welke flows echte schrijfproblemen oplossen.

## Bewust afgewezen / alleen heroverwegen bij productwijziging
- AI als ghostwriter;
- Herschrijf selectie;
- autonome Boekgeheugenwrites;
- automatische reparatie bij openen;
- stille migratie in load;
- future-format downgraden;
- agressieve media-cleanup;
- ongeregistreerde assets automatisch verwijderen;
- Dropbox-specifieke lockarchitectuur als kernstrategie;
- tweede onafhankelijke hoofdstukvolgorde in Planning;
- volwaardige coverdesigner;
- complexe DTP-editor.

## Historisch 'later' maar inmiddels uitgevoerd
Integriteit/Herstel, PDF, EPUB-validatie, Media Manager, Planning-context, 'In dit hoofdstuk', hoofdstukplanning opt-in voor AI, first-run, runtimeprofielen, Windows portable build, CI/releaseautomatisering, OpenRouter gratis-filter en globale tekstbreedte.

## Nieuwe ideeën toevoegen
Leg eerst vast: probleem, doel, status, risico, afhankelijkheden en waarom dit nu prioriteit heeft. Daarna pas implementatie plannen.
