# QuietWriter 1.0.0-rc2

RC2 is een stabiliteits- en releasecandidate zonder nieuwe grote functies.

Belangrijk sinds RC1:
- publieke portable package bevat geen interne DEV/PROD launchers;
- Windows smoke gebruikt de echte GUI-process exitcode;
- zoekcache/SQLite-afhandeling is verder afgehard en sluit handles expliciet;
- release-/versiemetadata is bijgewerkt;
- volledige Windows- en Ubuntu-testmatrix was groen in de releasecyclus.

Bekende niet-blokkerende beperking: met OpenRouter free-only kan een bewaard betaald model veilig persisted blijven terwijl de UI na catalogusload een gratis selectie toont. Dit is UX-verwarring, geen dataverlies.

Voor stabiele 1.0 blijven vooral praktijkchecks over: clean Windows, SmartScreen, DPI, echte providers, oude/grote boeken en langer dagelijks gebruik.
