APP_NAME = "QuietWriter"
__version__ = "0.28.3"
