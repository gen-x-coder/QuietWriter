from PySide6.QtWidgets import QDialogButtonBox, QInputDialog, QMessageBox
from ..i18n import tr

def confirm(parent, title: str, text: str, default_no: bool = True) -> bool:
    """Central Ja/Nee confirmation dialog using translated button labels."""
    box = QMessageBox(parent)
    box.setIcon(QMessageBox.Warning)
    box.setWindowTitle(title)
    box.setText(text)
    yes = box.addButton(tr('common.yes', 'Ja'), QMessageBox.YesRole)
    no = box.addButton(tr('common.no', 'Nee'), QMessageBox.NoRole)
    box.setDefaultButton(no if default_no else yes)
    box.exec()
    return box.clickedButton() is yes


def prompt_text(parent, title: str, label: str, text: str = '') -> tuple[str, bool]:
    """Localized single-line text prompt with QuietWriter button labels."""
    dialog = QInputDialog(parent)
    dialog.setWindowTitle(title)
    dialog.setLabelText(label)
    dialog.setTextValue(text)
    buttons = dialog.findChild(QDialogButtonBox)
    if buttons is not None:
        ok = buttons.button(QDialogButtonBox.Ok)
        cancel = buttons.button(QDialogButtonBox.Cancel)
        if ok is not None:
            ok.setText(tr('common.save', 'Opslaan'))
        if cancel is not None:
            cancel.setText(tr('common.cancel', 'Annuleren'))
    accepted = dialog.exec() == QInputDialog.Accepted
    return dialog.textValue(), accepted
