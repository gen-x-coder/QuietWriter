from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Iterator


@dataclass
class StreamChunk:
    content: str = ''
    thinking: str = ''


class ContextWindowError(RuntimeError):
    """Provider meldt dat de prompt niet in het actieve contextvenster past."""
    def __init__(self, message: str, prompt_tokens: int | None = None, available_tokens: int | None = None):
        super().__init__(message)
        self.prompt_tokens = prompt_tokens
        self.available_tokens = available_tokens


class AIProvider(ABC):
    """Provider-onafhankelijke AI-interface."""
    name = 'provider'

    @abstractmethod
    def is_available(self) -> bool: ...

    @abstractmethod
    def list_models(self) -> list[dict]: ...

    @abstractmethod
    def stream_chat(self, model: str, messages: list[dict], **options) -> Iterator[StreamChunk]: ...

    def complete(self, model: str, messages: list[dict], **options) -> str:
        parts: list[str] = []
        for chunk in self.stream_chat(model, messages, **options):
            if chunk.content:
                parts.append(chunk.content)
        return ''.join(parts)

    def embed(self, model: str, texts: list[str]) -> list[list[float]]:
        raise NotImplementedError(f'{self.name} ondersteunt in QuietWriter nog geen embeddings.')

    def cancel_active(self) -> None:
        return None

    def model_capabilities(self, model: str) -> set[str]:
        return set()

    def supports_chat(self, model: str) -> bool:
        caps = self.model_capabilities(model)
        return not caps or 'completion' in caps or 'chat' in caps

    def supports_embeddings(self, model: str) -> bool:
        caps = self.model_capabilities(model)
        return 'embedding' in caps or 'embeddings' in caps

    def context_window(self, model: str) -> int | None:
        return None

    def context_info(self, model: str) -> dict:
        """Best-effort informatie over model/runtime-context."""
        return {
            'model_max': self.context_window(model),
            'active_window': None,
            'configured_window': None,
        }

    def context_options(self, window: int, *, maximum: int | None = None) -> dict:
        """Provider-specifieke requestopties om een runtimevenster te kiezen."""
        return {}


class ProviderFactory:
    @staticmethod
    def for_name(settings, provider: str):
        provider = str(provider or 'ollama').lower()
        if provider == 'openrouter':
            from .openrouter_provider import OpenRouterProvider
            return OpenRouterProvider(
                api_key=str(settings.value('openrouter_api_key', '') or ''),
                base_url=str(settings.value('openrouter_url', 'https://openrouter.ai/api/v1') or 'https://openrouter.ai/api/v1'),
            )
        from .ollama_provider import OllamaProvider
        return OllamaProvider(str(settings.value('ollama_url', 'http://127.0.0.1:11434') or 'http://127.0.0.1:11434'))

    @staticmethod
    def from_settings(settings):
        return ProviderFactory.for_name(settings, str(settings.value('ai_provider', 'ollama') or 'ollama'))
