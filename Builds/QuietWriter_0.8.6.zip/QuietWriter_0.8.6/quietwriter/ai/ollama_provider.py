from __future__ import annotations
import json
import threading
import requests
from .providers import AIProvider, StreamChunk, ContextWindowError
from .context_budget import next_context_window


class OllamaProvider(AIProvider):
    name = 'ollama'

    def __init__(self, base_url='http://127.0.0.1:11434'):
        self.base_url = base_url.rstrip('/')
        self._response_lock = threading.Lock()
        self._active_response = None
        self._cancelled = False

    @staticmethod
    def probable_embedding_model(name: str) -> bool:
        n = (name or '').casefold()
        return any(x in n for x in ('embed', 'embedding', 'bge-', 'e5-', 'minilm'))

    def _set_active(self, response):
        with self._response_lock:
            self._active_response = response
            self._cancelled = False

    def _clear_active(self, response=None):
        with self._response_lock:
            if response is None or self._active_response is response:
                self._active_response = None

    def cancel_active(self) -> None:
        with self._response_lock:
            self._cancelled = True
            response = self._active_response
        if response is not None:
            try:
                response.close()
            except Exception:
                pass

    @staticmethod
    def _error_detail(r) -> str:
        try:
            data = r.json()
            detail = data.get('error') if isinstance(data, dict) else None
            if detail:
                return str(detail)
        except Exception:
            pass
        text = (getattr(r, 'text', '') or '').strip()
        return text[:500] if text else f'HTTP {r.status_code}'

    @classmethod
    def _raise_detailed(cls, r, prefix='Ollama'):
        if r.ok:
            return
        raise RuntimeError(f'{prefix}: {cls._error_detail(r)}')

    def list_models(self) -> list[dict]:
        r = requests.get(f'{self.base_url}/api/tags', timeout=2.5)
        self._raise_detailed(r, 'Ollama modellen ophalen mislukt')
        return [
            {'name': m.get('name', ''), 'size': int(m.get('size', 0) or 0)}
            for m in r.json().get('models', []) if m.get('name')
        ]

    def model_capabilities(self, model: str) -> set[str]:
        if not model:
            return set()
        try:
            r = requests.post(f'{self.base_url}/api/show', json={'model': model}, timeout=4)
            self._raise_detailed(r, f'Ollama modelinformatie mislukt voor {model}')
            caps = r.json().get('capabilities') or []
            return {str(x).casefold() for x in caps}
        except Exception:
            # Voor oudere Ollama-versies die capabilities nog niet teruggeven,
            # blijft een veilige naamheuristiek beschikbaar.
            return {'embedding'} if self.probable_embedding_model(model) else set()

    def supports_chat(self, model: str) -> bool:
        caps = self.model_capabilities(model)
        if 'embedding' in caps and 'completion' not in caps and 'chat' not in caps:
            return False
        if not caps and self.probable_embedding_model(model):
            return False
        return True

    def supports_embeddings(self, model: str) -> bool:
        caps = self.model_capabilities(model)
        return 'embedding' in caps or 'embeddings' in caps or self.probable_embedding_model(model)


    def _show_model(self, model: str) -> dict:
        if not model:
            return {}
        r = requests.post(f'{self.base_url}/api/show', json={'model': model}, timeout=4)
        self._raise_detailed(r, f'Ollama modelinformatie mislukt voor {model}')
        return r.json()

    @staticmethod
    def _show_context_values(data: dict) -> tuple[int | None, int | None]:
        import re
        info = data.get('model_info') or {}
        values=[]
        for key, value in info.items():
            if str(key).casefold().endswith('context_length'):
                try:
                    n=int(value)
                    if n>0: values.append(n)
                except Exception:
                    pass
        model_max=max(values) if values else None
        configured=None
        params=str(data.get('parameters') or '')
        m=re.search(r'num_ctx\s+(\d+)', params)
        if m:
            configured=int(m.group(1))
        return model_max, configured

    def _active_model_info(self, model: str) -> dict:
        try:
            r=requests.get(f'{self.base_url}/api/ps', timeout=3)
            self._raise_detailed(r, 'Ollama actieve modellen ophalen mislukt')
            for row in r.json().get('models', []) or []:
                names={str(row.get('name','')), str(row.get('model',''))}
                if model in names:
                    return row
        except Exception:
            pass
        return {}

    def context_info(self, model: str) -> dict:
        model_max=configured=None
        try:
            model_max, configured=self._show_context_values(self._show_model(model))
        except Exception:
            pass
        active=self._active_model_info(model)
        try:
            active_window=int(active.get('context_length') or 0) or None
        except Exception:
            active_window=None
        return {
            'model_max': model_max or configured or active_window,
            'configured_window': configured,
            'active_window': active_window,
            'size': int(active.get('size') or 0),
            'size_vram': int(active.get('size_vram') or 0),
        }

    def context_window(self, model: str) -> int | None:
        return self.context_info(model).get('model_max')

    def context_options(self, window: int, *, maximum: int | None = None) -> dict:
        opts={'num_ctx': int(window)}
        if maximum:
            opts['_max_num_ctx']=int(maximum)
        return opts

    def is_available(self) -> bool:
        try:
            self.list_models(); return True
        except Exception:
            return False

    @staticmethod
    def _split_think_stream(text: str, state: dict):
        state['buffer'] = state.get('buffer', '') + text
        out = []
        while state['buffer']:
            if state.get('thinking', False):
                pos = state['buffer'].find('</think>')
                if pos >= 0:
                    if pos: out.append(StreamChunk(thinking=state['buffer'][:pos]))
                    state['buffer'] = state['buffer'][pos+8:]
                    state['thinking'] = False
                    continue
                keep = 0
                for n in range(min(7, len(state['buffer'])), 0, -1):
                    if '</think>'.startswith(state['buffer'][-n:]): keep = n; break
                emit = state['buffer'][:-keep] if keep else state['buffer']
                if emit: out.append(StreamChunk(thinking=emit))
                state['buffer'] = state['buffer'][-keep:] if keep else ''
                break
            else:
                pos = state['buffer'].find('<think>')
                if pos >= 0:
                    if pos: out.append(StreamChunk(content=state['buffer'][:pos]))
                    state['buffer'] = state['buffer'][pos+7:]
                    state['thinking'] = True
                    continue
                keep = 0
                for n in range(min(6, len(state['buffer'])), 0, -1):
                    if '<think>'.startswith(state['buffer'][-n:]): keep = n; break
                emit = state['buffer'][:-keep] if keep else state['buffer']
                if emit: out.append(StreamChunk(content=emit))
                state['buffer'] = state['buffer'][-keep:] if keep else ''
                break
        return out

    @staticmethod
    def _context_error(r) -> ContextWindowError | None:
        try:
            data=r.json()
        except Exception:
            return None
        err=data.get('error') if isinstance(data,dict) else None
        if not isinstance(err,dict):
            return None
        msg=str(err.get('message') or '')
        low=msg.casefold()
        if 'context size' not in low and 'context length' not in low and 'exceed_context' not in str(err.get('type','')).casefold():
            return None
        def num(key):
            try: return int(err.get(key))
            except Exception: return None
        return ContextWindowError(msg or 'Prompt past niet in het contextvenster.', num('n_prompt_tokens'), num('n_ctx'))

    def stream_chat(self, model: str, messages: list[dict], **options):
        options=dict(options or {})
        max_num_ctx=options.pop('_max_num_ctx', None)
        state = {'buffer': '', 'thinking': False}
        attempts=0
        while True:
            attempts += 1
            payload = {'model': model, 'messages': messages, 'stream': True}
            if options:
                payload['options'] = {k: v for k, v in options.items() if v is not None}
            r = requests.post(f'{self.base_url}/api/chat', json=payload, stream=True, timeout=(5, 900))
            self._set_active(r)
            if not r.ok:
                ctx_err=self._context_error(r)
                if ctx_err and attempts < 3:
                    current=int(options.get('num_ctx') or ctx_err.available_tokens or 0)
                    maximum=max_num_ctx
                    if maximum is None:
                        try: maximum=self.context_window(model)
                        except Exception: maximum=None
                    needed=(ctx_err.prompt_tokens or current or 8192) + 2048
                    target=next_context_window(needed, maximum)
                    try: r.close()
                    except Exception: pass
                    self._clear_active(r)
                    if target > current:
                        options['num_ctx']=target
                        state={'buffer':'','thinking':False}
                        continue
                    raise ctx_err
                try:
                    self._raise_detailed(r, f'Ollama chat mislukt voor model {model}')
                finally:
                    try: r.close()
                    except Exception: pass
                    self._clear_active(r)
            try:
                for line in r.iter_lines(decode_unicode=True):
                    if self._cancelled:
                        break
                    if not line: continue
                    data = json.loads(line)
                    message = data.get('message') or {}
                    thought = message.get('thinking') or ''
                    if thought:
                        yield StreamChunk(thinking=thought)
                    content = message.get('content') or ''
                    if content:
                        yield from self._split_think_stream(content, state)
                    if data.get('done'): break
            finally:
                try: r.close()
                except Exception: pass
                self._clear_active(r)
            break
        if not self._cancelled and state.get('buffer'):
            if state.get('thinking'): yield StreamChunk(thinking=state['buffer'])
            else: yield StreamChunk(content=state['buffer'])

    def embed(self, model: str, texts: list[str]) -> list[list[float]]:
        r = requests.post(
            f'{self.base_url}/api/embed',
            json={'model': model, 'input': texts, 'truncate': True},
            stream=True,
            timeout=(5, 900),
        )
        self._set_active(r)
        try:
            self._raise_detailed(r, f'Ollama embeddings mislukt voor model {model}')
            data = r.json()
            if self._cancelled:
                return []
            return data.get('embeddings') or []
        finally:
            try: r.close()
            except Exception: pass
            self._clear_active(r)
