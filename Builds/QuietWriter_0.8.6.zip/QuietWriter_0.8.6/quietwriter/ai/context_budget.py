from __future__ import annotations

"""Contextbudgettering voor AI-chat.

QuietWriter kent niet voor ieder model exact dezelfde tokenizer. Daarom gebruiken we
vooraf een conservatieve schatting, kiezen we automatisch het kleinste bruikbare
contextvenster en laten we providers waar mogelijk het echte runtime-contextvenster
instellen. Ollama kan bij een onderschatting bovendien automatisch één stap groter
proberen op basis van de exacte tokenfout die Ollama zelf teruggeeft.
"""

STANDARD_CONTEXT_WINDOWS = (4096, 8192, 16384, 32768, 65536, 131072, 262144)


def estimate_tokens(text: str) -> int:
    # Nederlandse proza ligt vaak rond 3-4 tekens/token. 3.0 is bewust
    # conservatief zodat we eerder een groter venster kiezen dan te klein.
    return max(1, (len(text or '') + 2) // 3)


def message_tokens(messages: list[dict]) -> int:
    return sum(estimate_tokens(str(m.get('content', ''))) + 8 for m in messages)


def trim_text(text: str, max_chars: int) -> str:
    text = text or ''
    if len(text) <= max_chars:
        return text
    if max_chars < 400:
        return text[:max_chars]
    marker = '\n\n[… context ingekort …]\n\n'
    room = max_chars - len(marker)
    before = int(room * 0.68)
    after = room - before
    return text[:before] + marker + text[-after:]


def _normalize_limit(value) -> int | None:
    try:
        n = int(value)
        return n if n > 0 else None
    except Exception:
        return None


def next_context_window(required_tokens: int, maximum: int | None = None) -> int:
    """Kies het kleinste gangbare venster dat required_tokens past."""
    required = max(2048, int(required_tokens or 0))
    maximum = _normalize_limit(maximum)
    for size in STANDARD_CONTEXT_WINDOWS:
        if size >= required:
            return min(size, maximum) if maximum else size
    return maximum or STANDARD_CONTEXT_WINDOWS[-1]


def choose_context_window(
    estimated_input_tokens: int,
    *,
    model_max: int | None = None,
    active_window: int | None = None,
    configured_window: int | None = None,
    user_limit: int | None = None,
    reserve_output: int = 2048,
) -> dict:
    """Plan het runtime-contextvenster.

    Strategie:
    - reserveer ruimte voor antwoord en protocolmarge;
    - behoud een reeds geladen venster als dat groot genoeg is;
    - anders kies het kleinste standaardvenster dat past;
    - overschrijd nooit modelmaximum of een expliciete gebruikerslimiet;
    - als de volledige prompt niet kan passen, geeft ``needs_trim`` dat aan.
    """
    estimated = max(1, int(estimated_input_tokens or 1))
    model_max = _normalize_limit(model_max)
    active = _normalize_limit(active_window)
    configured = _normalize_limit(configured_window)
    user_limit = _normalize_limit(user_limit)

    hard_max = model_max
    if user_limit:
        hard_max = min(hard_max, user_limit) if hard_max else user_limit

    reserve = max(1024, int(reserve_output or 2048))
    # Bij zeer kleine modellen niet meer dan circa een kwart voor uitvoer reserveren.
    if hard_max and hard_max <= 8192:
        reserve = min(reserve, max(1024, hard_max // 4))
    required = estimated + reserve + 256

    preferred_min = max(x for x in (4096, configured or 0) if x)

    if active and active >= required:
        chosen = active
    else:
        chosen = next_context_window(max(required, preferred_min), hard_max)

    if hard_max:
        chosen = min(chosen, hard_max)
    chosen = max(2048, chosen)

    return {
        'window': chosen,
        'model_max': model_max,
        'active_window': active,
        'configured_window': configured,
        'user_limit': user_limit,
        'estimated_full_input_tokens': estimated,
        'reserve_output': reserve,
        'required_tokens': required,
        'needs_trim': required > chosen,
        'automatic': user_limit is None,
    }


def fit_messages(system_builder, context_text: str, history: list[dict], context_window: int | None,
                 reserve_output: int = 1800) -> tuple[list[dict], str, dict]:
    """Maak een prompt die ruim binnen het gekozen contextvenster blijft.

    system_builder(context) moet de volledige system prompt teruggeven. De laatste
    user-opdracht blijft altijd behouden. Oudere chatgeschiedenis valt als eerste af.
    """
    original_context = context_text or ''
    window = int(context_window or 8192)
    reserve = min(max(1024, int(reserve_output or 1800)), max(1024, window // 3))
    input_budget = max(1400, window - reserve - 256)

    hist = list(history or [])

    while len(hist) > 1:
        system = system_builder(context_text)
        msgs = [{'role': 'system', 'content': system}] + hist
        if message_tokens(msgs) <= input_budget:
            break
        hist.pop(0)

    system = system_builder(context_text)
    msgs = [{'role': 'system', 'content': system}] + hist
    if message_tokens(msgs) > input_budget:
        lo, hi = 0, len(context_text)
        best = ''
        while lo <= hi:
            mid = (lo + hi) // 2
            candidate = trim_text(context_text, mid)
            trial = [{'role': 'system', 'content': system_builder(candidate)}] + hist
            if message_tokens(trial) <= input_budget:
                best = candidate
                lo = mid + 1
            else:
                hi = mid - 1
        context_text = best
        system = system_builder(context_text)
        msgs = [{'role': 'system', 'content': system}] + hist

    info = {
        'context_window': window,
        'input_budget': input_budget,
        'estimated_input_tokens': message_tokens(msgs),
        'reserve_output': reserve,
        'history_messages': len(hist),
        'context_trimmed': len(context_text) < len(original_context),
    }
    return msgs, context_text, info
