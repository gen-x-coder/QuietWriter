# QuietWriter 0.8.6

## 0.8.6 — Slim automatisch contextvenster

- Vaste 8192-tokenlimiet vervangen door automatische contextplanning per model en opdracht.
- Ollama-modelmaximum wordt gelezen uit `/api/show`; een reeds geladen runtimecontext uit `/api/ps` wordt hergebruikt wanneer die groot genoeg is.
- QuietWriter kiest het kleinste passende venster (4K/8K/16K/32K/...) om geheugenbelasting te beperken.
- Ollama krijgt `num_ctx` alleen voor het werkelijk benodigde venster.
- Bij een exacte Ollama `exceed_context_size`-fout wordt automatisch een groter ondersteund venster geprobeerd.
- Als het modelmaximum te klein is, vallen eerst oude chatberichten weg en wordt pas daarna manuscriptcontext ingekort.
- `Context bekijken` toont gekozen contextvenster, geschatte invoer, antwoordreserve, actief runtimevenster en modelmaximum.
- OpenRouter-modelcontext wordt, wanneer beschikbaar, uit de modellenlijst gelezen.
- Regressiesuite uitgebreid naar 47 tests.

## 0.8.5 — AI vereenvoudigd en context veilig begrensd

- Verhalenbibliotheek, bibliothecaris en semantische zoeklaag tijdelijk uitgeschakeld in de actieve AI-flow.
- Bibliothecaris- en semantische modelkeuzes blijven zichtbaar maar zijn grijs met uitleg dat de functie tijdelijk niet actief is.
- Eén contextafhankelijke AI-knop: verzendpijl tijdens invoer, stopvierkant tijdens generatie.
- Directe chat gebruikt alleen schrijverspersona plus selectie/hoofdstuk/sectie/boek.
- Nieuwe contextbudgettering houdt automatisch ruimte vrij voor het antwoord en verwijdert oude chatgeschiedenis vóór manuscriptcontext wordt ingekort.
- Ollama-contextvenster wordt conservatief begrensd op 8192 tokens wanneer het runtimevenster niet expliciet in het model is vastgelegd.
- Geen expliciete temperature-optie meer naar Ollama; providers krijgen de eenvoudigste compatibele chataanroep.

# QuietWriter 0.8.4

## 0.8.4 — AI retrieval en stoppen gerepareerd

Deze versie richt zich uitsluitend op betrouwbaarheid van de AI-iteratie.

### Verhalenbibliotheek

- Vragen als **“Welke oude verhalen lijken op deze?”** gebruiken nu niet alleen de vraag als zoektekst, maar ook de actuele manuscripttekst als vergelijkingsreferentie.
- Het semantische zoekmodel vergelijkt daardoor de betekenis van het huidige hoofdstuk met de oude verhalen in plaats van alleen woorden als “oude verhalen”.
- Het bibliothecarismodel krijgt een begrensd fragment van de huidige tekst te zien naast titel, tags, beschrijving, synopsis en een fragment van ieder kandidaatverhaal.
- Er is een provider-onafhankelijke lokale fallback-rangschikking toegevoegd.
- Een fout bibliothecarismodel maakt retrieval niet langer leeg wanneer de semantische of lokale laag wel kandidaten heeft.
- Als een expliciete bibliotheekvraag **geen** relevante bronnen oplevert, wordt het hoofdmodel niet meer aangeroepen. QuietWriter meldt dan deterministisch dat er geen relevante oude verhalen zijn gevonden. Daarmee kan het model geen fictieve titels of mythes verzinnen.
- Het uiteindelijke schrijfmodel krijgt een expliciete whitelist van de geraadpleegde verhaaltitels en mag voor bibliotheekvergelijkingen alleen die bronnen gebruiken.

### Modelrollen

- Embeddingmodellen worden niet meer automatisch als bibliothecarismodel gekozen.
- Bekende embeddingnamen zoals `nomic-embed-*`, `qwen*-embedding`, BGE, E5 en MiniLM worden uit de chat/bibliothecarisrol gefilterd.
- **Modellen ophalen** gebruikt waar mogelijk Ollama `/api/show` capabilities om chat- en embeddingmodellen uit elkaar te houden.
- Een foutief opgeslagen embeddingmodel in de bibliothecarisinstelling wordt bij opstarten automatisch vervangen door het kleinste gevonden chatmodel.

### Stop AI en stabiliteit

- Nieuw: **Stop AI** naast Versturen.
- Stoppen annuleert zowel bibliotheekzoekwerk als de uiteindelijke streaming-chat.
- Ollama- en OpenRouter-providers kunnen hun actieve HTTP-stream sluiten.
- QThread-objecten worden niet langer op `None` gezet voordat de echte Qt-thread is geëindigd.
- Bij afsluiten stopt QuietWriter actieve AI-workers eerst en wacht gecontroleerd op beëindiging. Dit voorkomt `QThread: Destroyed while thread is still running`.
- Een gestopte generatie wordt niet als half antwoord in de boekchat opgeslagen.

### Tests

- Nieuwe tests voor retrieval op basis van de actuele tekst, embeddingmodelherkenning, deduplicatie en provider-cancellation.
- Volledige suite: **38 tests OK**.
