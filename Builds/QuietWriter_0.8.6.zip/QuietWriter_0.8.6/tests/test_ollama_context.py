import unittest
from unittest.mock import patch

from quietwriter.ai.ollama_provider import OllamaProvider


class FakeResponse:
    def __init__(self, status=200, data=None, lines=None):
        self.status_code=status
        self._data=data or {}
        self._lines=lines or []
        self.text=''
        self.ok=200 <= status < 300
        self.closed=False
    def json(self): return self._data
    def iter_lines(self, decode_unicode=True): return iter(self._lines)
    def close(self): self.closed=True


class OllamaContextTests(unittest.TestCase):
    def test_context_info_uses_model_max_and_active_runtime(self):
        p=OllamaProvider()
        show=FakeResponse(data={
            'model_info': {'gemma3.context_length': 131072},
            'parameters': 'temperature 0.7',
        })
        ps=FakeResponse(data={'models':[{
            'name':'gemma:latest','context_length':8192,'size':7_000_000_000,'size_vram':6_000_000_000
        }]})
        with patch('requests.post', return_value=show), patch('requests.get', return_value=ps):
            info=p.context_info('gemma:latest')
        self.assertEqual(info['model_max'],131072)
        self.assertEqual(info['active_window'],8192)

    def test_chat_retries_with_larger_context_after_exact_ollama_error(self):
        p=OllamaProvider()
        bad=FakeResponse(status=400, data={'error':{
            'code':400,'message':'request (8472 tokens) exceeds the available context size (8192 tokens), try increasing it',
            'type':'exceed_context_size_error','n_prompt_tokens':8472,'n_ctx':8192
        }})
        good=FakeResponse(status=200, lines=['{"message":{"content":"ok"},"done":true}'])
        with patch('requests.post', side_effect=[bad, good]) as post:
            chunks=list(p.stream_chat('gemma', [{'role':'user','content':'x'}], num_ctx=8192, _max_num_ctx=32768))
        self.assertEqual(''.join(c.content for c in chunks),'ok')
        second_payload=post.call_args_list[1].kwargs['json']
        self.assertEqual(second_payload['options']['num_ctx'],16384)


if __name__ == '__main__':
    unittest.main()
