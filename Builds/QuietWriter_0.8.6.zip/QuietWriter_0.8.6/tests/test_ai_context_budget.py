import unittest
from quietwriter.ai.context_budget import estimate_tokens, message_tokens, fit_messages


class ContextBudgetTests(unittest.TestCase):
    def test_long_context_is_trimmed_for_8192(self):
        persona = 'persona ' * 500
        context = 'hoofdstuk ' * 5000
        history = [
            {'role': 'assistant', 'content': 'oud antwoord ' * 1000},
            {'role': 'user', 'content': 'nieuwe vraag'},
        ]
        def system(ctx):
            return f'{persona}\nCONTEXT:\n{ctx}'
        msgs, fitted, info = fit_messages(system, context, history, 8192)
        self.assertLessEqual(message_tokens(msgs), info['input_budget'])
        self.assertLess(len(fitted), len(context))
        self.assertEqual(msgs[-1]['content'], 'nieuwe vraag')

    def test_old_history_drops_before_current_question(self):
        context = 'tekst ' * 1800
        history = [
            {'role': 'user', 'content': 'oude vraag ' * 1000},
            {'role': 'assistant', 'content': 'oud antwoord ' * 1000},
            {'role': 'user', 'content': 'huidige vraag'},
        ]
        msgs, _, _ = fit_messages(lambda c: 'persona\n'+c, context, history, 4096)
        self.assertEqual(msgs[-1]['content'], 'huidige vraag')
        self.assertLess(len(msgs), 4)

    def test_default_window_is_safe_8192(self):
        msgs, _, info = fit_messages(lambda c: c, 'x' * 30000, [{'role':'user','content':'test'}], None)
        self.assertEqual(info['context_window'], 8192)
        self.assertLessEqual(message_tokens(msgs), info['input_budget'])


if __name__ == '__main__':
    unittest.main()

class AutoContextPlannerTests(unittest.TestCase):
    def test_small_prompt_keeps_8192_when_active_and_sufficient(self):
        from quietwriter.ai.context_budget import choose_context_window
        plan = choose_context_window(4000, model_max=32768, active_window=8192)
        self.assertEqual(plan['window'], 8192)
        self.assertFalse(plan['needs_trim'])

    def test_larger_prompt_grows_to_16384(self):
        from quietwriter.ai.context_budget import choose_context_window
        plan = choose_context_window(8500, model_max=32768, active_window=8192)
        self.assertEqual(plan['window'], 16384)
        self.assertFalse(plan['needs_trim'])

    def test_model_max_caps_and_requests_trim(self):
        from quietwriter.ai.context_budget import choose_context_window
        plan = choose_context_window(9000, model_max=8192, active_window=8192)
        self.assertEqual(plan['window'], 8192)
        self.assertTrue(plan['needs_trim'])

    def test_configured_window_is_respected_as_preferred_minimum(self):
        from quietwriter.ai.context_budget import choose_context_window
        plan = choose_context_window(1800, model_max=32768, configured_window=16384)
        self.assertEqual(plan['window'], 16384)
