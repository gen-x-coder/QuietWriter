from PySide6.QtCore import Qt, QSettings, Signal, QMimeData, QTimer
from PySide6.QtGui import QColor, QDrag, QPainter, QPalette, QPen, QPixmap
from PySide6.QtWidgets import QAbstractItemView, QHeaderView, QTreeWidget

from ..themes import THEMES


class ManuscriptTree(QTreeWidget):
    chapterDropped = Signal(str, str, str, bool)
    dragStarted = Signal()
    dragFinished = Signal()

    MIME_TYPE = 'application/x-quietwriter-chapter'

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setColumnCount(2)
        self.setHeaderHidden(True)
        self.header().setStretchLastSection(False)
        self.header().setSectionResizeMode(0, QHeaderView.Stretch)
        self.header().setSectionResizeMode(1, QHeaderView.Fixed)
        self.header().setMinimumSectionSize(0)
        self.setColumnWidth(1, 58)
        self.setDragEnabled(True)
        self.setAcceptDrops(True)
        self.setDropIndicatorShown(False)
        # Crucial: do NOT use InternalMove. QTreeWidget would then mutate its own
        # item model during a drag, independently of book.json. QuietWriter uses
        # a custom QDrag and only changes the book model after a validated drop.
        self.setDragDropMode(QAbstractItemView.DragDrop)
        self.setDefaultDropAction(Qt.MoveAction)
        self.setSelectionMode(QAbstractItemView.SingleSelection)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setRootIsDecorated(True)
        self.setItemsExpandable(True)
        self.setIndentation(14)
        self.setUniformRowHeights(True)
        self.setMouseTracking(True)
        self.viewport().setMouseTracking(True)
        self._drag_allowed = False
        self._drag_item = None
        self._drop_item = None
        self._drop_before = True
        self._pending_drop = None
        # The guard starts on handle mouse-press, not only in startDrag().
        # QAbstractItemView may move focus while processing that press, which can
        # synchronously fire e.g. chapter-title editingFinished handlers. Those
        # handlers must already know that rebuilding the tree is unsafe.
        self._dragging = False
        self._drag_exec_active = False
        self._finish_scheduled = False

    @property
    def is_dragging(self):
        return self._dragging

    def _begin_drag_guard(self):
        if self._dragging:
            return
        self._dragging = True
        self._finish_scheduled = False
        self._pending_drop = None
        self.dragStarted.emit()

    def _schedule_drag_finish(self):
        if self._finish_scheduled:
            return
        self._finish_scheduled = True
        pending_drop = self._pending_drop
        self._pending_drop = None
        # Keep the guard active until the next event-loop turn. This guarantees
        # that startDrag()/mouseReleaseEvent() and Qt's native drag machinery
        # have fully unwound before EditorPage is allowed to rebuild the tree.
        QTimer.singleShot(0, lambda p=pending_drop: self._finish_drag(p))

    def _finish_drag(self, pending_drop):
        self._finish_scheduled = False
        self._drag_exec_active = False
        self._drag_allowed = False
        self._drag_item = None
        self._drop_item = None
        self._dragging = False
        self.viewport().setCursor(Qt.ArrowCursor)
        self.viewport().update()
        try:
            if pending_drop is not None:
                source_id, target_type, target_id, before = pending_drop
                self.chapterDropped.emit(source_id, target_type, target_id, before)
        finally:
            # Always release EditorPage's drag guards, including cancelled drags
            # and failures in a connected drop handler.
            self.dragFinished.emit()

    def mouseMoveEvent(self, event):
        idx = self.indexAt(event.position().toPoint())
        item = self.itemAt(event.position().toPoint())
        data = item.data(0, Qt.UserRole) if item else None
        over_handle = bool(idx.isValid() and idx.column() == 1 and data and data[0] == 'chapter')
        self.viewport().setCursor(Qt.OpenHandCursor if over_handle else Qt.ArrowCursor)
        super().mouseMoveEvent(event)

    def mousePressEvent(self, event):
        item = self.itemAt(event.position().toPoint())
        idx = self.indexAt(event.position().toPoint())
        data = item.data(0, Qt.UserRole) if item else None
        # Only the six-dot handle in column 1 can start a drag. Start the guard
        # before calling QTreeWidget.mousePressEvent(): the base implementation
        # may change focus, which can synchronously trigger editingFinished and
        # other callbacks that would otherwise clear this tree mid-press.
        self._drag_allowed = bool(item and idx.isValid() and idx.column() == 1 and data and data[0] == 'chapter')
        self._drag_item = item if self._drag_allowed else None
        if self._drag_allowed:
            self._begin_drag_guard()
            self.viewport().setCursor(Qt.ClosedHandCursor)
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        armed_without_native_drag = self._dragging and not self._drag_exec_active
        super().mouseReleaseEvent(event)
        # A click on the handle that never crossed Qt's drag threshold still
        # entered the guard in mousePressEvent. Release it after the press/release
        # sequence has completely unwound.
        if armed_without_native_drag and self._dragging:
            self._schedule_drag_finish()

    def startDrag(self, supportedActions):
        if not self._drag_allowed or not self._drag_item:
            if self._dragging:
                self._schedule_drag_finish()
            return
        data = self._drag_item.data(0, Qt.UserRole)
        if not data or data[0] != 'chapter':
            self._schedule_drag_finish()
            return

        # Normally the guard was started in mousePressEvent. Keep this fallback
        # for programmatic/Qt initiated drags so every path has identical safety.
        self._begin_drag_guard()
        mime = QMimeData()
        mime.setData(self.MIME_TYPE, data[1].encode('utf-8'))
        drag = QDrag(self)
        drag.setMimeData(mime)
        # Small neutral drag image; this does not detach/move the tree item.
        rect = self.visualItemRect(self._drag_item)
        pix = QPixmap(max(180, rect.width()), max(28, rect.height()))
        pix.fill(Qt.transparent)
        painter = QPainter(pix)
        painter.setPen(QColor(THEMES.get(str(QSettings('QuietWriter', 'QuietWriter').value('theme', 'Helder')), THEMES['Helder'])['muted']))
        painter.drawText(pix.rect().adjusted(8, 0, -8, 0), Qt.AlignVCenter | Qt.AlignLeft, self._drag_item.text(0))
        painter.end()
        drag.setPixmap(pix)

        self._drag_exec_active = True
        try:
            drag.exec(Qt.MoveAction)
        finally:
            # QDrag.exec() runs a nested native event loop. Never emit the drop
            # or dragFinished synchronously from here: schedule one event-loop
            # turn later, after the native drag and this virtual method returned.
            self._drag_exec_active = False
            self._drag_allowed = False
            self._drag_item = None
            self._drop_item = None
            self.viewport().setCursor(Qt.ArrowCursor)
            self.viewport().update()
            self._schedule_drag_finish()

    def dragEnterEvent(self, event):
        if event.mimeData().hasFormat(self.MIME_TYPE):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if not event.mimeData().hasFormat(self.MIME_TYPE):
            event.ignore(); return
        target = self.itemAt(event.position().toPoint())
        if not target:
            self._drop_item = None; self.viewport().update(); event.ignore(); return
        tdata = target.data(0, Qt.UserRole)
        source_id = bytes(event.mimeData().data(self.MIME_TYPE)).decode('utf-8', errors='ignore')
        if not tdata or tdata[0] not in ('chapter', 'section') or (tdata[0] == 'chapter' and tdata[1] == source_id):
            self._drop_item = None; self.viewport().update(); event.ignore(); return
        rect = self.visualItemRect(target)
        self._drop_item = target
        self._drop_before = event.position().y() < rect.center().y()
        self.viewport().update()
        event.setDropAction(Qt.MoveAction)
        event.accept()

    def dragLeaveEvent(self, event):
        self._drop_item = None
        self.viewport().update()
        event.accept()

    def dropEvent(self, event):
        # Never rebuild/mutate the QTreeWidget while Qt is dispatching the
        # active QDropEvent or while QDrag.exec() is still running. The receiver
        # of chapterDropped repopulates the tree and destroys its items, so the
        # drop event only records immutable IDs. _finish_drag dispatches the
        # reorder after the complete native drag stack has unwound.
        try:
            if not event.mimeData().hasFormat(self.MIME_TYPE):
                event.ignore(); return
            source_id = bytes(event.mimeData().data(self.MIME_TYPE)).decode('utf-8', errors='ignore')
            target = self._drop_item or self.itemAt(event.position().toPoint())
            if not source_id or not target:
                event.ignore(); return
            tdata = target.data(0, Qt.UserRole)
            if not tdata or tdata[0] not in ('chapter', 'section'):
                event.ignore(); return
            self._pending_drop = (source_id, tdata[0], tdata[1], bool(self._drop_before))
            event.setDropAction(Qt.MoveAction)
            event.accept()
        finally:
            # Remove the visual target reference immediately, but leave the
            # source item alone until QDrag.exec() itself has returned.
            self._drop_item = None
            self.viewport().update()

    def paintEvent(self, event):
        super().paintEvent(event)

        # QTreeWidget styles each column cell separately. A border in the QSS
        # therefore produced two selection bars for a chapter: one before the
        # title and one before the drag-handle column. Paint one row-level
        # accent here instead, while Qt still handles the selected background.
        current = self.currentItem()
        data = current.data(0, Qt.UserRole) if current else None
        if current and current.isSelected() and data and data[0] == 'chapter':
            r = self.visualItemRect(current)
            if r.isValid():
                p = QPainter(self.viewport())
                p.setPen(QPen(self.palette().color(QPalette.Highlight), 3))
                x = max(1, r.left() + 1)
                p.drawLine(x, r.top() + 3, x, r.bottom() - 3)

        if self._drop_item:
            r = self.visualItemRect(self._drop_item)
            y = r.top() if self._drop_before else r.bottom()
            p = QPainter(self.viewport())
            p.setPen(QPen(self.palette().color(QPalette.Highlight), 3))
            p.drawLine(8, y, max(8, self.viewport().width() - 8), y)
