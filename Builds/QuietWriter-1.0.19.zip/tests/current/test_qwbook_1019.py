from __future__ import annotations

import json
import zipfile
from pathlib import Path

import pytest

from quietwriter.qwbook_io import (
    QwBookConflictError, QwBookError, QwBookFutureFormatError,
    export_qwbook, import_qwbook,
)
from quietwriter.storage import Library, _safe_atomic_write_text


def _filled_book(lib: Library):
    book = lib.create_book('Draagbaar boek')
    lib.track_book(book)
    chapter = book.sections[0].chapters[0]
    lib.save_chapter(book, chapter, '# Begin\n\nEen **belangrijk** hoofdstuk.\n')
    # Book-local optional state should travel with the package as bytes.
    files = {
        'planning/notes.md': 'Losse planning\n',
        'planning/characters.json': json.dumps({'version': 1, 'characters': []}),
        'publication/texts/preface.md': 'Voorwoord\n',
        'ai/boekprofiel.md': '## Toon\nRustig\n',
        'ai/memory.md': '## Feiten\nEen feit\n',
        'export/settings.json': json.dumps({'format': 'docx'}),
    }
    for rel, text in files.items():
        _safe_atomic_write_text(book.path / rel, text)
    # A binary book-local asset is included byte-exact too.
    asset = book.path / 'assets' / 'images' / 'example.bin'
    asset.parent.mkdir(parents=True, exist_ok=True)
    asset.write_bytes(b'\x00\x01quietwriter\xff')
    lib.refresh_book_revision(book)
    return book


def _tree_bytes(root: Path):
    return {
        p.relative_to(root).as_posix(): p.read_bytes()
        for p in root.rglob('*') if p.is_file()
    }


def test_qwbook_roundtrip_preserves_complete_book_folder(tmp_path):
    source_lib = Library(tmp_path / 'source')
    book = _filled_book(source_lib)
    expected = _tree_bytes(book.path)
    package = tmp_path / 'boek.qwbook'
    export_qwbook(source_lib, book, package)

    target_lib = Library(tmp_path / 'target')
    imported = import_qwbook(target_lib, package)
    assert imported.id == book.id
    assert imported.title == book.title
    assert _tree_bytes(imported.path) == expected
    assert target_lib.load_book(imported.path).sections[0].chapters[0].title == book.sections[0].chapters[0].title


def test_qwbook_never_overwrites_same_book_identity(tmp_path):
    lib = Library(tmp_path / 'workspace')
    book = _filled_book(lib)
    package = tmp_path / 'boek.qwbook'
    export_qwbook(lib, book, package)
    before = _tree_bytes(book.path)
    with pytest.raises(QwBookConflictError):
        import_qwbook(lib, package)
    assert _tree_bytes(book.path) == before


def test_qwbook_detects_corrupt_payload_and_leaves_library_clean(tmp_path):
    source_lib = Library(tmp_path / 'source')
    book = _filled_book(source_lib)
    package = tmp_path / 'boek.qwbook'
    export_qwbook(source_lib, book, package)
    tampered = tmp_path / 'tampered.qwbook'
    with zipfile.ZipFile(package, 'r') as src, zipfile.ZipFile(tampered, 'w') as dst:
        for info in src.infolist():
            data = src.read(info.filename)
            if info.filename.startswith('book/chapters/'):
                data += b'TAMPER'
            dst.writestr(info, data)
    target = Library(tmp_path / 'target')
    with pytest.raises(QwBookError):
        import_qwbook(target, tampered)
    assert target.list_books() == []


def test_qwbook_refuses_future_package_version(tmp_path):
    path = tmp_path / 'future.qwbook'
    with zipfile.ZipFile(path, 'w') as z:
        z.writestr('qwbook.json', json.dumps({
            'format': 'quietwriter-book', 'version': 999, 'book_id': 'x', 'title': 'X',
            'files': {'book.json': {'sha256': 'x', 'size': 1}},
        }))
        z.writestr('book/book.json', b'x')
    with pytest.raises(QwBookFutureFormatError):
        import_qwbook(Library(tmp_path / 'target'), path)


def test_qwbook_refuses_path_traversal_before_writing_outside_library(tmp_path):
    data = b'{}'
    package = {
        'format': 'quietwriter-book', 'version': 1, 'book_id': 'abc', 'title': 'X',
        'files': {
            'book.json': {'sha256': __import__('hashlib').sha256(data).hexdigest(), 'size': len(data)},
            '../outside.txt': {'sha256': __import__('hashlib').sha256(b'bad').hexdigest(), 'size': 3},
        },
    }
    path = tmp_path / 'evil.qwbook'
    with zipfile.ZipFile(path, 'w') as z:
        z.writestr('qwbook.json', json.dumps(package))
        z.writestr('book/book.json', data)
        z.writestr('book/../outside.txt', b'bad')
    target_root = tmp_path / 'target'
    with pytest.raises(QwBookError):
        import_qwbook(Library(target_root), path)
    assert not (target_root / 'outside.txt').exists()

def test_export_settings_accept_qwbook_format(tmp_path):
    from quietwriter.exporting.settings import ExportSettingsStore
    lib = Library(tmp_path / 'workspace2')
    book = lib.create_book('Settings')
    lib.track_book(book)
    store = ExportSettingsStore(lib)
    settings = store.load(book)
    settings['format'] = 'qwbook'
    store.save(book, settings)
    assert store.load(book)['format'] == 'qwbook'
