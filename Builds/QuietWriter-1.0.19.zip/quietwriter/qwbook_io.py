from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

from .storage import Book, Library, slugify

PACKAGE_FORMAT = 'quietwriter-book'
PACKAGE_VERSION = 1
MANIFEST_NAME = 'qwbook.json'
BOOK_PREFIX = 'book/'


class QwBookError(RuntimeError):
    pass


class QwBookFutureFormatError(QwBookError):
    pass


class QwBookConflictError(QwBookError):
    pass


def _safe_member_name(name: str) -> PurePosixPath:
    path = PurePosixPath(name)
    if path.is_absolute() or '..' in path.parts or not path.parts:
        raise QwBookError(f'Ongeldig pad in .qwbook: {name}')
    return path



def _read_stable_bytes(path: Path) -> bytes:
    before = path.stat()
    data = path.read_bytes()
    after = path.stat()
    if before.st_size != after.st_size or before.st_mtime_ns != after.st_mtime_ns:
        raise QwBookError(f'Bestand veranderde tijdens export: {path.name}')
    return data

def _iter_book_files(book: Book):
    root = Path(book.path)
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise QwBookError(f'Symbolische koppeling wordt niet opgenomen: {path.name}')
        if path.is_file():
            relative = path.relative_to(root).as_posix()
            if relative.startswith('.') or '/.' in relative:
                continue
            yield relative, path


def export_qwbook(library: Library, book: Book, destination: Path) -> Path:
    """Create one portable, self-verifying QuietWriter book package."""
    destination = Path(destination)
    library.verify_book_unchanged(book)
    files: dict[str, dict[str, object]] = {}
    payloads: list[tuple[str, bytes]] = []
    for relative, path in _iter_book_files(book):
        data = _read_stable_bytes(path)
        files[relative] = {'sha256': hashlib.sha256(data).hexdigest(), 'size': len(data)}
        payloads.append((relative, data))

    if 'book.json' not in files:
        raise QwBookError('Dit boek heeft geen book.json en kan niet worden verpakt.')

    package = {
        'format': PACKAGE_FORMAT,
        'version': PACKAGE_VERSION,
        'book_id': book.id,
        'title': book.title,
        'files': files,
    }
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=destination.name + '.', suffix='.tmp', dir=str(destination.parent))
    os.close(fd)
    temp = Path(temp_name)
    try:
        with zipfile.ZipFile(temp, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            archive.writestr(MANIFEST_NAME, json.dumps(package, ensure_ascii=False, indent=2))
            for relative, data in payloads:
                archive.writestr(BOOK_PREFIX + relative, data)
        os.replace(temp, destination)
    finally:
        try:
            temp.unlink(missing_ok=True)
        except OSError:
            pass
    return destination


def _load_package(archive: zipfile.ZipFile) -> dict:
    names = archive.namelist()
    if MANIFEST_NAME not in names:
        raise QwBookError('Dit bestand bevat geen QuietWriter-pakketmanifest.')
    try:
        package = json.loads(archive.read(MANIFEST_NAME).decode('utf-8'))
    except (UnicodeDecodeError, json.JSONDecodeError, KeyError) as exc:
        raise QwBookError('Het QuietWriter-pakketmanifest is beschadigd.') from exc
    if not isinstance(package, dict) or package.get('format') != PACKAGE_FORMAT:
        raise QwBookError('Dit is geen geldig QuietWriter-boekbestand.')
    version = int(package.get('version') or 0)
    if version > PACKAGE_VERSION:
        raise QwBookFutureFormatError('Dit .qwbook-bestand is gemaakt met een nieuwere QuietWriter-versie.')
    if version < 1:
        raise QwBookError('Onbekende .qwbook-versie.')
    files = package.get('files')
    if not isinstance(files, dict) or 'book.json' not in files:
        raise QwBookError('Het .qwbook-bestand bevat geen volledige boekenlijst.')
    return package


def inspect_qwbook(source: Path) -> dict:
    source = Path(source)
    try:
        with zipfile.ZipFile(source, 'r') as archive:
            return _load_package(archive)
    except zipfile.BadZipFile as exc:
        raise QwBookError('Dit .qwbook-bestand is beschadigd of geen ZIP-container.') from exc


def import_qwbook(library: Library, source: Path) -> Book:
    """Import a complete package without ever overwriting an existing book."""
    source = Path(source)
    temp_root: Path | None = None
    final_path: Path | None = None
    try:
        with zipfile.ZipFile(source, 'r') as archive:
            package = _load_package(archive)
            names = archive.namelist()
            if len(names) != len(set(names)):
                raise QwBookError('Het .qwbook-bestand bevat dubbele bestandsnamen.')
            book_id = str(package.get('book_id') or '').strip()
            title = str(package.get('title') or source.stem).strip() or source.stem
            if not book_id:
                raise QwBookError('Het .qwbook-bestand bevat geen boek-id.')
            for existing in library.list_books():
                if existing.id == book_id:
                    raise QwBookConflictError(f'Boek “{existing.title}” met dezelfde identiteit bestaat al in deze werkmap.')

            folder_name = f'{slugify(title)}-{book_id[:8]}'
            final_path = library.books_dir / folder_name
            if final_path.exists():
                raise QwBookConflictError(f'Doelmap bestaat al: {final_path.name}')

            temp_root = Path(tempfile.mkdtemp(prefix='.qwbook-import-', dir=str(library.books_dir)))
            files = package['files']
            expected_entries = {BOOK_PREFIX + str(name) for name in files}
            actual_book_entries = {name for name in archive.namelist() if name.startswith(BOOK_PREFIX) and not name.endswith('/')}
            if actual_book_entries != expected_entries:
                raise QwBookError('De inhoud van het .qwbook-bestand wijkt af van het pakketmanifest.')

            for relative, metadata in files.items():
                rel = _safe_member_name(str(relative))
                entry = BOOK_PREFIX + rel.as_posix()
                info = archive.getinfo(entry)
                # Unix symlink bit in external attributes.
                if ((info.external_attr >> 16) & 0o170000) == 0o120000:
                    raise QwBookError(f'Symbolische koppeling in .qwbook geweigerd: {relative}')
                data = archive.read(info)
                if not isinstance(metadata, dict):
                    raise QwBookError(f'Ongeldige bestandsmetadata: {relative}')
                if int(metadata.get('size', -1)) != len(data) or str(metadata.get('sha256') or '') != hashlib.sha256(data).hexdigest():
                    raise QwBookError(f'Bestandscontrole mislukt voor {relative}.')
                target = temp_root.joinpath(*rel.parts)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)

        candidate = library.load_book(temp_root)
        if candidate.id != book_id:
            raise QwBookError('Boek-id in book.json komt niet overeen met het pakketmanifest.')
        if candidate.title != title:
            raise QwBookError('Boektitel in book.json komt niet overeen met het pakketmanifest.')
        # Every chapter referenced by the manifest must physically exist.
        for section in candidate.sections:
            for chapter in section.chapters:
                rel = _safe_member_name(chapter.file)
                if not (temp_root.joinpath(*rel.parts)).is_file():
                    raise QwBookError(f'Hoofdstukbestand ontbreekt: {chapter.file}')

        os.replace(temp_root, final_path)
        temp_root = None
        imported = library.load_book(final_path)
        library.track_book(imported)
        return imported
    except zipfile.BadZipFile as exc:
        raise QwBookError('Dit .qwbook-bestand is beschadigd of geen geldig archief.') from exc
    finally:
        if temp_root is not None:
            shutil.rmtree(temp_root, ignore_errors=True)
