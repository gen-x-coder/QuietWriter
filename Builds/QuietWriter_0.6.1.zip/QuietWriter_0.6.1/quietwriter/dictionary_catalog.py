from __future__ import annotations
import shutil
from dataclasses import dataclass
from pathlib import Path

LANGUAGES = {
    'nl_NL': 'Nederlands - Nederland',
    'en_US': 'Engels - VS',
    'de_DE': 'Duits - Duitsland',
    'es_ES': 'Spaans - Spanje',
    'fr_FR': 'Frans - Frankrijk',
}

@dataclass(frozen=True)
class DictionaryEntry:
    locale: str
    label: str
    dic: Path
    aff: Path | None
    source: str = ''


class DictionaryCatalog:
    """Vindt woordenboeken in QuietWriter en gangbare Office-installaties.

    QuietWriter gebruikt locale-codes (nl_NL, en_US, ...) als stabiele instelling.
    Daardoor ziet de gebruiker een taalnaam en nooit een bestandsnaam.
    """
    def __init__(self, workspace_dir: Path):
        self.workspace_dir = Path(workspace_dir)
        self.workspace_dir.mkdir(parents=True, exist_ok=True)
        self._entries: dict[str, DictionaryEntry] = {}
        self.scan()

    @staticmethod
    def _infer_locale(dic: Path) -> str:
        candidates = [dic.stem, dic.parent.name]
        for value in candidates:
            value = value.replace('-', '_')
            if value in LANGUAGES:
                return value
        return dic.stem.replace('-', '_')

    def _add_dic(self, dic: Path, source: str):
        locale = self._infer_locale(dic)
        if source not in ('Werkmap', 'Meegeleverd') and locale not in LANGUAGES:
            return
        aff = dic.with_suffix('.aff')
        if not aff.exists():
            aff = None
        label = LANGUAGES.get(locale, locale.replace('_', ' - '))
        current = self._entries.get(locale)
        # Werkmap/bundled heeft voorrang boven externe installaties.
        priority = {'Werkmap': 3, 'Meegeleverd': 2, 'ONLYOFFICE': 1, 'LibreOffice': 1, 'Extern': 0}
        if current and priority.get(current.source, 0) > priority.get(source, 0):
            return
        self._entries[locale] = DictionaryEntry(locale, label, dic, aff, source)

    def _scan_root(self, root: Path, source: str):
        if not root.exists():
            return
        for dic in root.rglob('*.dic'):
            name = dic.name.lower()
            if name.startswith('hyph_'):
                continue
            self._add_dic(dic, source)

    def scan(self):
        self._entries.clear()
        self._scan_root(self.workspace_dir, 'Werkmap')
        bundled = Path(__file__).resolve().parent.parent / 'dictionaries'
        if bundled.resolve() != self.workspace_dir.resolve():
            self._scan_root(bundled, 'Meegeleverd')

        # Bekende Windows-locaties. Dit maakt o.a. een bestaande ONLYOFFICE-installatie direct bruikbaar.
        roots = [
            (Path(r'C:/Program Files/ONLYOFFICE/DesktopEditors/dictionaries'), 'ONLYOFFICE'),
            (Path(r'C:/Program Files (x86)/ONLYOFFICE/DesktopEditors/dictionaries'), 'ONLYOFFICE'),
            (Path(r'C:/Program Files/LibreOffice/share/extensions'), 'LibreOffice'),
            (Path(r'C:/Program Files (x86)/LibreOffice/share/extensions'), 'LibreOffice'),
        ]
        for root, source in roots:
            self._scan_root(root, source)

    def entries(self) -> list[DictionaryEntry]:
        order = list(LANGUAGES)
        return sorted(self._entries.values(), key=lambda e: (order.index(e.locale) if e.locale in order else 999, e.label.casefold()))

    def get(self, locale: str) -> DictionaryEntry | None:
        return self._entries.get(locale)

    def add_custom(self, dic: Path) -> DictionaryEntry:
        dic = Path(dic)
        locale = self._infer_locale(dic)
        target_dir = self.workspace_dir / locale
        target_dir.mkdir(parents=True, exist_ok=True)
        target_dic = target_dir / f'{locale}.dic'
        shutil.copy2(dic, target_dic)
        aff = dic.with_suffix('.aff')
        if aff.exists():
            shutil.copy2(aff, target_dir / f'{locale}.aff')
        self.scan()
        return self.get(locale) or DictionaryEntry(locale, LANGUAGES.get(locale, locale), target_dic, target_dic.with_suffix('.aff') if target_dic.with_suffix('.aff').exists() else None, 'Werkmap')
