__version__ = '0.6.1'
APP_NAME = 'QuietWriter'
