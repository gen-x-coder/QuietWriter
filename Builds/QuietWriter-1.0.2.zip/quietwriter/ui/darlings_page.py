from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox, QFrame, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
    QMessageBox, QPushButton, QTextEdit, QVBoxLayout, QWidget,
)

from ..fragment_store import FragmentExternalModificationError, FragmentStore
from ..i18n import tr


class DarlingsPage(QWidget):
    """Workspace-wide browser for saved text fragments.

    Fragment text is deliberately read-only in this first UI slice. Only title,
    note and tags are editable; their save path always carries the revision that
    was loaded with the selected fragment.
    """

    def __init__(self, main):
        super().__init__()
        self.main = main
        self.store = FragmentStore(main.library.root)
        self._loading = False
        self._loaded_fragment = None
        self.dirty = False

        outer = QVBoxLayout(self)
        outer.setContentsMargins(32, 26, 36, 30)
        outer.setSpacing(14)

        title = QLabel(tr('darlings.title', 'Bewaarplaats'))
        title.setObjectName('title')
        info = QLabel(tr(
            'darlings.info',
            'Bewaar tekstfragmenten die je uit een manuscript wilt halen zonder ze kwijt te raken. '
            'Fragmenten zijn boekonafhankelijk en blijven gewone Markdownbestanden.'
        ))
        info.setObjectName('muted')
        info.setWordWrap(True)
        outer.addWidget(title)
        outer.addWidget(info)

        filters = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText(tr('darlings.search', 'Zoeken in titel, notitie, tags en tekst…'))
        self.tag_filter = QComboBox()
        self.tag_filter.setMinimumWidth(180)
        filters.addWidget(self.search, 1)
        filters.addWidget(self.tag_filter, 0)
        outer.addLayout(filters)

        self.warning = QLabel()
        self.warning.setObjectName('muted')
        self.warning.setWordWrap(True)
        self.warning.hide()
        outer.addWidget(self.warning)

        body = QHBoxLayout()
        body.setSpacing(18)

        left = QFrame()
        left.setObjectName('settingsNav')
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(8, 8, 8, 8)
        left_layout.setSpacing(6)
        list_title = QLabel(tr('darlings.fragments', 'Fragmenten'))
        list_title.setObjectName('sectionTitle')
        self.list = QListWidget()
        self.list.setObjectName('darlingsList')
        self.list.setMinimumWidth(285)
        self.list.setMaximumWidth(360)
        left_layout.addWidget(list_title)
        left_layout.addWidget(self.list, 1)
        body.addWidget(left, 0)

        right = QVBoxLayout()
        right.setSpacing(8)
        self.detail_title = QLabel(tr('darlings.detail', 'Fragment'))
        self.detail_title.setObjectName('sectionTitle')
        right.addWidget(self.detail_title)

        self.source = QLabel()
        self.source.setObjectName('muted')
        self.source.setWordWrap(True)
        right.addWidget(self.source)

        self.title_edit = QLineEdit()
        self.title_edit.setPlaceholderText(tr('darlings.title_placeholder', 'Titel (optioneel)'))
        self.tags_edit = QLineEdit()
        self.tags_edit.setPlaceholderText(tr('darlings.tags_placeholder', 'Tags, gescheiden door komma’s'))
        self.note_edit = QTextEdit()
        self.note_edit.setAcceptRichText(False)
        self.note_edit.setMaximumHeight(110)
        self.note_edit.setPlaceholderText(tr('darlings.note_placeholder', 'Notitie (optioneel)'))
        self.preview = QTextEdit()
        self.preview.setAcceptRichText(False)
        self.preview.setReadOnly(True)
        self.preview.setPlaceholderText(tr('darlings.preview_placeholder', 'Selecteer een fragment om het te bekijken.'))

        right.addWidget(QLabel(tr('darlings.field.title', 'Titel')))
        right.addWidget(self.title_edit)
        right.addWidget(QLabel(tr('darlings.field.tags', 'Tags')))
        right.addWidget(self.tags_edit)
        right.addWidget(QLabel(tr('darlings.field.note', 'Notitie')))
        right.addWidget(self.note_edit)
        right.addWidget(QLabel(tr('darlings.field.text', 'Tekst')))
        right.addWidget(self.preview, 1)

        save_row = QHBoxLayout()
        self.status = QLabel()
        self.status.setObjectName('muted')
        self.save_button = QPushButton(tr('common.save', 'Opslaan'))
        self.save_button.setObjectName('primaryButton')
        self.save_button.clicked.connect(self.save_metadata)
        save_row.addWidget(self.status)
        save_row.addStretch()
        save_row.addWidget(self.save_button)
        right.addLayout(save_row)
        body.addLayout(right, 1)
        outer.addLayout(body, 1)

        self.search.textChanged.connect(self.refresh)
        self.tag_filter.currentIndexChanged.connect(self.refresh)
        self.list.currentItemChanged.connect(self._selection_changed)
        self.title_edit.textChanged.connect(self._mark_dirty)
        self.tags_edit.textChanged.connect(self._mark_dirty)
        self.note_edit.textChanged.connect(self._mark_dirty)
        self._set_detail_enabled(False)
        self.refresh()

    @staticmethod
    def _first_text_line(text: str) -> str:
        return next((line.strip() for line in text.splitlines() if line.strip()), '')

    def display_name(self, fragment) -> str:
        if fragment.title.strip():
            return fragment.title.strip()
        first = self._first_text_line(fragment.text)
        return first[:80] if first else tr('darlings.untitled', 'Naamloos fragment')

    def _item_text(self, fragment) -> str:
        source = ' · '.join(part for part in (fragment.source_book_title, fragment.source_chapter_title) if part)
        return self.display_name(fragment) + (f'\n{source}' if source else '')

    def _set_detail_enabled(self, enabled: bool):
        for widget in (self.title_edit, self.tags_edit, self.note_edit, self.preview, self.save_button):
            widget.setEnabled(enabled)
        if not enabled:
            self.source.clear()
            self.status.clear()

    def refresh(self, *_args, select_id: str | None = None):
        if self._loading:
            return
        current_id = select_id
        if current_id is None and self._loaded_fragment is not None:
            current_id = self._loaded_fragment.id

        fragments = self.store.list_fragments()
        errors = list(self.store.last_list_errors)
        all_tags = sorted({tag for fragment in fragments for tag in fragment.tags}, key=str.casefold)

        self._loading = True
        try:
            selected_tag = self.tag_filter.currentData() or ''
            self.tag_filter.clear()
            self.tag_filter.addItem(tr('darlings.all_tags', 'Alle tags'), '')
            for tag in all_tags:
                self.tag_filter.addItem(tag, tag)
            idx = self.tag_filter.findData(selected_tag)
            self.tag_filter.setCurrentIndex(idx if idx >= 0 else 0)
            tag_cf = str(self.tag_filter.currentData() or '').casefold()
            query = self.search.text().strip().casefold()

            self.list.clear()
            selected_row = -1
            for fragment in fragments:
                if tag_cf and not any(tag.casefold() == tag_cf for tag in fragment.tags):
                    continue
                haystack = '\n'.join((
                    fragment.title, fragment.note, fragment.text,
                    fragment.source_book_title, fragment.source_chapter_title,
                    ' '.join(fragment.tags),
                )).casefold()
                if query and query not in haystack:
                    continue
                item = QListWidgetItem(self._item_text(fragment))
                item.setData(Qt.UserRole, fragment)
                self.list.addItem(item)
                if fragment.id == current_id:
                    selected_row = self.list.count() - 1

            if errors:
                self.warning.setText(tr(
                    'darlings.read_errors',
                    'Niet alle fragmenten konden worden gelezen ({count}). De overige fragmenten blijven beschikbaar.',
                    count=len(errors),
                ))
                self.warning.show()
            else:
                self.warning.clear()
                self.warning.hide()

            if self.list.count():
                self.list.setCurrentRow(selected_row if selected_row >= 0 else 0)
            else:
                self._loaded_fragment = None
                self._clear_detail()
        finally:
            self._loading = False

        if self.list.currentItem() is not None:
            self._selection_changed(self.list.currentItem())

    def _clear_detail(self):
        self._loading = True
        try:
            self.title_edit.clear()
            self.tags_edit.clear()
            self.note_edit.clear()
            self.preview.clear()
            self.dirty = False
            self._set_detail_enabled(False)
        finally:
            self._loading = False

    def _selection_changed(self, item, previous=None):
        if self._loading:
            return
        if self.dirty and self._loaded_fragment is not None and item is not None:
            next_fragment = item.data(Qt.UserRole)
            if next_fragment is not None and next_fragment.id != self._loaded_fragment.id:
                if not self._save_current_fields():
                    old_id = self._loaded_fragment.id if self._loaded_fragment is not None else None
                    self.dirty = False
                    self.refresh(select_id=old_id)
                    return
                if previous is not None:
                    previous.setData(Qt.UserRole, self._loaded_fragment)
                    previous.setText(self._item_text(self._loaded_fragment))
        if item is None:
            self._loaded_fragment = None
            self._clear_detail()
            return
        fragment = item.data(Qt.UserRole)
        if fragment is None:
            return
        self._loaded_fragment = fragment
        self._loading = True
        try:
            self._set_detail_enabled(True)
            self.title_edit.setText(fragment.title)
            self.tags_edit.setText(', '.join(fragment.tags))
            self.note_edit.setPlainText(fragment.note)
            self.preview.setPlainText(fragment.text)
            source_parts = [part for part in (fragment.source_book_title, fragment.source_chapter_title) if part]
            self.source.setText(
                tr('darlings.source', 'Bron: {source}', source=' · '.join(source_parts))
                if source_parts else tr('darlings.source_unknown', 'Bron niet vastgelegd')
            )
            self.status.setText(tr('darlings.saved', 'Opgeslagen'))
            self.dirty = False
            self.save_button.setEnabled(False)
        finally:
            self._loading = False

    def _mark_dirty(self, *_args):
        if self._loading or self._loaded_fragment is None:
            return
        self.dirty = True
        self.status.setText(tr('darlings.unsaved', 'Niet-opgeslagen wijzigingen'))
        self.save_button.setEnabled(True)

    def _save_current_fields(self):
        fragment = self._loaded_fragment
        if fragment is None or not self.dirty:
            return True
        tags = [part.strip() for part in self.tags_edit.text().split(',') if part.strip()]
        try:
            updated = self.store.update_metadata(
                fragment.id,
                expected_revision=fragment.revision,
                title=self.title_edit.text(),
                note=self.note_edit.toPlainText(),
                tags=tags,
            )
        except FragmentExternalModificationError:
            QMessageBox.warning(
                self,
                tr('darlings.external_title', 'Fragment extern gewijzigd'),
                tr('darlings.external_text', 'Dit fragment is sinds het openen buiten QuietWriter gewijzigd. De externe versie is opnieuw geladen; je wijziging is niet overschreven.'),
            )
            return False
        except Exception as exc:
            QMessageBox.critical(
                self,
                tr('darlings.save_failed_title', 'Fragment niet opgeslagen'),
                tr('darlings.save_failed_text', 'De fragmentgegevens konden niet veilig worden opgeslagen.\n\n{error}', error=exc),
            )
            return False
        self._loaded_fragment = updated
        self.dirty = False
        self.status.setText(tr('darlings.saved', 'Opgeslagen'))
        self.save_button.setEnabled(False)
        return True

    def save_pending(self):
        fragment_id = self._loaded_fragment.id if self._loaded_fragment is not None else None
        if self._save_current_fields():
            return True
        self.dirty = False
        if fragment_id:
            self.refresh(select_id=fragment_id)
        return False

    def save_metadata(self):
        fragment_id = self._loaded_fragment.id if self._loaded_fragment is not None else None
        if not self._save_current_fields():
            self.dirty = False
            if fragment_id:
                self.refresh(select_id=fragment_id)
            return False
        if fragment_id:
            self.refresh(select_id=fragment_id)
        return True

    def add_fragment(self, fragment):
        self.refresh(select_id=fragment.id)
