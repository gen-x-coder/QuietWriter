from pathlib import Path

from quietwriter.manuscript_markup import source_selection_with_enclosing_markup
from quietwriter.ui.rail_model import RailState, build_rail_view

ROOT = Path(__file__).resolve().parents[2]


def _selected(source, visible):
    start = source.index(visible)
    end = start + len(visible)
    a, b = source_selection_with_enclosing_markup(source, start, end)
    return source[a:b]


def test_copy_range_keeps_boundary_inline_markdown():
    assert _selected('Voor **vet** na', 'vet') == '**vet**'
    assert _selected('Voor *cursief* na', 'cursief') == '*cursief*'
    assert _selected('Voor ~~weg~~ na', 'weg') == '~~weg~~'
    assert _selected('Voor `code` na', 'code') == '`code`'
    assert _selected('Voor <u>onder</u> na', 'onder') == '<u>onder</u>'


def test_copy_range_keeps_nested_bold_italic_markdown():
    source = 'Voor ***beide*** na'
    start = source.index('beide')
    a, b = source_selection_with_enclosing_markup(source, start, start + len('beide'))
    assert source[a:b] == '***beide***'


def test_internal_markup_is_already_preserved():
    source = 'begin normaal **vet** einde'
    start = source.index('normaal')
    end = source.index(' einde')
    a, b = source_selection_with_enclosing_markup(source, start, end)
    assert source[a:b] == 'normaal **vet**'


def test_darlings_is_workspace_level_navigation():
    assert 'darlings' in build_rail_view(RailState(False, False, False)).visible_items
    assert 'darlings' in build_rail_view(RailState(True, True, True)).visible_items


def test_editor_copy_path_uses_source_text_not_plain_text():
    source = (ROOT / 'quietwriter' / 'ui' / 'editor_page.py').read_text(encoding='utf-8')
    method = source[source.index('    def copy_selection_to_darlings'):source.index('    def _editor_source_text')]
    assert 'self._editor_source_text()' in method
    assert 'source_selection_with_enclosing_markup' in method
    assert 'toPlainText()' not in method


def test_darlings_page_surfaces_list_errors_and_translates_empty_fallback():
    source = (ROOT / 'quietwriter' / 'ui' / 'darlings_page.py').read_text(encoding='utf-8')
    assert 'last_list_errors' in source
    assert "tr('darlings.untitled'" in source
    assert 'expected_revision=fragment.revision' in source
