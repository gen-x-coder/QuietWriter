from __future__ import annotations

from pathlib import Path

from ..markdown_io import CORE_EXPORT_ORDER, INTERNAL_METADATA, _clean_scalar
from ..storage import _safe_atomic_write_text
from .models import ExportDocument


def _frontmatter(document: ExportDocument) -> str:
    md = dict(document.metadata or {})
    md['title'] = document.title
    md['slug'] = document.slug
    rows = []
    emitted = set()
    for key in CORE_EXPORT_ORDER:
        rows.append(f'{key}: {_clean_scalar(md.get(key, ""))}')
        emitted.add(key)
    for source in ((md.get('extra') if isinstance(md.get('extra'), dict) else {}), md):
        for key, value in source.items():
            key = str(key).lower()
            if key in emitted or key in INTERNAL_METADATA or key in CORE_EXPORT_ORDER:
                continue
            scalar = _clean_scalar(value)
            if scalar and '\n' not in scalar:
                rows.append(f'{key}: {scalar}'); emitted.add(key)
    return '---\n' + '\n'.join(rows) + '\n---\n'


def export_markdown(document: ExportDocument, destination: Path, settings: dict) -> Path:
    options = dict(settings.get('markdown') or {})
    parts: list[str] = []
    if bool(options.get('include_frontmatter', True)):
        parts.append(_frontmatter(document).rstrip())
    multiple_sections = len(document.sections) > 1 or any(section.id != 'root' for section in document.sections)
    for section in document.sections:
        if bool(options.get('include_section_markers', True)) and multiple_sections:
            parts.append(f'<!-- quietwriter-section: {section.title} -->')
        for chapter in section.chapters:
            parts.append(f'# {chapter.title}')
            if chapter.markdown.strip(): parts.append(chapter.markdown.strip())
    _safe_atomic_write_text(Path(destination), '\n\n'.join(parts).rstrip() + '\n')
    return Path(destination)
