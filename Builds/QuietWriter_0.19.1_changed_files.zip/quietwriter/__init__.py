APP_NAME = "QuietWriter"
__version__ = "0.19.1"
