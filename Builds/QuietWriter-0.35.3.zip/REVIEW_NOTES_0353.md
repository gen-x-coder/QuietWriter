# Review 0.35.3

Hotfix voor de startcrash in 0.35.2.

Verplicht met echte PySide6:
1. `python main.py` koude start.
2. `pytest`
3. `pytest -m qt`
4. `pytest tests/legacy`
5. `pytest tests/legacy -m qt`

Specifiek reproduceren:
- 0.35.2 faalt in `AIPanel.__init__` op `tr(...)` met `NameError`.
- 0.35.3 moet zonder die fout het hoofdvenster openen.
- AI-paneel openen en een hoofdstuk openen om te bevestigen dat de vertaalde labels gewoon renderen.

Geen andere productwijzigingen in deze hotfix.
