from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QFileDialog, QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QVBoxLayout, QWidget,
)

from ..i18n import tr


class ImageInsertWidget(QWidget):
    """Small book-image insertion flow used inside the regular Insert panel.

    The source image is only previewed here. It is copied into the book's media
    store after the writer presses Insert, so cancelling never leaves an orphan.
    """

    insertRequested = Signal(str, str, str)
    cancelRequested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.source_path: Path | None = None
        self._preview_pixmap: QPixmap | None = None

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(10)

        title = QLabel(tr('insert.image.title', 'Afbeelding'))
        title.setObjectName('sectionTitle')
        description = QLabel(tr(
            'insert.image.description',
            'Voeg een JPG- of PNG-afbeelding toe als eigen blok in het manuscript.'
        ))
        description.setObjectName('muted')
        description.setWordWrap(True)

        self.preview_frame = QFrame()
        self.preview_frame.setObjectName('settingsCard')
        preview_layout = QVBoxLayout(self.preview_frame)
        preview_layout.setContentsMargins(10, 10, 10, 10)
        self.preview = QLabel(tr('insert.image.no_file', 'Nog geen afbeelding gekozen'))
        self.preview.setObjectName('muted')
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setMinimumHeight(150)
        self.preview.setMaximumHeight(220)
        preview_layout.addWidget(self.preview)

        self.file_label = QLabel('')
        self.file_label.setObjectName('muted')
        self.file_label.setWordWrap(True)
        self.choose_button = QPushButton(tr('insert.image.choose', 'Afbeelding kiezen…'))
        self.choose_button.setObjectName('secondaryButton')
        self.choose_button.clicked.connect(self.choose_file)

        alt_label = QLabel(tr('insert.image.alt', 'Alt-tekst'))
        self.alt_edit = QLineEdit()
        self.alt_edit.setPlaceholderText(tr(
            'insert.image.alt.placeholder',
            'Korte beschrijving voor toegankelijkheid'
        ))
        self.alt_edit.setToolTip(tr(
            'insert.image.alt.tip',
            'Beschrijf kort wat op de afbeelding te zien is. Deze tekst wordt ook in EPUB gebruikt.'
        ))

        caption_label = QLabel(tr('insert.image.caption', 'Onderschrift'))
        self.caption_edit = QLineEdit()
        self.caption_edit.setPlaceholderText(tr(
            'insert.image.caption.placeholder',
            'Optioneel onderschrift onder de afbeelding'
        ))

        buttons = QHBoxLayout()
        self.cancel_button = QPushButton(tr('common.cancel', 'Annuleren'))
        self.cancel_button.setObjectName('secondaryButton')
        self.insert_button = QPushButton(tr('insert.image.insert', 'Invoegen'))
        self.insert_button.setObjectName('primaryButton')
        self.insert_button.setEnabled(False)
        self.cancel_button.clicked.connect(self.cancelRequested.emit)
        self.insert_button.clicked.connect(self._emit_insert)
        buttons.addWidget(self.cancel_button)
        buttons.addStretch(1)
        buttons.addWidget(self.insert_button)

        root.addWidget(title)
        root.addWidget(description)
        root.addWidget(self.preview_frame)
        root.addWidget(self.file_label)
        root.addWidget(self.choose_button)
        root.addSpacing(6)
        root.addWidget(alt_label)
        root.addWidget(self.alt_edit)
        root.addWidget(caption_label)
        root.addWidget(self.caption_edit)
        root.addStretch(1)
        root.addLayout(buttons)

        QWidget.setTabOrder(self.choose_button, self.alt_edit)
        QWidget.setTabOrder(self.alt_edit, self.caption_edit)
        QWidget.setTabOrder(self.caption_edit, self.cancel_button)
        QWidget.setTabOrder(self.cancel_button, self.insert_button)

    def reset(self):
        self.source_path = None
        self._preview_pixmap = None
        self.preview.setPixmap(QPixmap())
        self.preview.setText(tr('insert.image.no_file', 'Nog geen afbeelding gekozen'))
        self.file_label.clear()
        self.alt_edit.clear()
        self.caption_edit.clear()
        self.insert_button.setEnabled(False)
        self.choose_button.setFocus()

    def choose_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            tr('insert.image.choose_title', 'Kies een afbeelding'),
            '',
            tr('insert.image.filter', 'Afbeeldingen (*.jpg *.jpeg *.png)')
        )
        if path:
            self.set_source(Path(path))

    def set_source(self, path: Path):
        path = Path(path)
        pixmap = QPixmap(str(path))
        if pixmap.isNull():
            self.source_path = None
            self._preview_pixmap = None
            self.preview.setPixmap(QPixmap())
            self.preview.setText(tr('insert.image.invalid', 'Deze afbeelding kan niet worden gelezen.'))
            self.file_label.setText(path.name)
            self.insert_button.setEnabled(False)
            return
        self.source_path = path
        self._preview_pixmap = pixmap
        self.file_label.setText(path.name)
        self.insert_button.setEnabled(True)
        self._refresh_preview()
        self.alt_edit.setFocus()

    def _refresh_preview(self):
        if not self._preview_pixmap:
            return
        size = self.preview.size()
        if size.width() <= 0 or size.height() <= 0:
            return
        scaled = self._preview_pixmap.scaled(
            max(1, size.width() - 8), max(1, size.height() - 8),
            Qt.KeepAspectRatio, Qt.SmoothTransformation,
        )
        self.preview.setText('')
        self.preview.setPixmap(scaled)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._refresh_preview()

    def _emit_insert(self):
        if not self.source_path:
            return
        self.insertRequested.emit(
            str(self.source_path),
            self.alt_edit.text().strip(),
            self.caption_edit.text().strip(),
        )
